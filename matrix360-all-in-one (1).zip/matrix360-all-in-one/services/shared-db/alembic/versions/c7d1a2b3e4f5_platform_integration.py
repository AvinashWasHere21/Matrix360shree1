"""platform_integration: external_ref, details, contact_events

Revision ID: c7d1a2b3e4f5
Revises: b44e2fae97e3
Create Date: 2026-10-12

Additive only. Existing rows keep working: new lead columns are nullable,
and contact_events is a new table. Nothing is dropped or rewritten.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "c7d1a2b3e4f5"
down_revision: Union[str, Sequence[str], None] = "b44e2fae97e3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("leads", schema=None) as batch_op:
        batch_op.add_column(sa.Column("external_ref", sa.String(120), nullable=True))
        batch_op.add_column(sa.Column("details", sa.JSON(), nullable=True))
        batch_op.create_index("ix_leads_external_ref", ["external_ref"], unique=True)

    op.create_table(
        "contact_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("lead_id", sa.String(36), sa.ForeignKey("leads.id"), nullable=False),
        sa.Column("channel", sa.String(20), nullable=False),
        sa.Column("direction", sa.String(10), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="sent"),
        sa.Column("message_id", sa.String(120), nullable=True),
        sa.Column("text", sa.Text(), nullable=False, server_default=""),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_contact_events_lead_id", "contact_events", ["lead_id"])
    op.create_index("ix_contact_events_message_id", "contact_events", ["message_id"])


def downgrade() -> None:
    op.drop_index("ix_contact_events_message_id", table_name="contact_events")
    op.drop_index("ix_contact_events_lead_id", table_name="contact_events")
    op.drop_table("contact_events")
    with op.batch_alter_table("leads", schema=None) as batch_op:
        batch_op.drop_index("ix_leads_external_ref")
        batch_op.drop_column("details")
        batch_op.drop_column("external_ref")
