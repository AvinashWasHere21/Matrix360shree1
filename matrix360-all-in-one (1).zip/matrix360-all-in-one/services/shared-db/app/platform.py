"""Matrix360 platform integration: connects the team's tools to this shared DB.

Adds, without changing any existing route:
- PATCH /api/v1/leads/{id}, contact history, funnel counts, due reminders.
- Adapters that speak each tool's existing format, so their code does not change:
    /integrations/chat/...       Avinash's chat widget (DB_API_URL contract)
    /integrations/whatsapp/...   Tanmayi's sharedDbClient (/api/leads...)
    /integrations/landing/...    Shalini's landing-page forms (FORM_ENDPOINT)

Every new lead still goes through the existing create_lead route logic, so
dedupe (phone last 10 -> email -> LinkedIn), scoring and audit stay in one place.
"""
from __future__ import annotations

import hashlib
import hmac
import threading
from datetime import datetime, timedelta, timezone

from fastapi import Depends, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pathlib import Path
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator
from sqlalchemy import func, select

from .models import ContactEvent, Lead, SiteVisit, utcnow
from .schemas import VALID_STAGES, LeadCreate
from .scoring import calculate_score

STAGE_RANK = {"new": 0, "qualified": 1, "contacted": 2, "engaged": 3, "visit_booked": 4}
PATCH_STAGES = VALID_STAGES | {"opted_out"}

CHAT_CLIENTS = {"shree-heights": "Shree Heights", "lakhotia-industrial": "Lakhotia", "vrindavan-greens": "Vrindavan Greens"}
CLIENT_PROPERTY = {"Shree Heights": "flats", "Lakhotia": "industrial", "Vrindavan Greens": "plots"}
CHAT_PROPERTY = {"flat": "flats", "plot": "plots", "industrial": "industrial"}
CHAT_TIMELINE = {"asap": "immediate", "1_3": "within_3_months", "3_6": "within_6_months", "6_plus": "within_12_months"}
CHAT_ROLE = {"decision_maker": True, "helping": False, "researching": False}
CHAT_STAGE = {"New": "new", "In conversation": "engaged", "Qualified": "engaged",
              "Handoff requested": "engaged", "Visit booked": "visit_booked"}
INDIVIDUAL = "Individual buyer"  # company is required by the lead model; buyers have none
# ponytail: one lock per process; with several app processes on Postgres use SELECT ... FOR UPDATE instead.
_CHAT_LOCK = threading.Lock()


class LeadUpdate(BaseModel):
    """Fields any tool may change on an existing lead. Each change is audited."""
    model_config = ConfigDict(extra="forbid")

    stage: str | None = None
    intent: str | None = None
    owner: str | None = Field(default=None, max_length=120)
    next_action: str | None = Field(default=None, max_length=255)
    next_action_date: datetime | None = None
    fit_score: int | None = Field(default=None, ge=0, le=100)
    fit_reasons: list[str] | None = None
    consent: bool | None = None
    opted_out: bool | None = None

    @field_validator("stage")
    @classmethod
    def known_stage(cls, v):
        if v is not None and v not in PATCH_STAGES:
            raise ValueError(f"Unknown stage '{v}'")
        return v

    @field_validator("intent")
    @classmethod
    def known_intent(cls, v):
        if v is not None and v not in {"hot", "warm", "cold"}:
            raise ValueError("intent must be hot, warm or cold")
        return v


class ContactIn(BaseModel):
    model_config = ConfigDict(extra="ignore")
    channel: str = Field(default="whatsapp", max_length=20)
    direction: str = Field(default="outbound", pattern="^(inbound|outbound)$")
    status: str = Field(default="sent", max_length=20)
    message_id: str | None = Field(default=None, max_length=120)
    text: str = Field(default="", max_length=4000)
    timestamp: datetime | None = None


def _contact_dict(c: ContactEvent) -> dict:
    return {"id": c.id, "lead_id": c.lead_id, "channel": c.channel, "direction": c.direction,
            "status": c.status, "message_id": c.message_id, "text": c.text,
            "timestamp": c.occurred_at.isoformat()}


def _clean_contact(value):
    """Forms send placeholders like 'Not known'. Only real-looking values count."""
    if not value or not isinstance(value, str):
        return None
    return value.strip() if any(ch.isdigit() for ch in value) or "@" in value else None


def _chat_structured(rec: dict) -> dict:
    """Chat answers mapped to the fields the shared scoring rule reads."""
    budget_lakh = rec.get("budget_max_lakh") or rec.get("budget_min_lakh")
    return {
        "timeline": CHAT_TIMELINE.get(rec.get("timeline"), "unknown"),
        "budget_inr": float(budget_lakh) * 100_000 if budget_lakh else None,
        "is_decision_maker": CHAT_ROLE.get(rec.get("role")),
        "site_visit_interest": rec.get("consult_type") == "visit",
    }


def _known(value):
    """Forms use placeholders for skipped answers; treat them as missing."""
    if not isinstance(value, str) or value.strip().lower() in {"", "not known", "unknown", "not sure", "n/a"}:
        return None
    return value.strip()


def register_platform(app, *, get_db, require_admin, settings, create_lead, lead_dict, record_audit):
    origins = [o.strip() for o in settings.allowed_origins.split(",") if o.strip()]
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST", "PATCH"],
                       allow_headers=["Content-Type", "Authorization", "X-Admin-Key", "Idempotency-Key"])

    def require_integration(authorization: str | None = Header(default=None)) -> None:
        token = (authorization or "").removeprefix("Bearer ").strip()
        if not token or not hmac.compare_digest(token, settings.integration_api_key):
            raise HTTPException(status_code=401, detail="Valid 'Authorization: Bearer <INTEGRATION_API_KEY>' required")

    def get_lead_or_404(db, lead_id: str) -> Lead:
        lead = db.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead not found")
        return lead

    # ── shared operations ────────────────────────────────────────────────────

    def update_lead(db, lead: Lead, upd: LeadUpdate, actor: str) -> dict:
        data = upd.model_dump(exclude_unset=True)
        before = lead_dict(lead)
        column = {"fit_score": "score", "fit_reasons": "score_reasons"}
        for key, value in data.items():
            if key == "consent":
                lead.consent_to_share = lead.contact_consent = bool(value)
            else:
                setattr(lead, column.get(key, key), value)
        after = lead_dict(lead)
        changes = {k: [before[k], after[k]] for k in data if before.get(k) != after.get(k)}
        if changes:
            lead.updated_at = utcnow()
            record_audit(db, "lead.updated", lead.id, actor=actor, details={"changes": changes})
        db.commit()
        db.refresh(lead)
        return lead_dict(lead)

    def list_contacts(db, lead_id: str) -> list[dict]:
        rows = db.scalars(select(ContactEvent).where(ContactEvent.lead_id == lead_id)
                          .order_by(ContactEvent.occurred_at)).all()
        return [_contact_dict(c) for c in rows]

    def add_contact(db, lead_id: str, c: ContactIn, actor: str) -> dict:
        if c.message_id:
            existing = db.scalar(select(ContactEvent).where(ContactEvent.message_id == c.message_id))
            if existing:
                return _contact_dict(existing)  # retries are safe
        event = ContactEvent(lead_id=lead_id, channel=c.channel, direction=c.direction, status=c.status,
                             message_id=c.message_id, text=c.text, occurred_at=c.timestamp or utcnow())
        db.add(event)
        db.flush()
        record_audit(db, f"contact.{c.direction}", lead_id, actor=actor,
                     details={"channel": c.channel, "status": c.status, "message_id": c.message_id})
        db.commit()
        return _contact_dict(event)

    def save_new(db, payload: LeadCreate, details_key: str, details: dict, external_ref: str | None = None):
        """Create through the existing endpoint logic, then attach tool details."""
        result = create_lead(payload=payload, db=db, idempotency_key=None)
        lead = db.get(Lead, result["lead_id"])
        merged = dict(lead.details or {})
        merged[details_key] = details
        lead.details = merged
        if external_ref and lead.external_ref is None:
            lead.external_ref = external_ref
        elif external_ref and lead.external_ref != external_ref:
            record_audit(db, "lead.external_ref_conflict", lead.id, actor=payload.source,
                         details={"existing": lead.external_ref, "incoming": external_ref})
        db.commit()
        db.refresh(lead)
        return lead, result["is_duplicate"]

    # ── canonical API additions (admin key) ──────────────────────────────────

    @app.get("/platform", include_in_schema=False)
    def platform_dashboard():
        return FileResponse(Path(__file__).parent / "static" / "platform.html")

    @app.patch("/api/v1/leads/{lead_id}", tags=["leads"], dependencies=[Depends(require_admin)])
    def patch_lead(lead_id: str, payload: LeadUpdate, db=Depends(get_db), x_actor: str | None = Header(default=None)):
        return update_lead(db, get_lead_or_404(db, lead_id), payload, actor=x_actor or "api")

    @app.get("/api/v1/leads/{lead_id}/contacts", tags=["contacts"], dependencies=[Depends(require_admin)])
    def get_contacts(lead_id: str, db=Depends(get_db)):
        get_lead_or_404(db, lead_id)
        return list_contacts(db, lead_id)

    @app.post("/api/v1/leads/{lead_id}/contacts", status_code=201, tags=["contacts"], dependencies=[Depends(require_admin)])
    def post_contact(lead_id: str, payload: ContactIn, db=Depends(get_db)):
        get_lead_or_404(db, lead_id)
        return add_contact(db, lead_id, payload, actor="api")

    @app.get("/api/v1/funnel", tags=["reporting"], dependencies=[Depends(require_admin)])
    def funnel(db=Depends(get_db)):
        def counts(col):
            return {k or "unknown": n for k, n in db.execute(select(col, func.count()).group_by(col)).all()}
        stage = counts(Lead.stage)
        return {
            "stages": {s: stage.get(s, 0) for s in STAGE_RANK} | {k: v for k, v in stage.items() if k not in STAGE_RANK},
            "by_source": counts(Lead.source),
            "by_intent": counts(Lead.intent),
            "opted_out": db.scalar(select(func.count()).select_from(Lead).where(Lead.opted_out.is_(True))) or 0,
            "total": db.scalar(select(func.count()).select_from(Lead)) or 0,
        }

    @app.get("/api/v1/reminders/due", tags=["site visits"], dependencies=[Depends(require_admin)])
    def reminders_due(now: datetime | None = Query(default=None), db=Depends(get_db)):
        """Site-visit reminders that are due and not yet recorded as sent.
        The caller sends each one through Tanmayi's policy gate, then records it with
        POST /contacts using the returned message_id, so it is never sent twice."""
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        due = []
        visits = db.scalars(select(SiteVisit).where(SiteVisit.status == "scheduled", SiteVisit.scheduled_at.is_not(None))).all()
        for v in visits:
            at = v.scheduled_at if v.scheduled_at.tzinfo else v.scheduled_at.replace(tzinfo=timezone.utc)
            if not now < at:
                continue
            kind = "2h" if now >= at - timedelta(hours=2) else "24h" if now >= at - timedelta(hours=24) else None
            if not kind:
                continue
            message_id = f"reminder-{kind}:{v.id}"
            if db.scalar(select(ContactEvent).where(ContactEvent.message_id == message_id)):
                continue
            due.append({"visit_id": v.id, "kind": kind, "scheduled_at": at.isoformat(),
                        "message_id": message_id, "lead": lead_dict(db.get(Lead, v.lead_id))})
        return due

    # ── Tanmayi: WhatsApp engage (sharedDbClient paths, Bearer key) ───────────

    wa = "/integrations/whatsapp/api/leads"

    @app.get(wa, tags=["integrations"], dependencies=[Depends(require_integration)])
    def wa_list(db=Depends(get_db)):
        return [lead_dict(l) for l in db.scalars(select(Lead).order_by(Lead.created_at.desc()).limit(500)).all()]

    @app.get(wa + "/{lead_id}", tags=["integrations"], dependencies=[Depends(require_integration)])
    def wa_get(lead_id: str, db=Depends(get_db)):
        return lead_dict(get_lead_or_404(db, lead_id))

    @app.patch(wa + "/{lead_id}", tags=["integrations"], dependencies=[Depends(require_integration)])
    def wa_patch(lead_id: str, payload: LeadUpdate, db=Depends(get_db)):
        return update_lead(db, get_lead_or_404(db, lead_id), payload, actor="whatsapp_engage")

    @app.get(wa + "/{lead_id}/contacts", tags=["integrations"], dependencies=[Depends(require_integration)])
    def wa_contacts(lead_id: str, db=Depends(get_db)):
        get_lead_or_404(db, lead_id)
        return list_contacts(db, lead_id)

    @app.post(wa + "/{lead_id}/contacts", status_code=201, tags=["integrations"], dependencies=[Depends(require_integration)])
    def wa_add_contact(lead_id: str, payload: ContactIn, db=Depends(get_db)):
        get_lead_or_404(db, lead_id)
        return add_contact(db, lead_id, payload, actor="whatsapp_engage")

    # ── Avinash: website chat (DB_API_URL contract, Bearer key) ──────────────

    @app.post("/integrations/chat/leads/upsert", tags=["integrations"], dependencies=[Depends(require_integration)])
    def chat_upsert(rec: dict, db=Depends(get_db)):
        # The chat sends overlapping updates from two threads; apply them one at a time.
        with _CHAT_LOCK:
            db.expire_all()
            return _chat_upsert(rec, db)

    def _chat_upsert(rec: dict, db):
        chat_id = str(rec.get("lead_id") or "").strip()
        client = CHAT_CLIENTS.get(rec.get("client_id"))
        if not chat_id or not client:
            raise HTTPException(status_code=422, detail="lead_id and a known client_id are required")
        ref = f"chat:{chat_id}"
        structured = _chat_structured(rec)
        chat_details = {k: v for k, v in rec.items() if k not in {"name", "phone", "email"}}
        lead = db.scalar(select(Lead).where(Lead.external_ref == ref))
        duplicate = False
        if lead is None:
            phone, email = _clean_contact(rec.get("phone")), _clean_contact(rec.get("email"))
            if not (phone or email):
                return {"status": "waiting_for_contact_details", "external_ref": ref}
            try:
                payload = LeadCreate(
                    client=client, property_type=CHAT_PROPERTY.get(rec.get("property_type")) or CLIENT_PROPERTY[client],
                    lead_type="buyer", source="chat", evidence=rec.get("page_url") or "Website chat",
                    name=rec.get("name") or "Website visitor", company=INDIVIDUAL, phone=phone, email=email,
                    consent=rec.get("followup_consent") is True,
                    utm_source=rec.get("utm_source") or None, utm_campaign=rec.get("utm_campaign") or None,
                    business_requirements=(rec.get("summary") or "")[:1000], **structured,
                )
            except ValidationError as exc:
                raise HTTPException(status_code=422, detail=exc.errors(include_url=False)) from exc
            lead, duplicate = save_new(db, payload, "chat", chat_details, external_ref=ref)
            if lead.external_ref != ref:
                # Matched an existing lead already linked to a different chat. Do not merge.
                return {"lead_id": lead.id, "is_duplicate": True, "status": "needs_review", "lead": lead_dict(lead)}

        # Each chat turn refreshes the lead with what the buyer has said so far.
        # The chat can deliver an older record after a newer one; keep the newest.
        stored = (lead.details or {}).get("chat") or {}
        if stored.get("lead_id") == chat_id and str(rec.get("updated_at") or "") < str(stored.get("updated_at") or ""):
            return {"lead_id": lead.id, "external_ref": ref, "is_duplicate": duplicate, "status": "older_update_ignored",
                    "lead": lead_dict(lead)}
        if stored.get("lead_id") == chat_id and str(rec.get("updated_at") or "") == str(stored.get("updated_at") or ""):
            # Same-second records arrive in any order. Answers only fill in during a chat,
            # so merge: a blank value never wipes one already received.
            chat_details = {**stored, **{k: v for k, v in chat_details.items() if v not in (None, "", [])}}
            rec = {**stored, **{k: v for k, v in rec.items() if v not in (None, "", [])}}
            structured = _chat_structured(rec)
        before = lead_dict(lead)
        lead.details = {**(lead.details or {}), "chat": chat_details}
        for key, value in structured.items():
            if value not in (None, "unknown", False):
                setattr(lead, key, value)
        if rec.get("followup_consent") is True:
            lead.consent_to_share = lead.contact_consent = True
        elif rec.get("followup_consent") is False:
            lead.consent_to_share = lead.contact_consent = False
        score = calculate_score({"industry": lead.industry, "plot_size_sqm": lead.plot_size_sqm,
                                 "budget_inr": lead.budget_inr, "timeline": lead.timeline,
                                 "is_decision_maker": lead.is_decision_maker,
                                 "site_visit_interest": lead.site_visit_interest},
                                profile_id=lead.property_type or "industrial")
        lead.score, lead.score_reasons, lead.missing_fields, lead.intent = score.score, score.reasons, score.missing_fields, score.intent
        target = CHAT_STAGE.get(rec.get("stage"), "engaged")
        if STAGE_RANK.get(target, 0) > STAGE_RANK.get(lead.stage or "new", 0):
            lead.stage = target
        if rec.get("handoff_requested"):
            lead.next_action = f"Sales to call: {rec.get('handoff_reason') or 'buyer asked for a person'}"[:255]
            lead.next_action_date = utcnow()
        after = lead_dict(lead)
        changes = {k: [before[k], after[k]] for k in ("intent", "stage", "consent", "fit_score", "next_action") if before[k] != after[k]}
        if changes:
            record_audit(db, "lead.chat_synced", lead.id, actor="chat", details={"changes": changes, "external_ref": ref})
        lead.updated_at = utcnow()
        db.commit()
        db.refresh(lead)
        return {"lead_id": lead.id, "external_ref": ref, "is_duplicate": duplicate, "lead": lead_dict(lead)}

    @app.post("/integrations/chat/messages", status_code=201, tags=["integrations"], dependencies=[Depends(require_integration)])
    def chat_message(rec: dict, db=Depends(get_db)):
        lead = db.scalar(select(Lead).where(Lead.external_ref == f"chat:{rec.get('lead_id')}"))
        if lead is None:
            raise HTTPException(status_code=404, detail="Send the lead upsert first")  # chat retries in order
        role = rec.get("role")
        msg = ContactIn(channel="chat", direction="inbound" if role == "lead" else "outbound",
                        status="chat",  # never counts toward the WhatsApp frequency cap
                        # retries resend the identical line; different lines in the same second must both be kept
                        message_id="chat:" + hashlib.sha1(f"{rec.get('lead_id')}|{rec.get('ts')}|{role}|{rec.get('text')}".encode()).hexdigest()[:24],
                        text=str(rec.get("text") or "")[:4000], timestamp=rec.get("ts"))
        return add_contact(db, lead.id, msg, actor="chat")

    # ── Shalini: landing-page forms (public, CORS-limited) ───────────────────

    @app.post("/integrations/landing/enquiry", status_code=201, tags=["integrations"])
    async def landing_enquiry(request: Request, db=Depends(get_db)):
        body = await request.json()
        attr = body.get("attribution") or {}
        client = body.get("client") if body.get("client") in CLIENT_PROPERTY else "Shree Heights"
        common = dict(client=client, property_type=CLIENT_PROPERTY[client],
                      utm_source=attr.get("utm_source"), utm_campaign=attr.get("utm_campaign"))
        details = {k: v for k, v in body.items() if k not in {"name", "phone", "email"}}
        try:
            if body.get("kind") == "referral":
                partner, prospect = body.get("partner") or {}, body.get("lead")
                if prospect:
                    # Consent was asserted by the partner for this enquiry only: keep it
                    # false here so no channel messages the prospect until a person confirms.
                    payload = LeadCreate(
                        **common, lead_type="buyer", source="referral",
                        evidence=prospect.get("evidence") or prospect.get("referralId") or f"Referred by {partner.get('name')}",
                        name=prospect.get("name") or "Referred prospect",
                        company=_known(prospect.get("company")) or INDIVIDUAL,
                        phone=_clean_contact(prospect.get("phone")), email=_clean_contact(prospect.get("email")),
                        consent=False, next_action="Confirm the prospect's consent before any message",
                        business_requirements=(prospect.get("reason") or "")[:1000])
                else:
                    payload = LeadCreate(
                        **common, lead_type="broker", source="broker", evidence="Partner registration form",
                        name=partner.get("name") or "Partner", company=partner.get("firm") or "Independent partner",
                        phone=_clean_contact(partner.get("phone")), email=_clean_contact(partner.get("email")),
                        linkedin_url=partner.get("linkedin") or None, consent=False)
            else:
                payload = LeadCreate(
                    **common, lead_type="buyer", source="landing_page",
                    evidence=attr.get("landing") or body.get("from") or "Landing page",
                    name=body.get("name") or "Website visitor", company=INDIVIDUAL,
                    phone=_clean_contact(body.get("phone")), email=_clean_contact(body.get("email")),
                    consent=body.get("consent") is True,  # the form has no consent box yet
                    site_visit_interest=body.get("kind") == "visit",
                    business_requirements=(body.get("summary") or body.get("message") or "")[:1000])
        except ValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors(include_url=False)) from exc
        lead, duplicate = save_new(db, payload, "landing", details)
        return {"lead_id": lead.id, "is_duplicate": duplicate, "lead": lead_dict(lead)}
