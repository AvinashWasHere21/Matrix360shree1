"""ReferralOps prototype application package."""
