"""Matrix360 platform integration: PATCH, contacts, adapters, reminders, funnel."""
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

ADMIN = {"X-Admin-Key": "test-secret"}
TOOL = {"Authorization": "Bearer tool-secret"}


@pytest.fixture
def client(tmp_path):
    settings = Settings(database_url=f"sqlite:///{(tmp_path / 'p.db').as_posix()}", admin_api_key="test-secret",
                        ai_provider="demo", integration_api_key="tool-secret")
    return TestClient(create_app(settings=settings))


def make_lead(client, **over):
    body = {"client": "Shree Heights", "property_type": "flats", "lead_type": "buyer", "source": "landing_page",
            "name": "Test Buyer", "company": "Individual buyer", "phone": "+91 9000011111", "consent": True}
    body.update(over)
    r = client.post("/api/v1/leads", json=body)
    assert r.status_code == 201, r.text
    return r.json()["lead_id"]


def chat_record(**over):
    rec = {"lead_id": "chat-1", "client_id": "shree-heights", "name": "Asha Roy", "phone": "+919000022222",
           "property_type": "flat", "timeline": "1_3", "budget_max_lakh": 80, "role": "researching",
           "consult_type": None, "followup_consent": None, "stage": "In conversation", "score": "Warm",
           "summary": "2 BHK, about 80 lakh", "open_questions": ["parking charges?"], "utm_source": "instagram"}
    rec.update(over)
    return rec


def test_patch_updates_fields_and_audits(client):
    lead_id = make_lead(client)
    r = client.patch(f"/api/v1/leads/{lead_id}", headers=ADMIN,
                     json={"stage": "qualified", "fit_score": 72, "fit_reasons": ["Pratha rubric"], "owner": "Pratha"})
    assert r.status_code == 200
    lead = r.json()
    assert (lead["stage"], lead["fit_score"], lead["fit_reasons"], lead["owner"]) == ("qualified", 72, ["Pratha rubric"], "Pratha")
    audit = client.get("/api/v1/audit", headers=ADMIN).json()
    assert any(e["event_type"] == "lead.updated" and "fit_score" in e["details"]["changes"] for e in audit)


def test_patch_rejects_unknown_values_and_needs_admin(client):
    lead_id = make_lead(client)
    assert client.patch(f"/api/v1/leads/{lead_id}", json={"stage": "qualified"}).status_code == 401
    assert client.patch(f"/api/v1/leads/{lead_id}", headers=ADMIN, json={"stage": "won_big"}).status_code == 422
    assert client.patch(f"/api/v1/leads/{lead_id}", headers=ADMIN, json={"lead_type": "x"}).status_code == 422


def test_contacts_are_recorded_once_per_message_id(client):
    lead_id = make_lead(client)
    msg = {"channel": "whatsapp", "direction": "outbound", "status": "sent", "message_id": "wamid.1"}
    assert client.post(f"/api/v1/leads/{lead_id}/contacts", headers=ADMIN, json=msg).status_code == 201
    client.post(f"/api/v1/leads/{lead_id}/contacts", headers=ADMIN, json=msg)  # retry
    assert len(client.get(f"/api/v1/leads/{lead_id}/contacts", headers=ADMIN).json()) == 1


def test_whatsapp_adapter_matches_tanmayi_client(client):
    lead_id = make_lead(client)
    base = "/integrations/whatsapp/api/leads"
    assert client.get(base).status_code == 401
    leads = client.get(base, headers=TOOL).json()
    assert isinstance(leads, list) and leads[0]["lead_id"] == lead_id
    # what engageWorkflow sends on STOP
    r = client.patch(f"{base}/{lead_id}", headers=TOOL, json={"opted_out": True, "stage": "opted_out", "intent": "cold",
                                                              "next_action": "none_opted_out", "next_action_date": None})
    assert r.status_code == 200 and r.json()["opted_out"] is True and r.json()["stage"] == "opted_out"
    client.post(f"{base}/{lead_id}/contacts", headers=TOOL,
                json={"timestamp": "2026-10-12T10:00:00Z", "direction": "outbound", "status": "sent",
                      "channel": "whatsapp", "message_id": "m1"})
    history = client.get(f"{base}/{lead_id}/contacts", headers=TOOL).json()
    assert history[0]["direction"] == "outbound" and history[0]["status"] == "sent"


def test_chat_upsert_creates_then_updates_one_lead(client):
    first = client.post("/integrations/chat/leads/upsert", headers=TOOL, json=chat_record()).json()
    lead = first["lead"]
    assert (lead["client"], lead["property_type"], lead["source"], lead["lead_type"]) == ("Shree Heights", "flats", "chat", "buyer")
    assert lead["intent"] == "warm" and lead["stage"] == "engaged" and lead["consent"] is False
    assert lead["details"]["chat"]["open_questions"] == ["parking charges?"]
    again = client.post("/integrations/chat/leads/upsert", headers=TOOL,
                        json=chat_record(consult_type="visit", followup_consent=True, stage="Visit booked")).json()
    assert again["lead_id"] == first["lead_id"]
    assert again["lead"]["intent"] == "hot" and again["lead"]["consent"] is True and again["lead"]["stage"] == "visit_booked"
    # stage never moves backwards
    back = client.post("/integrations/chat/leads/upsert", headers=TOOL, json=chat_record(stage="In conversation")).json()
    assert back["lead"]["stage"] == "visit_booked"
    assert len(client.get("/api/v1/leads", headers=ADMIN).json()) == 1


def test_chat_matches_existing_lead_by_phone_and_keeps_source(client):
    lead_id = make_lead(client, phone="9000022222", utm_source="facebook")
    r = client.post("/integrations/chat/leads/upsert", headers=TOOL, json=chat_record()).json()
    assert r["lead_id"] == lead_id and r["is_duplicate"] is True
    assert r["lead"]["source"] == "landing_page" and r["lead"]["utm_source"] == "facebook"
    assert len(client.get("/api/v1/leads", headers=ADMIN).json()) == 1


def test_chat_messages_do_not_count_as_whatsapp_contacts(client):
    lead_id = client.post("/integrations/chat/leads/upsert", headers=TOOL, json=chat_record()).json()["lead_id"]
    msg = {"lead_id": "chat-1", "client_id": "shree-heights", "role": "bot", "text": "Hi Asha", "ts": "2026-10-12T10:00:00Z"}
    assert client.post("/integrations/chat/messages", headers=TOOL, json=msg).status_code == 201
    client.post("/integrations/chat/messages", headers=TOOL, json=msg)  # retry
    history = client.get(f"/api/v1/leads/{lead_id}/contacts", headers=ADMIN).json()
    assert len(history) == 1 and history[0]["status"] == "chat" and history[0]["channel"] == "chat"
    client.post("/integrations/chat/messages", headers=TOOL, json=dict(msg, text="What size?"))  # same second, new line
    assert len(client.get(f"/api/v1/leads/{lead_id}/contacts", headers=ADMIN).json()) == 2
    unknown = dict(msg, lead_id="chat-unknown")
    assert client.post("/integrations/chat/messages", headers=TOOL, json=unknown).status_code == 404


def test_landing_forms_map_to_shared_format(client):
    visit = {"kind": "visit", "name": "Ravi Sen", "phone": "9000033333", "email": "", "date": "2026-10-17",
             "slot": "Morning", "config": "3 BHK", "attribution": {"landing": "/", "utm_source": "instagram",
                                                                   "utm_campaign": "sh_oct"}, "summary": "3 BHK visit"}
    lead = client.post("/integrations/landing/enquiry", json=visit).json()["lead"]
    assert (lead["source"], lead["utm_source"], lead["utm_campaign"], lead["consent"]) == ("landing_page", "instagram", "sh_oct", False)
    assert lead["intent"] == "hot" and lead["details"]["landing"]["slot"] == "Morning"

    referral = {"kind": "referral", "intent": "lead",
                "partner": {"name": "Broker One", "firm": "B1 Realty", "phone": "9000044444", "email": ""},
                "lead": {"name": "Prospect P", "company": "Unknown", "phone": "9000055555", "email": "Unknown",
                         "reason": "Moving to Chandannagar", "consent": {"given": True}}}
    lead = client.post("/integrations/landing/enquiry", json=referral).json()["lead"]
    assert (lead["source"], lead["consent"], lead["company"]) == ("referral", False, "Individual buyer")
    assert "consent" in lead["next_action"].lower()

    partner = {"kind": "referral", "intent": "register", "lead": None,
               "partner": {"name": "Broker Two", "firm": "B2 Homes", "phone": "9000066666", "email": "b2@homes.test"}}
    lead = client.post("/integrations/landing/enquiry", json=partner).json()["lead"]
    assert (lead["lead_type"], lead["source"], lead["company"]) == ("broker", "broker", "B2 Homes")


def test_visit_schedule_moves_stage_and_reminders_are_due_once(client):
    lead_id = make_lead(client)
    visit = client.post(f"/api/v1/leads/{lead_id}/site-visits", headers=ADMIN, json={"requested_by": "chat"}).json()
    at = datetime.now(timezone.utc) + timedelta(hours=20)
    r = client.patch(f"/api/v1/site-visits/{visit['id']}", headers=ADMIN,
                     json={"status": "scheduled", "scheduled_at": at.isoformat()})
    assert r.status_code == 200
    assert client.get(f"/api/v1/leads/{lead_id}", headers=ADMIN).json()["stage"] == "visit_booked"

    due = client.get("/api/v1/reminders/due", headers=ADMIN).json()
    assert [d["kind"] for d in due] == ["24h"]
    client.post(f"/api/v1/leads/{lead_id}/contacts", headers=ADMIN,
                json={"channel": "whatsapp", "status": "sent", "message_id": due[0]["message_id"]})
    assert client.get("/api/v1/reminders/due", headers=ADMIN).json() == []
    two_hours_before = (at - timedelta(minutes=90)).isoformat()
    assert [d["kind"] for d in client.get("/api/v1/reminders/due", headers=ADMIN, params={"now": two_hours_before}).json()] == ["2h"]

    client.patch(f"/api/v1/site-visits/{visit['id']}", headers=ADMIN, json={"status": "cancelled"})
    assert client.get(f"/api/v1/leads/{lead_id}", headers=ADMIN).json()["stage"] == "visit_cancelled"
    assert client.get("/api/v1/reminders/due", headers=ADMIN).json() == []


def test_funnel_counts(client):
    make_lead(client)
    client.post("/integrations/chat/leads/upsert", headers=TOOL, json=chat_record())
    f = client.get("/api/v1/funnel", headers=ADMIN).json()
    assert f["total"] == 2 and f["stages"]["new"] == 1 and f["stages"]["engaged"] == 1
    assert f["by_source"] == {"landing_page": 1, "chat": 1}


def test_chat_ignores_an_older_record_delivered_late(client):
    newer = chat_record(updated_at="2026-10-12T10:05:00", followup_consent=True)
    older = chat_record(updated_at="2026-10-12T10:01:00", followup_consent=None)
    client.post("/integrations/chat/leads/upsert", headers=TOOL, json=newer)
    r = client.post("/integrations/chat/leads/upsert", headers=TOOL, json=older).json()
    assert r["status"] == "older_update_ignored" and r["lead"]["consent"] is True


def test_platform_dashboard_page_is_served(client):
    r = client.get("/platform")
    assert r.status_code == 200 and "Matrix360 Leads" in r.text


def test_chat_same_second_records_merge_instead_of_wiping(client):
    full = chat_record(updated_at="2026-10-12T10:05:00", followup_consent=True, visit_pref="Sat 17 Oct, Morning")
    partial = chat_record(updated_at="2026-10-12T10:05:00", followup_consent=None, visit_pref=None)
    client.post("/integrations/chat/leads/upsert", headers=TOOL, json=full)
    lead = client.post("/integrations/chat/leads/upsert", headers=TOOL, json=partial).json()["lead"]
    assert lead["consent"] is True and lead["details"]["chat"]["visit_pref"] == "Sat 17 Oct, Morning"
    assert lead["details"]["chat"]["followup_consent"] is True
