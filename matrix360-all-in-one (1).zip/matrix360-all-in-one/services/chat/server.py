"""Property Desk chat backend (FastAPI). One server, many businesses.

Run:  ADMIN_KEY=long-secret uvicorn server:app --port 8000
Each website embeds widget.js with data-client="<business id>". Business settings live in
clients/<id>.json (and optionally the database). See README.md and DB_CONTRACT.md.
"""
import csv
import glob
import io
import json
import os
import re
import secrets
import threading
import time
import urllib.request
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from urllib.parse import urlparse

from fastapi import BackgroundTasks, Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse
from pydantic import BaseModel, Field

import db
import engine
import parsing
import schema

BASE = os.path.dirname(os.path.abspath(__file__))
ADMIN_KEY = os.getenv("ADMIN_KEY", "")
EXTRA_ORIGINS = {o.strip().rstrip("/") for o in os.getenv("EXTRA_ORIGINS", "").split(",") if o.strip()}
ALLOW_LOCALHOST = os.getenv("ALLOW_LOCALHOST", "1") == "1"  # set to 0 in production
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
MAX_MESSAGES_PER_LEAD = int(os.getenv("MAX_MESSAGES_PER_LEAD", "300"))

store = db.LocalStore()
remote = db.RemoteSync()
remote_cfg = db.RemoteConfig(remote)

# --------------------------------------------------------------- business configs
_cfg_lock = threading.Lock()
_files = {}  # client_id -> (mtime, config)


def _load_files():
    with _cfg_lock:
        seen = set()
        for path in glob.glob(os.path.join(BASE, "clients", "*.json")):
            cid = os.path.splitext(os.path.basename(path))[0]
            seen.add(cid)
            m = os.path.getmtime(path)
            if cid not in _files or _files[cid][0] != m:
                with open(path, encoding="utf-8") as f:
                    cfg = json.load(f)
                cfg["id"] = cid
                cfg.setdefault("location", {}).setdefault("options", [])
                cfg.setdefault("contact", {})
                cfg.setdefault("amenities", [])
                cfg.setdefault("faq", [])
                cfg.setdefault("budget_bands", [])
                _files[cid] = (m, cfg)
        for gone in set(_files) - seen:
            del _files[gone]


def get_client(client_id):
    _load_files()
    hit = _files.get(client_id or "")
    if not hit:
        return None
    cfg = hit[1]
    over = remote_cfg.get(client_id)
    return db.deep_merge(cfg, over) if over else cfg


def all_origins():
    _load_files()
    out = set(EXTRA_ORIGINS)
    for _, cfg in _files.values():
        out |= {o.rstrip("/") for o in cfg.get("origins", [])}
    return out


def origin_ok(origin, client=None):
    if not origin:
        return True  # server-to-server calls, curl
    o = origin.rstrip("/")
    host = urlparse(o).hostname or ""
    if ALLOW_LOCALHOST and host in ("localhost", "127.0.0.1", "[::1]", "::1", ""):
        return True
    if o in EXTRA_ORIGINS:
        return True
    if client is not None:
        return o in {x.rstrip("/") for x in client.get("origins", [])}
    return o in all_origins()


@asynccontextmanager
async def lifespan(_app):
    _load_files()
    if remote.enabled:
        threading.Thread(target=_flusher, daemon=True).start()
        flush_remote()
    yield


app = FastAPI(title="Property Desk chat backend", lifespan=lifespan)


@app.middleware("http")
async def cors(request: Request, call_next):
    origin = request.headers.get("origin", "")
    allowed = bool(origin) and origin_ok(origin)
    if request.method == "OPTIONS":
        resp = Response(status_code=204)
    else:
        resp = await call_next(request)
    if allowed:
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Admin-Key"
        resp.headers["Access-Control-Max-Age"] = "600"
    return resp


# ---------------------------------------------------------------------- helpers
_hits = defaultdict(deque)


def rate_limit(request: Request):
    ip = (request.headers.get("x-forwarded-for", "").split(",")[0].strip() or (request.client.host if request.client else "unknown"))
    q = _hits[ip]
    t = time.time()
    while q and t - q[0] > 60:
        q.popleft()
    if len(q) >= 40:
        raise HTTPException(429, "Too many messages. Please wait a minute.")
    q.append(t)


def admin(x_admin_key: str = Header(default="")):
    if not ADMIN_KEY or not secrets.compare_digest(x_admin_key, ADMIN_KEY):
        raise HTTPException(403, "Forbidden")


def _post_json(url, payload):
    req = urllib.request.Request(url, data=json.dumps(payload, ensure_ascii=False).encode(), headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=8).read()


def alert_text(event, lead):
    head = {"handoff_requested": "TEAM MEMBER REQUESTED", "handoff_consent": "HANDOFF: CONTACT PERMISSION UPDATED",
            "qualification_complete": "QUALIFIED LEAD", "lead_created": "NEW CHAT"}.get(event, event.upper())
    consent = {True: "Follow-up ALLOWED", False: "Do NOT contact outside the chat", None: "Follow-up permission NOT given yet, do not contact"}[lead["followup_consent"]]
    return f"{head} · {lead['client_id']} · {lead['score']}\n{lead['name']} · {lead['phone']}\n{lead['summary']}\n{consent}"


def notify(event, lead, client):
    n = client.get("notify", {})
    text = alert_text(event, lead)
    chat_id = n.get("telegram_chat_id") or TELEGRAM_CHAT_ID
    if TELEGRAM_BOT_TOKEN and chat_id and event in ("handoff_requested", "handoff_consent", "qualification_complete"):
        try:
            _post_json(f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage", {"chat_id": chat_id, "text": text})
        except Exception as e:  # noqa: BLE001
            print("telegram failed:", type(e).__name__)
    url = n.get("webhook_url") or WEBHOOK_URL
    if url:
        try:
            _post_json(url, {"event": event, "lead": db.crm_record(lead), "alert_text": text})
        except Exception as e:  # noqa: BLE001
            print("webhook failed:", type(e).__name__)


def flush_remote():
    try:
        remote.flush(store)
    except Exception as e:  # noqa: BLE001
        print("sync failed:", type(e).__name__)


def _flusher():
    while True:
        time.sleep(30)
        flush_remote()




def public_client(c):
    return {"id": c["id"], "name": c["name"], "color": c.get("color", "#0d6a5a"), "tagline": c.get("tagline", ""),
            "privacy_url": c.get("privacy_url", ""), "disclaimer": c.get("disclaimer", "")}


# -------------------------------------------------------------------------- API
class SessionIn(BaseModel):
    client_id: str = Field(max_length=60)
    name: str = Field(max_length=80)
    phone: str = Field(max_length=24)
    consent: bool = False
    resume_session_id: str = Field(default="", max_length=80)
    page_url: str = Field(default="", max_length=300)
    utm_source: str = Field(default="", max_length=60)
    utm_medium: str = Field(default="", max_length=60)
    utm_campaign: str = Field(default="", max_length=60)


class ChatIn(BaseModel):
    session_id: str = Field(max_length=80)
    message: str = Field(default="", max_length=500)
    chip_id: str = Field(default="", max_length=80)


class ResumeIn(BaseModel):
    session_id: str = Field(max_length=80)


SOURCE_MAP = {"meta": "Meta ad", "facebook": "Meta ad", "fb": "Meta ad", "instagram": "Meta ad", "ig": "Meta ad",
              "google": "Google ad", "adwords": "Google ad", "99acres": "99acres", "magicbricks": "MagicBricks"}


@app.get("/api/config/{client_id}")
def config(client_id: str, request: Request):
    c = get_client(client_id)
    if not c:
        raise HTTPException(404, "Unknown business")
    if not origin_ok(request.headers.get("origin", ""), c):
        raise HTTPException(403, "This website is not allowed to use this chat")
    return public_client(c)


@app.post("/api/session", dependencies=[Depends(rate_limit)])
def new_session(body: SessionIn, request: Request, bg: BackgroundTasks):
    c = get_client(body.client_id)
    if not c:
        raise HTTPException(404, "Unknown business")
    if not origin_ok(request.headers.get("origin", ""), c):
        raise HTTPException(403, "This website is not allowed to use this chat")
    name = re.sub(r"\s+", " ", body.name).strip()
    if len(name) < 2 or not re.search(r"[A-Za-zऀ-ॿঀ-৿]", name):
        raise HTTPException(400, "Please enter your name.")
    ph = parsing.clean_phone(body.phone)
    if not ph:
        raise HTTPException(400, "Please enter a valid 10-digit Indian mobile number.")
    if not body.consent:
        raise HTTPException(400, "Please tick the box to continue.")
    e164, key = ph
    if body.resume_session_id:
        old = store.by_session(body.resume_session_id)
        if old and old["client_id"] == c["id"] and old["phone_key"] == key:
            return _resume_payload(old, c)
    now = engine.now_iso()
    lead = schema.blank()
    u = body.utm_source.strip()
    lead.update(
        lead_id="ld_" + secrets.token_hex(8), client_id=c["id"], session_id=secrets.token_urlsafe(24),
        name=name[:80], phone=e164, phone_key=key, source=SOURCE_MAP.get(u.lower()) or u or "Website chat",
        page_url=body.page_url[:300], utm_source=u[:60], utm_medium=body.utm_medium[:60], utm_campaign=body.utm_campaign[:60],
        intake_consent=True, created_at=now, updated_at=now,
    )
    lead["ctx"] = {}
    reply = engine.start(lead, c)
    ts = engine.now_iso()
    store.save(lead, [("bot", m, ts) for m in reply["messages"]])
    bg.add_task(flush_remote)
    bg.add_task(notify, "lead_created", lead, c)
    return {"session_id": lead["session_id"], "client": public_client(c), **_view(reply)}


def _view(reply):
    return {"messages": reply["messages"], "chips": reply["chips"], "quick": reply["quick"],
            "progress": reply["progress"], "step": reply["step"]}


def _resume_payload(lead, c):
    v = engine.view(lead, c)
    return {"session_id": lead["session_id"], "client": public_client(c), "resumed": True,
            "transcript": [{"role": m["role"], "text": m["text"]} for m in store.messages(lead["lead_id"])][-80:],
            "chips": v["chips"], "quick": v["quick"], "progress": v["progress"], "step": v["step"], "messages": []}


@app.post("/api/resume", dependencies=[Depends(rate_limit)])
def resume(body: ResumeIn, request: Request):
    lead = store.by_session(body.session_id)
    if not lead:
        raise HTTPException(404, "Session not found")
    c = get_client(lead["client_id"])
    if not c or not origin_ok(request.headers.get("origin", ""), c):
        raise HTTPException(403, "This website is not allowed to use this chat")
    return _resume_payload(lead, c)


_turn_lock = threading.Lock()


@app.post("/api/chat", dependencies=[Depends(rate_limit)])
def chat(body: ChatIn, request: Request, bg: BackgroundTasks):
    text = body.message.strip()
    if not text and not body.chip_id:
        raise HTTPException(400, "Empty message")
    with _turn_lock:
        lead = store.by_session(body.session_id)
        if not lead:
            raise HTTPException(404, "Session expired. Please start the chat again.")
        c = get_client(lead["client_id"])
        if not c:
            raise HTTPException(404, "Unknown business")
        if not origin_ok(request.headers.get("origin", ""), c):
            raise HTTPException(403, "This website is not allowed to use this chat")
        if store.message_count(lead["lead_id"]) > MAX_MESSAGES_PER_LEAD:
            raise HTTPException(429, "This chat has reached its limit. Please call the team.")
        shown = text
        if body.chip_id and not text:
            shown = _chip_text(lead, c, body.chip_id)
        reply = engine.handle(lead, c, text, body.chip_id or None)
        ts = engine.now_iso()
        store.save(lead, [("lead", shown, ts)] + [("bot", m, ts) for m in reply["messages"]])
    bg.add_task(flush_remote)
    for ev in reply["events"]:
        bg.add_task(notify, ev, lead, c)
    return _view(reply)


def _chip_text(lead, c, chip_id):
    """Readable label for a tapped chip, for the stored transcript."""
    for ch in engine.chips_for(lead.get("awaiting") or "", lead, c) + engine.quick_actions(c):
        if ch["id"] == chip_id:
            return ch["label"]
    return chip_id


# ------------------------------------------------------------------------ admin
@app.get("/api/admin/clients", dependencies=[Depends(admin)])
def admin_clients():
    _load_files()
    return [{"id": cid, "name": cfg["name"], "origins": cfg.get("origins", []), "todo": cfg.get("_todo", "")} for cid, (_, cfg) in _files.items()]


@app.get("/api/admin/leads", dependencies=[Depends(admin)])
def admin_leads(client_id: str = ""):
    return [db.crm_record(l) for l in store.list(client_id or None)]


@app.get("/api/admin/leads/{lead_id}/messages", dependencies=[Depends(admin)])
def admin_messages(lead_id: str):
    return store.messages(lead_id)


@app.get("/api/admin/leads.csv", dependencies=[Depends(admin)])
def admin_csv(client_id: str = ""):
    out = io.StringIO()
    w = csv.writer(out)
    cols = [n for n in schema.NAMES if n not in schema.CRM_EXCLUDE]
    w.writerow(cols)
    for l in store.list(client_id or None, 5000):
        w.writerow([json.dumps(l[n], ensure_ascii=False) if isinstance(l[n], (list, dict)) else l[n] for n in cols])
    return PlainTextResponse(out.getvalue(), media_type="text/csv")


@app.get("/api/admin/sync", dependencies=[Depends(admin)])
def admin_sync():
    """Status of the copy to the other database. POST-free: calling it also triggers a retry."""
    sent = remote.flush(store) if remote.enabled else 0
    return {"remote_enabled": remote.enabled, "flavor": remote.flavor, "sent_now": sent, **store.outbox_stats()}


# ------------------------------------------------------------------ static files
@app.get("/health")
def health():
    return {"ok": True}


@app.get("/widget.js")
def widget():
    return FileResponse(os.path.join(BASE, "widget.js"), media_type="application/javascript",
                        headers={"Cache-Control": "public, max-age=300"})


@app.get("/demo", response_class=HTMLResponse)
def demo():
    return FileResponse(os.path.join(BASE, "demo.html"))


@app.get("/", response_class=HTMLResponse)
def index():
    _load_files()
    rows = "".join(f'<li><a href="/demo?client={cid}">{cfg["name"]}</a> <code>{cid}</code></li>' for cid, (_, cfg) in sorted(_files.items()))
    return f"<!doctype html><meta charset=utf-8><title>Property Desk chat</title><body style='font:16px system-ui;max-width:640px;margin:40px auto;padding:0 16px'><h1>Property Desk chat</h1><p>Demo pages:</p><ul>{rows}</ul></body>"
