"""The lead record. This is the contract with the database your friend is building.

Every lead is one flat record (one row). Lists are JSON arrays. Times are ISO 8601 UTC strings.
Run `python schema.py` to print a Postgres CREATE TABLE for it, or `python schema.py --json`
to print the field list as JSON. DB_CONTRACT.md explains how each field maps to the 10 questions.
"""
import json
import sys

# (name, sql type, kind, default)   kind: text | int | real | bool | json
LEAD_COLUMNS = [
    # identity
    ("lead_id", "TEXT PRIMARY KEY", "text", ""),
    ("client_id", "TEXT NOT NULL", "text", ""),          # which business: shree-heights, ...
    ("session_id", "TEXT", "text", ""),
    ("name", "TEXT", "text", ""),
    ("phone", "TEXT", "text", ""),                       # E.164, e.g. +919876543210
    ("phone_key", "TEXT", "text", ""),                   # last 10 digits, use to de-duplicate people
    ("email", "TEXT", "text", None),
    # attribution
    ("source", "TEXT", "text", "Website chat"),
    ("page_url", "TEXT", "text", ""),
    ("utm_source", "TEXT", "text", ""),
    ("utm_medium", "TEXT", "text", ""),
    ("utm_campaign", "TEXT", "text", ""),
    # Q1  property type
    ("property_type", "TEXT", "text", None),             # flat | industrial | plot
    # Q2  purpose
    ("purpose", "TEXT", "text", None),
    # Q3  size / configuration
    ("size_label", "TEXT", "text", None),                # "2 BHK", "2-3 katha", "about 5000 sq ft"
    ("size_min", "DOUBLE PRECISION", "real", None),
    ("size_max", "DOUBLE PRECISION", "real", None),
    ("size_unit", "TEXT", "text", None),                 # bhk | katha | sq ft | acre | ...
    # Q4  location
    ("location_pref", "TEXT", "text", None),
    # Q5  budget (always in lakh rupees; 1 crore = 100)
    ("budget_label", "TEXT", "text", None),              # "about ₹70 lakh"
    ("budget_min_lakh", "DOUBLE PRECISION", "real", None),
    ("budget_max_lakh", "DOUBLE PRECISION", "real", None),
    ("budget_approx", "BOOLEAN", "bool", None),
    # Q6  timeline
    ("timeline", "TEXT", "text", None),                  # asap | 1_3 | 3_6 | 6_plus (months)
    ("timeline_label", "TEXT", "text", None),
    # Q7  role
    ("role", "TEXT", "text", None),                      # decision_maker | helping | researching
    # Q8  must-have infrastructure / features
    ("features", "JSONB", "json", []),                   # labels the visitor picked
    ("features_other", "TEXT", "text", None),            # anything they typed
    # Q9  consultation
    ("consult_type", "TEXT", "text", None),              # visit | call | none
    ("visit_pref", "TEXT", "text", None),                # "Sat 17 Oct, Morning" (a request, not a booking)
    # Q10 contact + permission
    ("contact_channel", "TEXT", "text", None),           # call | whatsapp | sms | email | none
    ("contact_time", "TEXT", "text", None),
    ("followup_consent", "BOOLEAN", "bool", None),       # NULL = not asked yet. Only contact outside the chat when TRUE.
    ("followup_consent_at", "TEXT", "text", None),
    ("intake_consent", "BOOLEAN", "bool", None),         # ticked the box on the name/phone form
    # handoff and bookkeeping
    ("handoff_requested", "BOOLEAN", "bool", False),
    ("handoff_reason", "TEXT", "text", None),
    ("unknown_fields", "JSONB", "json", []),             # questions answered "not sure / prefer not to say"
    ("open_questions", "JSONB", "json", []),             # questions the bot could not answer -> team must confirm
    ("score", "TEXT", "text", "Cold"),                   # Hot | Warm | Cold
    ("stage", "TEXT", "text", "New"),                    # New | In conversation | Qualified | Handoff requested
    ("summary", "TEXT", "text", ""),
    ("awaiting", "TEXT", "text", None),                  # internal: current question
    ("ctx", "JSONB", "json", {}),                        # internal: sub-step state
    ("created_at", "TEXT", "text", ""),
    ("updated_at", "TEXT", "text", ""),
]

NAMES = [c[0] for c in LEAD_COLUMNS]
KINDS = {c[0]: c[2] for c in LEAD_COLUMNS}
DEFAULTS = {c[0]: c[3] for c in LEAD_COLUMNS}
# Internal fields stay on this server.
CRM_EXCLUDE = {"ctx", "awaiting", "session_id"}  # session_id is a secret token: never leaves this server


def blank():
    d = {}
    for k, v in DEFAULTS.items():
        d[k] = json.loads(json.dumps(v)) if isinstance(v, (list, dict)) else v
    return d


def sql_postgres():
    lines = []
    for name, typ, _, _ in LEAD_COLUMNS:
        lines.append(f"  {name} {typ}")
    ddl = "CREATE TABLE IF NOT EXISTS leads (\n" + ",\n".join(lines) + "\n);\n"
    ddl += "CREATE UNIQUE INDEX IF NOT EXISTS leads_pk ON leads(lead_id);\n"
    ddl += "CREATE INDEX IF NOT EXISTS leads_client_phone ON leads(client_id, phone_key);\n\n"
    ddl += (
        "CREATE TABLE IF NOT EXISTS lead_messages (\n"
        "  id BIGSERIAL PRIMARY KEY,\n  lead_id TEXT NOT NULL REFERENCES leads(lead_id),\n"
        "  role TEXT NOT NULL,   -- lead | bot\n  text TEXT NOT NULL,\n  ts TEXT NOT NULL\n);\n"
    )
    return ddl


if __name__ == "__main__":
    if "--json" in sys.argv:
        print(json.dumps([{"name": n, "type": t, "default": d} for n, t, _, d in LEAD_COLUMNS], indent=2, ensure_ascii=False))
    else:
        print(sql_postgres())
