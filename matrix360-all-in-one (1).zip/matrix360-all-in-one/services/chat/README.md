# Property Desk chat

One chatbot server for many property businesses. Each website gets a chat button with one line of code. The bot asks for name and mobile number, then walks the visitor through the 10-question qualification script using clickable options, answers questions about the project, and saves everything to one lead record per conversation.

It is rule-based: no AI service, no API key, no per-message cost. It understands messy answers such as "about seventy lakhs", "1 cr 20 lakh", "dedh crore", "sixty to seventy lac", "75,00,000", "2-3 katha".

Included businesses: **Shree Heights** (flats), **Vrindavan Greens** (plots), **Lakhotia Industrial Complex** (industrial).

## Try it (2 minutes)

```bash
pip install -r requirements.txt
ADMIN_KEY=choose-a-long-secret uvicorn server:app --port 8000     # or: bash start.sh / start.bat
```

Open http://localhost:8000 and pick a business. Run the tests with `pip install pytest httpx && pytest`.

## Add the chat to a company website

Paste before `</body>` on every page, with that business's id:

```html
<script src="https://YOUR-SERVER/widget.js" data-client="shree-heights" defer></script>
```

| Business | `data-client` | Allowed website |
|---|---|---|
| Shree Heights | `shree-heights` | shreeheights.com |
| Lakhotia Industrial Complex | `lakhotia-industrial` | lakhotiaindustrialcomplex.com |
| Vrindavan Greens | `vrindavan-greens` | bhawanivrindavangreens.com |

Optional attributes: `data-color` (brand colour), `data-title`, `data-api` (if the backend is on another address), `data-open="1"` (auto-open once on desktop). On WordPress, Wix, Webflow or Shopify, put the line in the site's custom code / footer scripts setting. The server only answers requests from the website listed for that business (see `origins` in its config), so a copied snippet will not work elsewhere.

Campaign tags (`utm_source`, `utm_medium`, `utm_campaign`, Meta `fbclid`, Google `gclid`) on the visitor's link are saved on the lead.

## The conversation

One question at a time, in this order, skipping anything already known. Every question shows tappable options; typing works too. A quick-action row (Location, Amenities, Pricing, Talk to a team member) is always visible.

| # | Question | Options shown |
|---|---|---|
| 1 | Flat, industrial or plot? | skipped when the business sells one type (all three currently do) |
| 2 | What will it be used for? | only purposes for that property type, plus "Not sure yet" |
| 3 | Size or configuration | project sizes (BHK / katha / sq ft), typed areas understood, "Not sure yet" |
| 4 | Preferred location | the project's configured areas, or type any place |
| 5 | Budget | price bands, or type any figure, "Prefer not to say" (never rejects for a missing budget) |
| 6 | Decision or visit timeline | within a month / 1–3 / 3–6 / 6+ months / not decided |
| 7 | Decision-maker, helping someone, or researching | three buttons |
| 8 | Essential infrastructure / features | **only amenities verified in the config**; for a business with none (Lakhotia), generic requirement chips that are recorded as needs, never as availability |
| 9 | Sales consultation or site visit | then preferred date (next available days) and time of day |
| 10 | Contact channel, best time, explicit permission | follow-up only if they say yes; "Only in this chat" is an option |

Throughout: they can ask anything ("how far is the station?", "do you have a pool?", "what's the price?") and the bot answers and returns to the question. At the end it shows a summary of known vs not-shared answers, offers "Change an answer" and "Talk to a team member". A handoff request first asks permission to contact them, then alerts the team.

**What the bot will not do:** invent inventory, prices, legal or registration facts, locations or infrastructure. Anything not in the business's config gets: *"I don't have a confirmed answer for that, so a team member needs to confirm it"*, and the question is saved in `open_questions` on the lead for the sales team. Site visits are saved as requests, not bookings.

## Setting up a business

Each business is one file in `clients/`. Copy `clients/shree-heights.json`, change the id and contents, and the new business works immediately (no restart needed) with `data-client="<file name>"`. It holds: name, allowed website origins, colour, contact details, location and landmarks, amenities, purposes, size options, budget bands, pricing/inventory, FAQ answers and visit days.

**Content gaps to fill before launch**
- **Lakhotia Industrial Complex:** its website did not expose any readable content when this was built, so `clients/lakhotia-industrial.json` contains no facts (location, sizes, infrastructure, contact). Until it is filled in, the bot answers every such question with "a team member needs to confirm". Get these from the business owner, or have them come from the database.
- **All three:** no prices are published on their websites, so the bot says so and refers pricing to the team. Add `pricing.inventory` entries (or serve them from the database) once the team approves quoting them.
- Budget bands, purpose options and size bands are conversation choices I drafted, not claims about the project. Adjust them to how each business sells.
- Shree Heights and Vrindavan Greens facts (amenities, landmarks, plan details) were taken from their websites on 12 Oct 2026. Have each business confirm them.
- Add each business's `privacy_url` so the consent box links to its privacy policy, and check the consent wording against the DPDP Act with them.

## Connecting your friend's database

See **DB_CONTRACT.md** (give it to him). In short: set `DB_API_URL` and `DB_API_KEY`; every lead update and chat line is POSTed to his API (or to Supabase tables created from `schema.sql`). If his API is down, leads are queued in the local `chat.db` and retried, so nothing is lost. The exact fields, mapped to the 10 questions, are in `schema.py`. Optionally the bot reads prices, amenities and FAQs from his database (`CONFIG_FROM_DB=1`).

## Configuration

| Variable | Purpose |
|---|---|
| `ADMIN_KEY` | Needed to read leads at `/api/admin/*`. Empty disables them. |
| `ALLOW_LOCALHOST` | Default `1` so you can test locally. Set `0` in production. |
| `EXTRA_ORIGINS` | Extra allowed website origins, comma-separated (staging sites). |
| `DB_API_URL`, `DB_API_KEY`, `DB_FLAVOR`, `CONFIG_FROM_DB` | The other database, see above. |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` | Alerts for team-member requests and qualified leads. A client file can set its own `notify.telegram_chat_id`. |
| `WEBHOOK_URL` | POSTs every event (lead created, handoff, qualified) as JSON, per client via `notify.webhook_url`. |
| `DB_PATH` | Local SQLite file, default `chat.db`. Needs a disk that persists. |

Admin endpoints (header `X-Admin-Key`): `/api/admin/leads?client_id=`, `/api/admin/leads.csv`, `/api/admin/leads/{id}/messages`, `/api/admin/clients`, `/api/admin/sync`.

## Going live

1. Host `server.py` over HTTPS (any small VM or app host that keeps a disk). A site on HTTPS cannot call an HTTP backend.
2. Set `ADMIN_KEY`, `ALLOW_LOCALHOST=0`, and the database variables.
3. Put the script tag on each website.
4. Test each business with its real buyer questions. The bot hands over to a human when unsure, but rule-based parsing has limits: it can miss unusual phrasing, and it replies in English (it understands some Hinglish number words).

**Known limitations**
- The mobile number is format-checked (10 digits starting 6–9) but not verified by OTP, so fake numbers are possible. Add OTP before paying for follow-up calls if that matters.
- The same person chatting from two devices creates two lead rows with the same `phone_key`. This is deliberate: typing someone else's number never reveals their chat. Merge them in the database by `phone_key`.
- Visit reminders are not sent by this backend. Use the `qualification_complete` webhook event to trigger them from your own tooling.
- The previous single-business `palmgrove-chat` and the React `full-app` in your original zip are replaced by this version.
