import http.server
import json
import os
import sys
import tempfile
import threading

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest

# a fake "friend's database" API
RECEIVED = {"leads": [], "messages": []}
FAIL = {"on": False}


class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        if FAIL["on"]:
            self.send_response(503); self.end_headers(); return
        assert self.headers.get("Authorization") == "Bearer secret-key"
        RECEIVED["leads" if self.path == "/leads/upsert" else "messages"].append(body)
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b"{}")

    def do_GET(self):
        if self.path == "/clients/shree-heights":
            out = json.dumps({"pricing": {"published": True, "note": "", "inventory": [
                {"label": "2 BHK", "match": ["2 bhk", "2bhk"], "price_text": "₹68 lakh onwards", "area_text": "1,050 sq ft"}]}}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(out)
        else:
            self.send_response(404); self.end_headers()


@pytest.fixture(scope="module")
def app_client():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    d = tempfile.mkdtemp()
    os.environ.update(DB_PATH=os.path.join(d, "t.db"), DB_API_URL=f"http://127.0.0.1:{srv.server_port}", DB_API_KEY="secret-key",
                      ADMIN_KEY="adm", CONFIG_FROM_DB="1", CONFIG_TTL="0")
    import server
    from fastapi.testclient import TestClient
    with TestClient(server.app) as c:
        yield c, server
    srv.shutdown()


def start(c, client="shree-heights", name="Test Buyer", phone="98765 43210", origin=None, **kw):
    h = {"Origin": origin} if origin else {}
    return c.post("/api/session", json={"client_id": client, "name": name, "phone": phone, "consent": True, **kw}, headers=h)


def test_validation(app_client):
    c, _ = app_client
    assert start(c, phone="12345").status_code == 400
    assert start(c, phone="5876543210").status_code == 400
    assert start(c, name="").status_code == 400
    assert c.post("/api/session", json={"client_id": "shree-heights", "name": "A B", "phone": "9876543210", "consent": False}).status_code == 400
    assert start(c, client="nope").status_code == 404


def test_origin_rules(app_client):
    c, _ = app_client
    assert start(c, origin="https://shreeheights.com").status_code == 200
    assert start(c, origin="https://evil.example").status_code == 403                 # not this business's site
    assert start(c, client="vrindavan-greens", origin="https://shreeheights.com").status_code == 403   # another business's site
    r = c.get("/api/config/shree-heights", headers={"Origin": "https://shreeheights.com"})
    assert r.headers["access-control-allow-origin"] == "https://shreeheights.com"
    assert "access-control-allow-origin" not in c.get("/api/config/shree-heights", headers={"Origin": "https://evil.example"}).headers


def test_full_chat_and_database_sync(app_client):
    c, server = app_client
    RECEIVED["leads"].clear(); RECEIVED["messages"].clear()
    r = start(c, name="Rahul Sen", phone="+91 98765-43211", utm_source="google", utm_campaign="oct_launch").json()
    sid = r["session_id"]
    assert r["chips"][0]["id"].startswith("purpose:") and r["quick"]
    chat = lambda **k: c.post("/api/chat", json={"session_id": sid, **k}).json()
    chat(chip_id="purpose:live")
    out = chat(message="3 bhk about seventy lakhs")
    assert out["step"] == "location"
    # a pricing question is answered from the DATABASE config merged over the file
    out = chat(message="what is the price of a 2 bhk?")
    assert "₹68 lakh onwards" in "\n".join(out["messages"])
    server.flush_remote()
    lead = RECEIVED["leads"][-1]
    assert lead["name"] == "Rahul Sen" and lead["phone"] == "+919876543211" and lead["client_id"] == "shree-heights"
    assert lead["purpose"] == "To live in" and lead["budget_min_lakh"] == 70 and lead["budget_approx"] is True
    assert lead["source"] == "Google ad" and lead["utm_campaign"] == "oct_launch"
    assert "session_id" not in lead and "ctx" not in lead                 # internal fields never leave
    assert len({l["lead_id"] for l in RECEIVED["leads"]}) == 1            # same record updated, not a new one each time
    roles = [m["role"] for m in RECEIVED["messages"]]
    assert "lead" in roles and "bot" in roles
    # resume
    j = c.post("/api/resume", json={"session_id": sid}).json()
    assert j["transcript"] and j["chips"]


def test_remote_down_does_not_lose_leads(app_client):
    c, server = app_client
    RECEIVED["leads"].clear()
    FAIL["on"] = True
    sid = start(c, name="Offline Test", phone="9876543299").json()["session_id"]
    c.post("/api/chat", json={"session_id": sid, "chip_id": "purpose:investment"})
    server.flush_remote()
    assert not RECEIVED["leads"]                                          # remote refused
    assert server.store.outbox_stats()["pending"] > 0                     # but queued locally
    assert c.get("/api/admin/leads", headers={"X-Admin-Key": "adm"}).json()   # and visible locally
    FAIL["on"] = False
    with server.store.conn() as con:
        con.execute("UPDATE outbox SET next_try=0")
    server.flush_remote()
    assert any(l["name"] == "Offline Test" for l in RECEIVED["leads"])
    assert server.store.outbox_stats()["pending"] == 0


def test_admin_protected(app_client):
    c, _ = app_client
    assert c.get("/api/admin/leads").status_code == 403
    assert c.get("/api/admin/leads", headers={"X-Admin-Key": "wrong"}).status_code == 403
    assert c.get("/api/admin/leads.csv", headers={"X-Admin-Key": "adm"}).status_code == 200


def test_session_secret_not_guessable_by_phone(app_client):
    c, _ = app_client
    a = start(c, phone="9000000001").json()
    b = start(c, phone="9000000001").json()
    assert a["session_id"] != b["session_id"] and "transcript" not in b      # same phone does not reveal the earlier chat
    assert c.post("/api/chat", json={"session_id": "bogus", "message": "hi"}).status_code == 404


def test_widget_and_demo_served(app_client):
    c, _ = app_client
    assert "data-client" in c.get("/widget.js").text
    assert c.get("/demo").status_code == 200 and c.get("/health").json() == {"ok": True}
