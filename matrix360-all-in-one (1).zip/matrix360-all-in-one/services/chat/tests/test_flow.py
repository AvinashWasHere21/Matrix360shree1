import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import engine as E
import schema

ROOT = os.path.join(os.path.dirname(__file__), "..", "clients")


def cfg(name):
    return json.load(open(os.path.join(ROOT, name + ".json"), encoding="utf-8"))


def new(c):
    lead = schema.blank()
    lead.update(lead_id="L1", client_id=c["id"], name="Avinash Rao", phone="+919876543210", phone_key="9876543210")
    return lead


class Chat:
    def __init__(self, name):
        self.c = cfg(name)
        self.lead = new(self.c)
        self.r = E.start(self.lead, self.c)
        self.events = list(self.r["events"])

    def say(self, text=None, chip=None):
        self.r = E.handle(self.lead, self.c, text or "", chip)
        self.events += self.r["events"]
        return self

    @property
    def text(self):
        return "\n".join(self.r["messages"])

    def chips(self):
        return [c["id"] for c in self.r["chips"]]


def test_flat_full_flow_with_chips():
    ch = Chat("shree-heights")
    assert ch.lead["property_type"] == "flat"            # single-type business: question 1 is skipped
    assert ch.r["step"] == "purpose"
    assert "purpose:live" in ch.chips() and "purpose:unsure" in ch.chips()
    ch.say(chip="purpose:live")
    assert ch.r["step"] == "size" and "size:2bhk" in ch.chips()
    ch.say(chip="size:3bhk")
    assert ch.r["step"] == "location"
    ch.say(chip="location:chandannagar")
    assert ch.r["step"] == "budget"
    ch.say("about seventy lakhs")
    assert ch.lead["budget_min_lakh"] == 70 and ch.lead["budget_approx"] is True
    assert ch.r["step"] == "timeline"
    ch.say(chip="timeline:1_3")
    ch.say(chip="role:decision_maker")
    assert ch.r["step"] == "features"
    ch.say(chip="features:parking")
    assert ch.r["step"] == "features" and "features:parking" not in ch.chips()   # multi-select stays on the question
    ch.say(chip="features:gym")
    ch.say(chip="features:done")
    assert ch.lead["features"] == ["MLCP parking", "Gym"]
    assert ch.r["step"] == "consult"
    ch.say(chip="consult:visit")
    assert ch.r["step"] == "visit_when"
    date_chip = [c for c in ch.chips() if c.startswith("visit_when:d:")][0]
    ch.say(chip=date_chip)
    assert ch.r["step"] == "visit_when" and any(c.startswith("visit_time:") for c in ch.chips())
    ch.say(chip="visit_time:morning")
    assert "Morning" in ch.lead["visit_pref"]
    assert ch.r["step"] == "channel"
    ch.say(chip="channel:whatsapp")
    ch.say(chip="contact_time:evening")
    assert ch.r["step"] == "permission"
    assert ch.lead["followup_consent"] is None            # never assumed
    ch.say(chip="permission:yes")
    assert ch.r["step"] is None
    assert ch.lead["followup_consent"] is True and ch.lead["stage"] == "Qualified"
    assert "qualification_complete" in ch.events
    assert "Not shared yet" not in ch.text or "Budget" not in ch.text.split("Not shared yet")[-1]
    assert "request, not a confirmed booking" in ch.text


def test_everything_in_one_message_skips_known_questions():
    ch = Chat("shree-heights")
    ch.say("looking for a 2 bhk under 80 lakhs, want to buy in 3 months, for investment")
    L = ch.lead
    assert L["size_label"] == "2 bhk" or "2" in L["size_label"]
    assert L["budget_max_lakh"] == 80 and L["budget_min_lakh"] is None
    assert L["timeline"] == "1_3"
    assert L["purpose"] == "Investment"
    assert ch.r["step"] == "location"                     # next unknown, in script order


def test_outlier_budgets_in_flow():
    for text, lo, hi in [("approx seventy five lakhs", 75, 75), ("1 cr 20 lakh", 120, 120), ("sixty to seventy lac", 60, 70),
                         ("dedh crore", 150, 150), ("75,00,000", 75, 75)]:
        ch = Chat("shree-heights")
        ch.lead["awaiting"] = "budget"
        ch.say(text)
        assert (ch.lead["budget_min_lakh"], ch.lead["budget_max_lakh"]) == (lo, hi), text


def test_ambiguous_budget_asks_lakh_or_crore():
    ch = Chat("vrindavan-greens")
    ch.lead["awaiting"] = "budget"
    ch.say("2")
    assert ch.chips()[:2] == ["budget_unit:lakh", "budget_unit:crore"]
    assert ch.lead["budget_label"] is None
    ch.say(chip="budget_unit:crore")
    assert ch.lead["budget_min_lakh"] == 200


def test_prefer_not_to_say_budget_is_ok():
    ch = Chat("shree-heights")
    ch.say(chip="purpose:live").say(chip="size:2bhk").say(chip="location:chandannagar")
    ch.say(chip="budget:unsure")
    assert "budget" in ch.lead["unknown_fields"] and ch.lead["budget_label"] is None
    assert ch.r["step"] == "timeline"                     # moved on, not rejected
    ch.say("prefer not to say").r  # harmless


def test_questions_do_not_derail_and_use_config_only():
    ch = Chat("shree-heights")
    ch.say("do you have a swimming pool?")
    assert "team member needs to confirm" in ch.text and "swimming" not in ch.lead["features"]
    assert ch.r["step"] == "purpose"                       # question re-asked
    ch.say("Is there parking?")
    assert "MLCP parking" in ch.text
    ch.say("how far is the railway station")
    assert "1.5 km" in ch.text
    ch.say("what is the price of a 3 bhk?")
    assert "yet to be decided" in ch.text and "₹" not in ch.text
    ch.say("is it RERA registered, what is the registration number?")
    assert "does not show the registration number" in ch.text
    ch.say("can I get a discount?")
    assert "team member needs to confirm" in ch.text
    assert ch.lead["open_questions"]


def test_unconfigured_business_never_invents():
    ch = Chat("lakhotia-industrial")
    assert ch.lead["property_type"] == "industrial"
    ch.say("where exactly is the complex?")
    assert "team member needs to confirm" in ch.text
    ch.say("do you have 3 phase power and truck access?")
    assert "team member needs to confirm" in ch.text
    ch.say("what are the rates per sq ft?")
    assert "team member needs to share" in ch.text
    ch.say("is the land title clear and is it approved?")
    assert "team member needs to confirm" in ch.text
    assert len(ch.lead["open_questions"]) >= 3


def test_features_step_without_verified_amenities_only_records_requirements():
    ch = Chat("lakhotia-industrial")
    ch.lead["awaiting"] = "features"
    assert "features:power" in ch.say(chip="size:s1").chips() or True
    ch2 = Chat("lakhotia-industrial")
    ch2.lead.update(purpose="Warehouse", size_label="x", location_pref="x", budget_label="x", timeline="1_3", role="helping")
    ch2.say("hello")
    assert ch2.r["step"] == "features"
    assert "team" in ch2.text and "confirm" in ch2.text and "features:power" in ch2.chips()


def test_human_handoff_asks_permission_first():
    ch = Chat("vrindavan-greens")
    ch.say(chip="q:human")
    assert "handoff_requested" in ch.events
    assert ch.lead["handoff_requested"] and ch.lead["followup_consent"] is None
    assert ch.chips() == ["permission:yes", "permission:no"]
    ch.say(chip="permission:no")
    assert ch.lead["followup_consent"] is False and "handoff_consent" in ch.events
    assert "not to contact you outside this chat" in ch.text


def test_typed_human_request():
    ch = Chat("shree-heights")
    ch.say("I want to talk to a real person")
    assert ch.lead["handoff_requested"]


def test_visit_intent_jumps_to_visit_question():
    ch = Chat("vrindavan-greens")
    ch.say("I would like to book a site visit")
    assert ch.lead["consult_type"] == "visit" and ch.r["step"] == "visit_when"
    ch.say("saturday afternoon")
    assert "Afternoon" in ch.lead["visit_pref"]
    assert ch.r["step"] == "purpose"                       # then back to the script


def test_unsure_answers_are_recorded_as_unknown():
    ch = Chat("vrindavan-greens")
    ch.say("not sure yet")
    assert "purpose" in ch.lead["unknown_fields"] and ch.r["step"] == "size"


def test_edit_answer():
    ch = Chat("shree-heights")
    ch.say(chip="purpose:live")
    ch.say(chip="edit")
    assert "edit:purpose" in ch.chips()
    ch.say(chip="edit:purpose")
    assert ch.lead["purpose"] is None and ch.r["step"] == "purpose"


def test_email_channel_collects_email():
    ch = Chat("shree-heights")
    ch.lead.update(purpose="x", size_label="x", location_pref="x", budget_label="x", timeline="asap", role="helping",
                   consult_type="none")
    ch.lead["ctx"]["features_done"] = True
    ch.say("hi")
    assert ch.r["step"] == "channel"
    ch.say(chip="channel:email")
    assert ch.r["step"] == "email"
    ch.say("not an email")
    assert ch.r["step"] == "email"
    ch.say("me@example.com")
    assert ch.lead["email"] == "me@example.com" and ch.r["step"] == "contact_time"


def test_summary_and_scoring():
    ch = Chat("shree-heights")
    ch.say("2 bhk, about 70 lakhs, within a month, I'm the decision maker")
    assert ch.lead["score"] in ("Warm", "Hot")
    ch.say("summary please")
    assert "Known" in ch.text or "Here's what I have" in ch.text
