# Shree Heights — website

Marketing website for **Shree Heights**, gated 2 & 3 BHK homes in North Bagbazar, Chandannagar.

**Stack:** React 19 · React Router · Motion (Framer Motion) · Vite · plain CSS design system.

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build → dist/
npm run preview   # serve the production build
```

## Landing pages for ads & CTAs

Every page has its own URL, so an ad can open the right page directly — the headline, CTA and price are in the first screen.

| Creative / CTA | URL |
| --- | --- |
| "Come home to Chandannagar" | `/` |
| "Why have Chandannagar professionals chosen Shree Heights?" | `/why-shree-heights` |
| "জলের মতো শান্ত জীবন" — serene living | `/serene-living` |
| "প্রতিটি সকাল নতুন সম্ভাবনার" — mornings / wellness | `/mornings` |
| "ছোট থেকে বড় হওয়া" — families / growing up | `/growing-up` |
| 2 & 3 BHK, price, plans, availability, specs | `/residences` |
| Amenities | `/amenities` |
| Gallery | `/gallery` |
| 360° / virtual tour | `/virtual-tour` |
| Location & map | `/location` |
| Developers | `/developers` |
| Contact & enquiry | `/contact` |
| **Book a site visit** | `/site-visit` |
| Broker / referral partners | `/partners` |

**Tracking:** every "Book a site visit" button adds `?from=<page>`, and the first `utm_*`, `gclid` or `fbclid`
values of a session are remembered. Both are attached to the enquiry, so you can see which ad produced the lead.
Example ad link: `https://shreeheights.com/mornings?utm_source=facebook&utm_campaign=mornings`.
`/site-visit?config=3bhk` pre-selects 3 BHK on the form.

## Things to fill in

All in `src/data/site.js` unless noted:

- **Lead capture** — `FORM_ENDPOINT`. Set it to a form backend (Formspree, Google Apps Script, a CRM webhook) to
  receive JSON. While it is empty, forms open WhatsApp with the details pre-filled to `CONTACT.whatsapp`.
- **Availability** — edit `public/availability.json` (no rebuild needed). Until real numbers are entered the
  tracker shows "ask our team" rather than figures.
- **Brochure** — put the PDF in `public/` and set `BROCHURE_URL`.
- **Floor plans** — the published plans (master, first floor, Tower 1, Tower 2, 5th–12th) are in `src/assets/plans/`;
  unit carpet / balcony / built-up / chargeable areas are in `UNITS`. Update both if the drawings change.
- **360° tour** — add 2:1 equirectangular images to `TOUR_SCENES` with `loop: true` (they spin seamlessly).
- **RERA** — `CONTACT.rera` links to the certificate on the current site; copy the PDF into `public/` before
  switching domains.

## Broker / referral partner form (`/partners`)

Collects partner details (name, firm, phone, email, LinkedIn), whether they are registering or submitting a lead,
lead details with explicit "Unknown" marking, property type, reason, evidence link and referral ID, and the
prospect's consent (answer, method and date — scoped to this enquiry only; leads without consent are refused).

- **Partner approval is internal only.** The public form never sends an approval field; your backend/CRM must set
  approval itself and ignore any approval value arriving from the browser.
- **No commission logic.** Commission terms, percentages, eligibility and payments are intentionally not
  implemented — add them only from approved business rules.

## Deploying

Any static host works; the router needs unknown paths to fall back to `index.html`:

- **Vercel** — import the repo; `vercel.json` handles the rewrite.
- **Netlify** — build `npm run build`, publish `dist`; `public/_redirects` handles the rewrite.

Social previews use `index.html` defaults plus per-page titles; images live in `public/og/`.
Images are cropped from the campaign creatives and are artistic impressions.
