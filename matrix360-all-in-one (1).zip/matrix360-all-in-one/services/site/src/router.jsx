import { createBrowserRouter } from 'react-router';
import Layout from './components/Layout.jsx';
import Home from './pages/Home.jsx';
import WhyShreeHeights from './pages/WhyShreeHeights.jsx';
import SereneLiving from './pages/SereneLiving.jsx';
import Mornings from './pages/Mornings.jsx';
import GrowingUp from './pages/GrowingUp.jsx';
import Residences from './pages/Residences.jsx';
import Amenities from './pages/Amenities.jsx';
import GalleryPage from './pages/Gallery.jsx';
import VirtualTour from './pages/VirtualTour.jsx';
import Location from './pages/Location.jsx';
import Developers from './pages/Developers.jsx';
import Contact from './pages/Contact.jsx';
import SiteVisit from './pages/SiteVisit.jsx';
import Partners from './pages/Partners.jsx';
import NotFound from './pages/NotFound.jsx';

// Every campaign creative links straight to one of these URLs.
export const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: 'why-shree-heights', element: <WhyShreeHeights /> },
      { path: 'serene-living', element: <SereneLiving /> },
      { path: 'mornings', element: <Mornings /> },
      { path: 'growing-up', element: <GrowingUp /> },
      { path: 'residences', element: <Residences /> },
      { path: 'amenities', element: <Amenities /> },
      { path: 'gallery', element: <GalleryPage /> },
      { path: 'virtual-tour', element: <VirtualTour /> },
      { path: 'location', element: <Location /> },
      { path: 'developers', element: <Developers /> },
      { path: 'contact', element: <Contact /> },
      { path: 'site-visit', element: <SiteVisit /> },
      { path: 'partners', element: <Partners /> },
      { path: '*', element: <NotFound /> },
    ],
  },
]);
