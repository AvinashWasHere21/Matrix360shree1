import { useSearchParams } from 'react-router';
import LeadForm from '../components/LeadForm.jsx';
import { Fade, MaskedLines } from '../components/Motion.jsx';
import { CONTACT, FROM_COPY, whatsappLink } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const STEPS = [
  { title: 'Pick a day', text: 'Choose a date and time of day that suits you.' },
  { title: 'We confirm', text: 'Our team calls or messages you to lock in the slot.' },
  { title: 'Walk the site', text: 'See the homes, the podium and the neighbourhood with our team.' },
];

export default function SiteVisit() {
  const [params] = useSearchParams();
  const context = FROM_COPY[params.get('from')] || 'See the homes, the amenities and the neighbourhood for yourself — free, with no obligation.';
  usePageMeta({
    title: 'Book a Site Visit · Shree Heights, Chandannagar',
    description: 'Book a free site visit to Shree Heights — 2 & 3 BHK homes in Chandannagar from ₹70 Lakhs. Pick a date and our team will confirm.',
  });

  return (
    <section className="hero visit-hero">
      <div className="container hero__grid hero__grid--top">
        <div className="hero__copy">
          <Fade delay={0.05}><span className="eyebrow">Free site visit</span></Fade>
          <MaskedLines className="h1 h1--md" lines={['Book a', <em key="v">site visit.</em>]} />
          <Fade as="p" className="lead" delay={0.4}>{context}</Fade>
          <Fade as="ol" className="steps" delay={0.5}>
            {STEPS.map((s) => <li key={s.title}><span><strong>{s.title}</strong><span>{s.text}</span></span></li>)}
          </Fade>
          <Fade className="form__alt" delay={0.6}>
            <span>Prefer to talk?</span>
            <a href={CONTACT.office.href}>{CONTACT.office.label}</a>
            <a href={CONTACT.mobile.href}>{CONTACT.mobile.label}</a>
            <a href={whatsappLink('Hello Shree Heights, I’d like to book a site visit.')} target="_blank" rel="noopener noreferrer">WhatsApp</a>
          </Fade>
        </div>
        <Fade className="form-card" delay={0.25}>
          <div className="form-card__core">
            <LeadForm kind="visit" title="Your visit" intro="Takes under a minute. Only name and mobile are required." />
          </div>
        </Fade>
      </div>
    </section>
  );
}
