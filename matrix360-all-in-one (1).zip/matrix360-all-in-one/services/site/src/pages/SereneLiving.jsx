import Button, { VisitButton } from '../components/Button.jsx';
import Icon from '../components/Icon.jsx';
import { CountUp, Fade, MaskedLines, Parallax, Reveal, useInViewClass } from '../components/Motion.jsx';
import { IMG, RENDERS } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const EVENING = [
  { time: '5:30', ampm: 'pm', title: 'Tea on the balcony', text: 'Decorative glass railings frame uninterrupted green views.' },
  { time: '6:00', ampm: 'pm', title: 'A walk by the water', text: 'Landscaped greens and a calm water body on the podium.' },
  { time: '6:30', ampm: 'pm', title: 'The Strand at dusk', text: 'Chandannagar’s riverside promenade is just 600 m away.' },
  { time: '7:15', ampm: 'pm', title: 'Neighbours on the lawn', text: 'The party lawn and community hall bring everyone together.' },
  { time: '8:30', ampm: 'pm', title: 'Quiet, by design', text: 'A gated community with 24×7 security keeps evenings unhurried.' },
];

const NEARBY = [
  { value: '11', unit: 'm', label: 'to the Chandannagar Heritage Museum' },
  { value: '600', unit: 'm', label: 'to the Strand on the Hooghly' },
  { value: '750', unit: 'm', label: 'to the Chandannagar Ferry Ghat' },
];

export default function SereneLiving() {
  const [timelineRef, timelineIn] = useInViewClass();
  usePageMeta({
    title: 'জলের মতো শান্ত জীবন · Serene living at Shree Heights',
    description: 'Where life finds its quieter rhythm — landscaped greens and water inside the gate, the Strand 600 m away. Book a site visit to Shree Heights, Chandannagar.',
    image: '/og/serene.jpg',
  });

  return (
    <>
      <section className="hero hero--immersive serene-hero">
        <div className="hero__bg">
          <div className="media-settle">
            <img src={IMG.lakeside} alt="A couple watching the sunset over the water at Shree Heights" width="956" height="749" fetchPriority="high" />
          </div>
        </div>
        <div className="container">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow eyebrow--light">Serene living</span></Fade>
            <MaskedLines className="h1 bn" lang="bn" lines={['জলের মতো', 'শান্ত জীবন।']} />
            <Fade as="p" className="lead--serif" delay={0.45}>Where life finds its quieter rhythm.</Fade>
            <Fade className="hero__ctas" delay={0.55}>
              <VisitButton from="serene" variant="light">Book a site visit</VisitButton>
              <Button to="/amenities" variant="outline-light">Explore amenities</Button>
            </Fade>
            <Fade className="fact-row" delay={0.7}>
              <span className="fact"><Icon name="water" />Greens &amp; water inside the gate</span>
              <span className="fact"><Icon name="pin" />600 m to the Strand</span>
            </Fade>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container split split--wide-left">
          <Reveal as="p" className="statement">
            Take a break from the fast pace — <em>a few moments by the greenery and water,</em>{' '}
            <span className="soft">every single day.</span>
          </Reveal>
          <Reveal className="stack" delay={0.1}>
            <p className="body-lg">
              At Shree Heights, serene nature balances your busy days. Landscaped podium greens, a calm water body and
              open lawns sit within the gate, while Chandannagar’s riverside Strand and heritage lanes are a short walk away.
            </p>
            <VisitButton from="serene" variant="ghost">Visit at golden hour</VisitButton>
          </Reveal>
        </div>
      </section>

      <section className="section section--sand">
        <div className="container">
          <Reveal className="section-head">
            <span className="eyebrow eyebrow--gold">An evening at Shree Heights</span>
            <h2 className="h2">Let the day <em>slow down.</em></h2>
          </Reveal>
          <ol className={`timeline ${timelineIn}`.trim()} ref={timelineRef}>
            {EVENING.map((item, i) => (
              <Reveal as="li" className="timeline__item" key={item.time} delay={0.15 + i * 0.12}>
                <span className="timeline__time">{item.time}<small>{item.ampm}</small></span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="section section--night">
        <div className="container split">
          <Reveal className="frame frame--dark">
            <div className="frame__core" style={{ aspectRatio: '4 / 3.4' }}>
              <Parallax src={RENDERS.waterBody} alt="The water body and landscaped greens at Shree Heights" style={{ height: '100%' }} loading="lazy" />
            </div>
          </Reveal>
          <div className="stack">
            <Reveal className="stack">
              <span className="eyebrow eyebrow--light">Beyond the gate</span>
              <h2 className="h2">Close to the river, <em>close to history.</em></h2>
              <p>Live in the picturesque heritage town of Chandannagar — its museum, its Strand and its ghats are part of your everyday walk.</p>
            </Reveal>
            <div className="stats stats--rows">
              {NEARBY.map((s, i) => (
                <Reveal className="stat" key={s.label} delay={i * 0.08}>
                  <span className="stat__value"><CountUp value={s.value} /><small>{s.unit}</small></span>
                  <span className="stat__label">{s.label}</span>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
