import Button, { VisitButton } from '../components/Button.jsx';
import Icon from '../components/Icon.jsx';
import { Fade, Magnetic, MaskedLines, Parallax, Reveal } from '../components/Motion.jsx';
import { IMG, RENDERS } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const JOURNEY = [
  { stage: 'First steps', place: 'Kids’ play arena', dist: '0', unit: 'km — inside the gate', text: 'Safe, green play space where children make their first friends.' },
  { stage: 'School days', place: 'St. Thomas School', dist: '500', unit: 'm', text: 'Two minutes from home — the school run becomes a stroll.' },
  { stage: 'Growing years', place: 'St. Joseph’s Convent', dist: '1.1', unit: 'km', text: 'With Modern Public School 2.1 km away, the choice stays close.' },
  { stage: 'First degree', place: 'Chandernagore College', dist: '800', unit: 'm', text: 'Higher studies without leaving home — or the family.' },
];

const COMMUNITY = [
  { icon: 'shield', title: 'Gated, with 24×7 security', text: 'CCTV at the ground-floor lobby and a secure perimeter, so children can roam the podium freely.' },
  { icon: 'hall', title: 'Pujo, birthdays & everything between', text: 'A community hall and party lawn for the celebrations that shape childhood memories.' },
  { icon: 'people', title: 'Grandparents, a room away', text: '3 BHK homes leave space for the whole family to live together.' },
];

export default function GrowingUp() {
  usePageMeta({
    title: 'ছোট থেকে বড় হওয়া · Growing up at Shree Heights',
    description: 'Growing up, without growing away — a play arena inside the gate and schools and a college within 2 km. Book a family site visit to Shree Heights, Chandannagar.',
    image: '/og/growing-up.jpg',
  });

  return (
    <>
      <section className="hero growing-hero">
        <div className="container hero__grid">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">For families</span></Fade>
            <MaskedLines className="h1 bn" lang="bn" lines={['ছোট থেকে', 'বড় হওয়া।']} />
            <Fade as="p" className="lead--serif" delay={0.45}>Growing up, without growing away.</Fade>
            <Fade as="p" className="lead" delay={0.52}>
              From first steps to first degree — play, school and college are all within 2 km of home.
            </Fade>
            <Fade className="hero__ctas" delay={0.62}>
              <Magnetic><VisitButton from="growing-up" sub="bring the whole family.">Book a site visit</VisitButton></Magnetic>
              <Button to="/residences" variant="ghost">2 &amp; 3 BHK homes</Button>
            </Fade>
          </div>

          <div className="hero__media hero__media--tilt">
            <div className="frame">
              <div className="frame__core">
                <div className="media-settle">
                  <img src={IMG.playGarden} alt="Children playing in the Shree Heights play arena" width="900" height="759" fetchPriority="high" />
                </div>
              </div>
            </div>
            <div className="chip chip--tl" style={{ '--i': 0 }}>
              <span className="chip__icon chip__icon--gold"><Icon name="slide" /></span>
              <span><strong>Kids’ play arena</strong>Inside the gate</span>
            </div>
            <div className="chip chip--br" style={{ '--i': 1 }}>
              <span className="chip__icon"><Icon name="school" /></span>
              <span><strong>500 m</strong>to St. Thomas School</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--paper">
        <div className="container">
          <Reveal className="section-head section-head--center">
            <span className="eyebrow eyebrow--gold">A childhood, mapped</span>
            <h2 className="h2">From first steps <em>to first degree.</em></h2>
            <p>Every stage of growing up, within a short walk or a quick drive of home.</p>
          </Reveal>
          <ol className="journey">
            {JOURNEY.map((j, i) => (
              <Reveal as="li" className="journey__step" key={j.place} delay={i * 0.1}>
                <span className="journey__stage">{j.stage}</span>
                <span className="journey__dist">{j.dist}<small>{j.unit}</small></span>
                <h3>{j.place}</h3>
                <p>{j.text}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="section">
        <div className="container split">
          <Reveal className="frame">
            <div className="frame__core" style={{ aspectRatio: '4 / 3.2' }}>
              <Parallax src={RENDERS.kidsPlayArea} alt="The kids’ play arena at Shree Heights" style={{ height: '100%' }} loading="lazy" />
            </div>
          </Reveal>
          <div className="stack">
            <Reveal className="stack">
              <span className="eyebrow">A community that raises them</span>
              <h2 className="h2">Safe to roam. <em>Easy to belong.</em></h2>
            </Reveal>
            <ul className="status" style={{ justifySelf: 'stretch' }}>
              {COMMUNITY.map((c, i) => (
                <Reveal as="li" key={c.title} delay={0.1 + i * 0.08}>
                  <span className="status__mark status__mark--wip"><Icon name={c.icon} /></span>
                  <span><strong>{c.title}</strong>{c.text}</span>
                </Reveal>
              ))}
            </ul>
            <Reveal delay={0.3}><VisitButton from="growing-up">Bring the family to visit</VisitButton></Reveal>
          </div>
        </div>
      </section>
    </>
  );
}
