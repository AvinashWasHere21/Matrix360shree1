import Button, { VisitButton } from '../components/Button.jsx';
import AmenityGrid from '../components/AmenityGrid.jsx';
import Icon from '../components/Icon.jsx';
import { Fade, MaskedLines, Reveal, useInViewClass } from '../components/Motion.jsx';
import { AMENITIES, IMG } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const MORNING = [
  { time: '6:00', ampm: 'am', title: 'Sunrise on the yoga deck', text: 'Breathe with the first light on the open-air deck.' },
  { time: '6:45', ampm: 'am', title: 'A workout at the gym', text: 'No traffic between you and your training.' },
  { time: '7:30', ampm: 'am', title: 'A game of badminton', text: 'Neighbours make the best doubles partners.' },
  { time: '8:15', ampm: 'am', title: 'The school run', text: 'St. Thomas School is just 500 m from the gate.' },
  { time: '9:00', ampm: 'am', title: 'Off to work', text: 'Chandannagar Railway Station is five minutes away.' },
];

const WELLNESS = AMENITIES.filter((a) => a.group === 'wellness' || a.group === 'leisure');

export default function Mornings() {
  const [timelineRef, timelineIn] = useInViewClass();
  usePageMeta({
    title: 'প্রতিটি সকাল নতুন সম্ভাবনার · Mornings at Shree Heights',
    description: 'Every morning begins with possibility — a yoga deck, gym and badminton court at home, the school and station minutes away. Book a site visit.',
    image: '/og/mornings.jpg',
  });

  return (
    <>
      <section className="hero hero--panorama mornings-hero">
        <div className="hero__sun" aria-hidden="true" />
        <div className="container hero__top" style={{ position: 'relative', zIndex: 1 }}>
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">Wellness &amp; mornings</span></Fade>
            <MaskedLines className="h1 bn" lang="bn" lines={['প্রতিটি সকাল', 'নতুন সম্ভাবনার।']} />
            <Fade as="p" className="lead--serif" delay={0.45}>Every morning begins with possibility.</Fade>
          </div>
          <Fade className="stack" delay={0.55}>
            <p className="body-lg">
              Start the day on the yoga deck, fit in a workout and still make the 9 o’clock train. At Shree Heights the
              good habits are on your doorstep.
            </p>
            <div className="hero__ctas">
              <VisitButton from="mornings">Book a site visit</VisitButton>
              <Button to="/amenities" variant="ghost">All amenities</Button>
            </div>
          </Fade>
        </div>
        <Fade className="hero__band" delay={0.3}>
          <div className="media-settle">
            <img src={IMG.yogaDeck} alt="Residents practising pranayama on the Shree Heights yoga deck at sunrise" width="1536" height="604" fetchPriority="high" />
          </div>
        </Fade>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head section-head--split">
            <Reveal className="stack">
              <span className="eyebrow eyebrow--gold">Morning, mapped</span>
              <h2 className="h2">Three hours, <em>five good things.</em></h2>
            </Reveal>
            <Reveal as="p" delay={0.1}>
              When the yoga deck, the gym, the court, the school and the station are all this close, mornings stop being a rush.
            </Reveal>
          </div>
          <ol className={`timeline ${timelineIn}`.trim()} ref={timelineRef}>
            {MORNING.map((item, i) => (
              <Reveal as="li" className="timeline__item" key={item.time} delay={0.15 + i * 0.12}>
                <span className="timeline__time">{item.time}<small>{item.ampm}</small></span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="section section--paper">
        <div className="container">
          <div className="section-head section-head--split">
            <Reveal className="stack">
              <span className="eyebrow">Inside the gate</span>
              <h2 className="h2">Spaces that <em>keep you well.</em></h2>
            </Reveal>
            <Reveal className="stack stack--sm" delay={0.1}>
              <p>Move, play, gather and celebrate — every amenity is a few steps from your front door.</p>
              <span className="fact" style={{ marginTop: 0 }}><Icon name="lotus" />Yoga deck · Gym · Badminton court</span>
            </Reveal>
          </div>
          <AmenityGrid items={WELLNESS} />
        </div>
      </section>
    </>
  );
}
