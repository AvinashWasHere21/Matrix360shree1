import { VisitButton } from '../components/Button.jsx';
import Gallery from '../components/Gallery.jsx';
import { Fade, MaskedLines } from '../components/Motion.jsx';
import { usePageMeta } from '../lib/usePageMeta.js';

export default function GalleryPage() {
  usePageMeta({
    title: 'Gallery · Shree Heights, Chandannagar',
    description: 'Explore Shree Heights — the towers, the yoga deck, the water-side deck, the kids’ play arena and life in the community.',
  });
  return (
    <section className="page-hero">
      <div className="container">
        <div className="section-head section-head--split" style={{ marginBottom: 36 }}>
          <div className="stack">
            <Fade delay={0.05}><span className="eyebrow">Gallery</span></Fade>
            <MaskedLines className="h1 h1--md" lines={['A closer look', <em key="g">at Shree Heights.</em>]} />
          </div>
          <Fade className="stack stack--sm" delay={0.45}>
            <p className="body-lg">The towers, the amenities and the everyday moments that make this community home. Tap any image to open it.</p>
            <VisitButton from="gallery">See it in person</VisitButton>
          </Fade>
        </div>
        <Fade delay={0.5}><Gallery /></Fade>
        <p className="small muted" style={{ marginTop: 24 }}>Renders are artistic impressions for representation only. Construction images are actual site photographs.</p>
      </div>
    </section>
  );
}
