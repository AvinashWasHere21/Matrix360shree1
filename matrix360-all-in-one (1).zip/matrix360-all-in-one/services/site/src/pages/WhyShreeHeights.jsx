import Button, { VisitButton } from '../components/Button.jsx';
import AmenityGrid from '../components/AmenityGrid.jsx';
import Icon from '../components/Icon.jsx';
import PriceCard from '../components/PriceCard.jsx';
import { Fade, Magnetic, MaskedLines, Reveal } from '../components/Motion.jsx';
import { AMENITIES, IMG } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const REASONS = [
  {
    title: 'Your commute starts closer to home',
    text: 'Chandannagar Railway Station is 1.5 km away — about five minutes — and Chuchura station is 4.3 km out. Less time getting to the platform, more time for everything else.',
    icon: 'train',
    fact: '1.5 km · 5 min to the station',
  },
  {
    title: 'Care, two minutes away',
    text: 'The Sub-Divisional Hospital is 500 m from the gate — a short drive for doctors on call, and quiet reassurance for every family.',
    icon: 'hospital',
    fact: '500 m · Sub-Divisional Hospital',
  },
  {
    title: 'Schools and a college within 2 km',
    text: 'St. Thomas School (500 m), Chandernagore College (800 m), St. Joseph’s Convent (1.1 km) and Modern Public School (2.1 km). The school run takes minutes, not mornings.',
    icon: 'school',
    fact: '4 institutions within 2.1 km',
  },
  {
    title: 'Specifications you’d choose yourself',
    text: 'Jaquar-or-equivalent fittings, an Italian-marble ground-floor lobby, vitrified floors, concealed copper wiring and AC points in every bedroom and living room.',
    icon: 'sparkle',
    fact: 'Jaquar fittings · Italian marble lobby',
  },
  {
    title: 'Security that’s built in',
    text: 'A gated community with 24×7 security, CCTV at the ground-floor lobby, fire-fighting provisions and multi-level car parking.',
    icon: 'shield',
    fact: 'Gated · 24×7 security',
  },
  {
    title: 'A track record, not just a promise',
    text: 'Developed by Dream Royally LLP with JP Group (since 1985) and Bhawani Group (since 1989). The structure is already almost complete — see it before you decide.',
    icon: 'building',
    fact: 'Structurally almost complete',
  },
];

const AFTER_HOURS = ['Gymnasium', 'Badminton court', 'Games room', 'Community hall'];

export default function WhyShreeHeights() {
  usePageMeta({
    title: 'Why Chandannagar’s professionals choose Shree Heights',
    description: 'Five minutes to the station, two to the hospital, schools within 2 km and specifications you’d choose yourself. Book a site visit to discover why.',
    image: '/og/professionals.jpg',
  });

  return (
    <>
      <section className="hero why-hero">
        <div className="container hero__grid">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">For Chandannagar’s professionals</span></Fade>
            <MaskedLines
              className="h1 h1--sm"
              lines={['Why have Chandannagar', 'professionals chosen', <em key="s">Shree Heights?</em>]}
            />
            <Fade as="p" className="lead" delay={0.5}>
              Doctors, lawyers, bankers and teachers are choosing a home that gives them time back — and a
              neighbourhood they’re proud to come home to.
            </Fade>
            <Fade className="hero__ctas" delay={0.6}>
              <Magnetic><VisitButton from="professionals" sub="to discover why.">Book a site visit</VisitButton></Magnetic>
              <Button href="#reasons" variant="ghost" icon="chevron">Six reasons</Button>
            </Fade>
            <Fade className="hero__meta" delay={0.7}><PriceCard inline /></Fade>
          </div>

          <div className="hero__media">
            <div className="frame">
              <div className="frame__core">
                <div className="media-settle">
                  <img src={IMG.professionals} alt="A doctor, a lawyer and a banker in front of Shree Heights" width="910" height="631" fetchPriority="high" />
                </div>
              </div>
            </div>
            <div className="chip chip--tl" style={{ '--i': 0 }}>
              <span className="chip__icon"><Icon name="hospital" /></span>
              <span><strong>500 m</strong>to the Sub-Divisional Hospital</span>
            </div>
            <div className="chip chip--br" style={{ '--i': 1 }}>
              <span className="chip__icon chip__icon--gold"><Icon name="train" /></span>
              <span><strong>5 minutes</strong>to Chandannagar Station</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--paper" id="reasons">
        <div className="container reasons">
          <Reveal className="reasons__intro">
            <span className="eyebrow">The reasons</span>
            <h2 className="h2">Six reasons, <em>one address.</em></h2>
            <p className="body-lg">
              Professional life runs on time, trust and peace of mind. Here’s how Shree Heights gives you more of all three.
            </p>
            <VisitButton from="professionals">See it for yourself</VisitButton>
          </Reveal>
          <ol className="reasons__list">
            {REASONS.map((r, i) => (
              <Reveal as="li" className="reason" key={r.title} delay={0.05}>
                <span className="reason__num">{String(i + 1).padStart(2, '0')}</span>
                <h3 className="h3">{r.title}</h3>
                <p>{r.text}</p>
                <span className="fact"><Icon name={r.icon} />{r.fact}</span>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="section section--night">
        <div className="container">
          <div className="section-head section-head--split">
            <Reveal className="stack">
              <span className="eyebrow eyebrow--light">After hours</span>
              <h2 className="h2">Unwind <em>without leaving home.</em></h2>
            </Reveal>
            <Reveal as="p" delay={0.1}>
              A workout before the first appointment, a game of badminton after the last one — the amenities are
              a lift ride away.
            </Reveal>
          </div>
          <AmenityGrid items={AMENITIES.filter((a) => AFTER_HOURS.includes(a.name))} />
        </div>
      </section>
    </>
  );
}
