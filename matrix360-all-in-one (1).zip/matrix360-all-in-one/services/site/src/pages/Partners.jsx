import Icon from '../components/Icon.jsx';
import ReferralForm from '../components/ReferralForm.jsx';
import { Fade, MaskedLines } from '../components/Motion.jsx';
import { CONTACT } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const STEPS = [
  { title: 'Tell us about you', text: 'Register as a broker or referral partner, or submit one specific lead.' },
  { title: 'We review', text: 'Every submission is checked by an authorised member of our team.' },
  { title: 'We get in touch', text: 'Our partnerships team contacts you with next steps.' },
];

export default function Partners() {
  usePageMeta({
    title: 'Broker & Referral Partners · Shree Heights, Chandannagar',
    description: 'Brokers and referral partners — register with Shree Heights or submit a lead for 2 & 3 BHK homes in Chandannagar.',
  });
  return (
    <section className="hero partners-hero">
      <div className="container hero__grid hero__grid--top">
        <div className="hero__copy partners-intro">
          <Fade delay={0.05}><span className="eyebrow">Brokers &amp; referral partners</span></Fade>
          <MaskedLines className="h1 h1--md" lines={['Partner with', <em key="p">Shree Heights.</em>]} />
          <Fade as="p" className="lead" delay={0.4}>
            Know someone looking for a home in Chandannagar? Register as a partner or refer a buyer — our team reviews
            every submission personally.
          </Fade>
          <Fade as="ol" className="steps" delay={0.5}>
            {STEPS.map((s) => <li key={s.title}><span><strong>{s.title}</strong><span>{s.text}</span></span></li>)}
          </Fade>
          <Fade className="fact" delay={0.6}>
            <Icon name="shield" />Leads are accepted only with the prospect’s consent
          </Fade>
          <Fade className="form__alt" delay={0.65}>
            <span>Questions?</span>
            <a href={CONTACT.office.href}>{CONTACT.office.label}</a>
            <a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>
          </Fade>
        </div>
        <Fade className="form-card" delay={0.25}>
          <div className="form-card__core">
            <ReferralForm />
          </div>
        </Fade>
      </div>
    </section>
  );
}
