import Button, { VisitButton } from '../components/Button.jsx';
import LandmarkRail from '../components/LandmarkRail.jsx';
import MapViewer from '../components/MapViewer.jsx';
import { Fade, MaskedLines, Reveal } from '../components/Motion.jsx';
import { CONTACT } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

export default function Location() {
  usePageMeta({
    title: 'Location · Shree Heights, North Bagbazar, Chandannagar',
    description: '11 m to the Heritage Museum, 600 m to the Strand, 1.5 km to Chandannagar station — see every landmark near Shree Heights and open the exact location in Google Maps.',
  });

  return (
    <>
      <section className="hero">
        <div className="container hero__grid hero__grid--top">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">Location</span></Fade>
            <MaskedLines className="h1 h1--md" lines={['Where heritage', 'meets everyday', <em key="c">convenience.</em>]} />
            <Fade as="p" className="lead" delay={0.5}>
              Live in the picturesque heritage town of Chandannagar while enjoying excellent modern connectivity.
            </Fade>
            <Fade className="address-card" delay={0.58}>
              <span className="kicker">Site address</span>
              <p>{CONTACT.address[0]}<br />{CONTACT.address[1]}</p>
            </Fade>
            <Fade className="hero__ctas" delay={0.65}>
              <Button href={CONTACT.directions} target="_blank" rel="noopener noreferrer" icon="pin">Open in Google Maps</Button>
              <VisitButton from="location" variant="ghost">Book a site visit</VisitButton>
            </Fade>
          </div>
          <Fade delay={0.4}><LandmarkRail /></Fade>
        </div>
      </section>

      <section className="section section--paper">
        <div className="container">
          <Reveal className="section-head section-head--split">
            <div className="stack">
              <span className="eyebrow">Location viewer</span>
              <h2 className="h2">Find us <em>on the map.</em></h2>
            </div>
            <p>374 &amp; 375 Kuthir Math Road, in North Bagbazar — open the exact location in Google Maps for directions from wherever you are.</p>
          </Reveal>
          <Reveal><MapViewer /></Reveal>
        </div>
      </section>

      <section className="section">
        <div className="container split split--wide-left">
          <Reveal as="p" className="statement">
            A former French settlement on the Hooghly, famous for its riverside Strand and the lights of{' '}
            <em>Jagaddhatri Puja</em> — <span className="soft">now with a modern address of its own.</span>
          </Reveal>
          <Reveal className="stack" delay={0.1}>
            <p className="body-lg">
              Shree Heights sits beside the Chandannagar Heritage Museum, with the post office, hospital, schools,
              police station and ferry ghat all within a kilometre — and two railway stations for the daily commute.
            </p>
            <VisitButton from="location">Walk the neighbourhood with us</VisitButton>
          </Reveal>
        </div>
      </section>
    </>
  );
}
