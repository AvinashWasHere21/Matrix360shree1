import Button, { VisitButton } from '../components/Button.jsx';
import { Fade, MaskedLines } from '../components/Motion.jsx';
import { usePageMeta } from '../lib/usePageMeta.js';

export default function NotFound() {
  usePageMeta({ title: 'Page not found · Shree Heights', description: 'This page has moved. Explore Shree Heights, Chandannagar.' });
  return (
    <section className="error-page">
      <div className="stack" style={{ justifyItems: 'center' }}>
        <Fade><span className="eyebrow">Error 404</span></Fade>
        <MaskedLines className="h1 h1--md" lines={['This floor', <em key="e">isn’t built yet.</em>]} />
        <Fade as="p" className="lead" delay={0.4} style={{ marginInline: 'auto' }}>
          The page you were looking for has moved — but your new home is still right here.
        </Fade>
        <Fade className="hero__ctas" delay={0.5} style={{ justifyContent: 'center' }}>
          <Button to="/">Back to home</Button>
          <VisitButton variant="ghost" from="404" />
        </Fade>
      </div>
    </section>
  );
}
