import { Link } from 'react-router';
import Button, { ArrowLink, VisitButton } from '../components/Button.jsx';
import Icon from '../components/Icon.jsx';
import PriceCard from '../components/PriceCard.jsx';
import ConstructionUpdates from '../components/ConstructionUpdates.jsx';
import { CountUp, Fade, Magnetic, MaskedLines, Reveal } from '../components/Motion.jsx';
import { AMENITIES, RENDERS, STORIES } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const FEATURES = [
  { icon: 'gate', label: <>Gated<br />community</> },
  { icon: 'dumbbell', label: <>Modern<br />amenities</> },
  { icon: 'people', label: <>A vibrant<br />community</> },
  { icon: 'train', label: <>Close to everything<br />you need</> },
];

const STATS = [
  { value: '11', unit: 'm', label: 'to the Chandannagar Heritage Museum' },
  { value: '500', unit: 'm', label: 'to the Sub-Divisional Hospital and St. Thomas School' },
  { value: '600', unit: 'm', label: 'to the Strand on the Hooghly' },
  { value: '1.5', unit: 'km', label: 'to Chandannagar Railway Station' },
];

const BENTO = ['story--a', 'story--b', 'story--c', 'story--d'];

const EXPLORE = [
  { icon: 'sun', title: 'Virtual tour', text: 'Drag to look around the amenities.', to: '/virtual-tour' },
  { icon: 'building', title: 'Availability', text: 'See which homes are open today.', to: '/residences#availability' },
  { icon: 'blueprint', title: 'Floor plans', text: 'Tower plans and unit carpet areas.', to: '/residences#floor-plans' },
  { icon: 'sparkle', title: 'Gallery', text: 'The towers, the podium, the life.', to: '/gallery' },
];

function StoryCard({ story, className, delay }) {
  return (
    <Reveal className={`story ${className}`} delay={delay}>
      <img src={story.img} alt="" loading="lazy" />
      <span className="eyebrow eyebrow--light">{story.eyebrow}</span>
      {story.titleBn ? (
        <>
          <h3 className="story__title bn" lang="bn">{story.titleBn}</h3>
          <p className="story__sub">{story.sub}</p>
        </>
      ) : (
        <h3 className="story__title">{story.title}</h3>
      )}
      <Link className="story__cta" to={story.to} viewTransition>
        {story.cta}
        <span className="btn__icon"><Icon name="arrow" /></span>
        <span className="sr-only"> — {story.titleBn ? story.sub : story.title}</span>
      </Link>
    </Reveal>
  );
}

export default function Home() {
  usePageMeta({
    title: 'Shree Heights · 2 & 3 BHK Homes in Chandannagar from ₹70 Lakhs',
    description: 'Come home to Chandannagar. Gated 2 & 3 BHK residences in North Bagbazar — steps from the Strand, minutes from the station. ₹70 Lakhs onwards. Book a site visit.',
    image: '/og/home.jpg',
  });

  return (
    <>
      <section className="hero home-hero">
        <div className="container hero__grid">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">2 &amp; 3 BHK · North Bagbazar, Chandannagar</span></Fade>
            <MaskedLines className="h1" lines={['Come home to', <em key="c">Chandannagar.</em>]} />
            <Fade as="p" className="lead" delay={0.45}>
              Modern living in the place you belong — a gated community steps from the Strand and minutes from the station.
            </Fade>
            <Fade className="hero__ctas" delay={0.55}>
              <Magnetic><VisitButton from="home" sub="and experience the difference.">Book a site visit</VisitButton></Magnetic>
              <Button to="/residences" variant="ghost">Explore residences</Button>
            </Fade>
            <Fade className="hero__meta" delay={0.65}><PriceCard inline /></Fade>
          </div>

          <div className="hero__media">
            <div className="frame">
              <div className="frame__core">
                <div className="media-settle">
                  <img src={RENDERS.aerialView} alt="Aerial view of the Shree Heights towers, podium and water body" width="1600" height="833" fetchPriority="high" />
                </div>
              </div>
            </div>
            <div className="chip chip--tl" style={{ '--i': 0 }}>
              <span className="chip__pulse" aria-hidden="true" />
              <span><strong>Structurally almost complete</strong>Site open for visits</span>
            </div>
            <div className="chip chip--br" style={{ '--i': 1 }}>
              <span className="chip__icon"><Icon name="train" /></span>
              <span><strong>1.5 km</strong>to Chandannagar Station</span>
            </div>
          </div>
        </div>

        <div className="container">
          <Fade as="ul" className="features" delay={0.8}>
            {FEATURES.map((f) => (
              <li className="feature" key={f.icon}><Icon name={f.icon} /><span>{f.label}</span></li>
            ))}
            <li className="feature feature--statement"><span>Live the next chapter<br />in Chandannagar</span></li>
          </Fade>
        </div>
      </section>

      <section className="section">
        <div className="container split split--wide-left">
          <Reveal as="p" className="statement">
            In a town of riverside promenades and festival lights, Shree Heights brings <em>gated, modern living</em>{' '}
            <span className="soft">to the heart of old Chandannagar.</span>
          </Reveal>
          <Reveal className="stack" delay={0.1}>
            <p className="body-lg">
              Spacious 2 &amp; 3 BHK homes with beautiful interiors, made for joyful living the Bengali way. The Heritage
              Museum is next door, the Strand is a short walk away and the railway station is five minutes from the gate.
            </p>
            <ArrowLink to="/location">See what’s nearby</ArrowLink>
          </Reveal>
        </div>
      </section>

      <section className="section section--paper">
        <div className="container">
          <div className="section-head section-head--split">
            <Reveal className="stack">
              <span className="eyebrow">Life at Shree Heights</span>
              <h2 className="h2">Four ways to <em>feel at home.</em></h2>
            </Reveal>
            <Reveal as="p" delay={0.1}>
              Calm evenings by the water, mornings on the yoga deck, children growing up among friends — and a
              location that gives every professional time back in the day.
            </Reveal>
          </div>
          <div className="bento">
            {STORIES.map((story, i) => (
              <StoryCard story={story} className={BENTO[i]} delay={(i % 2) * 0.1} key={story.key} />
            ))}
          </div>
        </div>
      </section>

      <section className="section section--tight">
        <div className="container">
          <Reveal className="section-head section-head--split" style={{ marginBottom: 40 }}>
            <h2 className="h2">Explore <em>from home.</em></h2>
            <p>Take the tour, check what’s available and study the plans before you visit.</p>
          </Reveal>
          <div className="explore">
            {EXPLORE.map((e, i) => (
              <Reveal key={e.title} delay={i * 0.07}>
                <Link className="explore__card" to={e.to} viewTransition>
                  <Icon name={e.icon} />
                  <strong>{e.title}</strong>
                  <span>{e.text}</span>
                  <span className="btn__icon"><Icon name="arrow" /></span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <div className="marquee" aria-hidden="true">
        <div className="marquee__track">
          {[0, 1].map((copy) => AMENITIES.slice(0, 10).map((a) => (
            <span className="marquee__item" key={`${copy}-${a.name}`}>
              {a.name}<Icon name="sparkle" />
            </span>
          )))}
        </div>
      </div>

      <section className="section section--sand">
        <div className="container">
          <div className="section-head section-head--split">
            <Reveal className="stack">
              <span className="eyebrow">Residences</span>
              <h2 className="h2">Two layouts. <em>Room for everyone.</em></h2>
            </Reveal>
            <Reveal className="stack stack--sm" delay={0.1}>
              <p>Thoughtfully planned 2 &amp; 3 BHK homes with vitrified floors, Jaquar fittings and balconies that open onto green views.</p>
              <PriceCard inline />
            </Reveal>
          </div>
          <div className="configs">
            <Reveal as="article" className="config">
              <div className="config__core">
                <span className="config__num">2<sup>BHK</sup></span>
                <h3 className="h3">For couples &amp; young families</h3>
                <p>Efficient, light-filled planning with a generous living-dining space and a balcony for evening tea.</p>
                <div className="config__foot">
                  <span className="kicker">603 sq ft carpet</span>
                  <ArrowLink to="/residences#floor-plans">View floor plans</ArrowLink>
                </div>
              </div>
            </Reveal>
            <Reveal as="article" className="config config--dark" delay={0.1}>
              <div className="config__core">
                <span className="config__num">3<sup>BHK</sup></span>
                <h3 className="h3">For growing &amp; multi-generational families</h3>
                <p>An extra bedroom for parents, guests or a study — space to live together without living on top of each other.</p>
                <div className="config__foot">
                  <span className="kicker">769–878 sq ft carpet</span>
                  <VisitButton from="residences" extra={{ config: '3bhk' }} variant="light" size="sm">Enquire</VisitButton>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <Reveal className="section-head section-head--center">
            <span className="eyebrow eyebrow--gold">Location</span>
            <h2 className="h2">Everything, <em>a few minutes away.</em></h2>
          </Reveal>
          <div className="stats">
            {STATS.map((s, i) => (
              <Reveal className="stat" key={s.label} delay={i * 0.08}>
                <span className="stat__value"><CountUp value={s.value} /><small>{s.unit}</small></span>
                <span className="stat__label">{s.label}</span>
              </Reveal>
            ))}
          </div>
          <Reveal className="center-row">
            <Button to="/location" variant="ghost">All 12 landmarks nearby</Button>
          </Reveal>
        </div>
      </section>

      <section className="section section--paper" id="construction">
        <div className="container">
          <ConstructionUpdates from="home" limit={7} />
        </div>
      </section>

      <section className="section">
        <div className="container split split--wide-left">
          <Reveal className="stack">
            <span className="kicker">Building Bengal since</span>
            <span className="big-number"><CountUp value="1985" /></span>
          </Reveal>
          <Reveal className="stack" delay={0.1}>
            <h2 className="h2">Built by families who know <em>how Bengal lives.</em></h2>
            <p className="body-lg">
              Shree Heights is developed by Dream Royally LLP, bringing together JP Group (Parakh Group, since 1985) and
              Bhawani Group (Lakhotia Group, since 1989) — decades of residential and commercial projects across West
              Bengal and Odisha.
            </p>
            <ArrowLink to="/developers">Meet the developers</ArrowLink>
          </Reveal>
        </div>
      </section>
    </>
  );
}
