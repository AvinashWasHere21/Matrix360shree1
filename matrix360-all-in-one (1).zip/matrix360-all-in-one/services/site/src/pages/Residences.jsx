import Button, { ArrowLink, VisitButton } from '../components/Button.jsx';
import AvailabilityTracker from '../components/AvailabilityTracker.jsx';
import FloorPlans from '../components/FloorPlans.jsx';
import Icon from '../components/Icon.jsx';
import PriceCard from '../components/PriceCard.jsx';
import ProjectCard from '../components/ProjectCard.jsx';
import SpecsAccordion from '../components/SpecsAccordion.jsx';
import ConstructionUpdates from '../components/ConstructionUpdates.jsx';
import { Fade, Magnetic, MaskedLines, Reveal } from '../components/Motion.jsx';
import { CONTACT, RENDERS } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const CONFIGS = [
  {
    key: '2bhk', num: '2', title: 'For couples & young families', dark: false,
    text: 'Efficient, light-filled planning with a generous living-dining space and a balcony for evening tea.',
    carpet: '603 sq ft carpet', points: ['Two bedrooms and two toilets', 'Living & dining with vitrified flooring', 'Kitchen with granite platform', 'Balcony with glass railing'],
  },
  {
    key: '3bhk', num: '3', title: 'For growing & multi-generational families', dark: true,
    text: 'An extra bedroom for parents, guests or a study — space to live together without living on top of each other.',
    carpet: '769–878 sq ft carpet', points: ['Three bedrooms with two or three toilets', 'Geyser in the master bathroom', 'Jaquar-or-equivalent fittings', 'Balcony with green views'],
  },
];

export default function Residences() {
  usePageMeta({
    title: '2 & 3 BHK Residences from ₹70 Lakhs · Shree Heights, Chandannagar',
    description: 'Gated 2 & 3 BHK homes in Chandannagar from ₹70 Lakhs — floor plans, live availability, specifications and construction status. Book a site visit.',
  });

  return (
    <>
      <section className="hero res-hero">
        <div className="container hero__grid">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">Residences</span></Fade>
            <MaskedLines className="h1 h1--md" lines={['2 & 3 BHK homes,', <em key="p">from ₹70 Lakhs.</em>]} />
            <Fade as="p" className="lead" delay={0.45}>
              Two residential towers, thoughtfully planned homes and premium specifications — in the heart of heritage Chandannagar.
            </Fade>
            <Fade className="hero__ctas" delay={0.55}>
              <Magnetic><VisitButton from="residences" sub="see the homes in person.">Book a site visit</VisitButton></Magnetic>
              <Button to="/virtual-tour" variant="ghost">Take the virtual tour</Button>
            </Fade>
            <Fade className="hero__meta" delay={0.65}><PriceCard inline /></Fade>
          </div>
          <div className="hero__media">
            <div className="frame">
              <div className="frame__core">
                <div className="media-settle">
                  <img src={RENDERS.nightElevation} alt="Evening elevation of the Shree Heights towers" width="1600" height="833" fetchPriority="high" />
                </div>
              </div>
            </div>
            <a className="chip chip--tl" style={{ '--i': 0 }} href={CONTACT.rera} target="_blank" rel="noopener noreferrer">
              <span className="chip__icon"><Icon name="shield" /></span>
              <span><strong>RERA registered</strong>View certificate</span>
            </a>
            <div className="chip chip--br" style={{ '--i': 1 }}>
              <span className="chip__pulse" aria-hidden="true" />
              <span><strong>Structurally almost complete</strong>Two residential towers</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--paper" id="availability">
        <div className="container">
          <Reveal className="section-head">
            <span className="eyebrow">Project at a glance</span>
            <h2 className="h2">Know the project. <em>See what’s open.</em></h2>
          </Reveal>
          <div className="split split--top">
            <Reveal><ProjectCard /></Reveal>
            <Reveal delay={0.1}><AvailabilityTracker /></Reveal>
          </div>
        </div>
      </section>

      <section className="section" id="floor-plans">
        <div className="container">
          <div className="section-head section-head--split">
            <Reveal className="stack">
              <span className="eyebrow">Configurations</span>
              <h2 className="h2">Two layouts. <em>Room for everyone.</em></h2>
            </Reveal>
            <Reveal as="p" delay={0.1}>
              Every home comes with vitrified floors, concealed copper wiring and balconies that open onto green views.
              Browse the plans and unit areas below.
            </Reveal>
          </div>
          <div className="configs">
            {CONFIGS.map((c, i) => (
              <Reveal as="article" className={`config${c.dark ? ' config--dark' : ''}`} key={c.key} delay={i * 0.1}>
                <div className="config__core">
                  <span className="config__num">{c.num}<sup>BHK</sup></span>
                  <h3 className="h3">{c.title}</h3>
                  <p>{c.text}</p>
                  <ul className="config__list">
                    {c.points.map((p) => <li key={p}><Icon name="check" />{p}</li>)}
                  </ul>
                  <div className="config__foot">
                    <span className="kicker">{c.carpet}</span>
                    <VisitButton from="residences" extra={{ config: c.key }} variant={c.dark ? 'light' : 'primary'} size="sm">Enquire for {c.num} BHK</VisitButton>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="plans-wrap" delay={0.1}><FloorPlans /></Reveal>
        </div>
      </section>

      <section className="section section--sand" id="specifications">
        <div className="container reasons">
          <Reveal className="reasons__intro">
            <span className="eyebrow">Specifications</span>
            <h2 className="h2">Made to last, <em>finished with care.</em></h2>
            <p className="body-lg">Quality materials and trusted brands, from the Italian-marble lobby to the fittings in your bathroom.</p>
            <ArrowLink to="/amenities">See the amenities</ArrowLink>
          </Reveal>
          <SpecsAccordion />
        </div>
      </section>

      <section className="section section--paper" id="construction">
        <div className="container">
          <ConstructionUpdates from="residences" />
        </div>
      </section>
    </>
  );
}
