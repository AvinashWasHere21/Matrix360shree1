import { VisitButton } from '../components/Button.jsx';
import AmenityGrid from '../components/AmenityGrid.jsx';
import Icon from '../components/Icon.jsx';
import { Fade, MaskedLines, Reveal } from '../components/Motion.jsx';
import { AMENITIES, RENDERS } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';
import { Link } from 'react-router';

const GROUPS = [
  { key: 'wellness', title: 'Wellness', line: 'Move every day.' },
  { key: 'leisure', title: 'Leisure & celebrations', line: 'Gather often.' },
  { key: 'family', title: 'Family & nature', line: 'Grow up outdoors.' },
  { key: 'everyday', title: 'Everyday essentials', line: 'Live without worry.' },
];

export default function Amenities() {
  usePageMeta({
    title: 'Amenities · Shree Heights, Chandannagar',
    description: 'Yoga deck, gym, badminton court, community hall, party lawn, kids’ play arena, podium garden, MLCP parking and 24×7 security — all inside the gate.',
  });

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <div className="section-head section-head--split" style={{ marginBottom: 40 }}>
            <div className="stack">
              <Fade delay={0.05}><span className="eyebrow">Amenities</span></Fade>
              <MaskedLines className="h1 h1--md" lines={['Everything you need,', <em key="g">inside the gate.</em>]} />
            </div>
            <Fade className="stack stack--sm" delay={0.45}>
              <p className="body-lg">Sixteen everyday luxuries — for wellness, celebrations, children and complete peace of mind.</p>
              <VisitButton from="amenities">Book a site visit</VisitButton>
            </Fade>
          </div>
          <div className="a-bento">
            <Fade className="a-tile a-tile--w7" delay={0.5}>
              <img src={RENDERS.yogaDeck} alt="" />
              <h3>Yoga deck</h3><p>Sunrise asanas on the open-air deck.</p>
            </Fade>
            <Fade className="a-tile a-tile--w5" delay={0.6}>
              <img src={RENDERS.podiumView} alt="" />
              <h3>Podium garden</h3><p>Greens and water to unwind beside.</p>
            </Fade>
            <Reveal className="a-tile a-tile--w4 a-tile--crimson">
              <Icon name="shield" className="a-tile__icon" />
              <div><h3>Gated &amp; secure</h3><p>24×7 security, CCTV at the lobby and fire-fighting provisions.</p></div>
            </Reveal>
            <Reveal className="a-tile a-tile--w8" delay={0.1}>
              <img src={RENDERS.kidsPlayArea} alt="" />
              <h3>Kids’ play arena &amp; lawns</h3><p>Safe, green space for children to run free.</p>
            </Reveal>
            <Reveal className="a-tile a-tile--w4">
              <img src={RENDERS.gym} alt="" loading="lazy" />
              <h3>Gymnasium</h3><p>Fully fitted, a lift ride away.</p>
            </Reveal>
            <Reveal className="a-tile a-tile--w4" delay={0.08}>
              <img src={RENDERS.gamesRoom} alt="" loading="lazy" />
              <h3>Games room</h3><p>Pool, carrom and long afternoons.</p>
            </Reveal>
            <Reveal className="a-tile a-tile--w4" delay={0.16}>
              <img src={RENDERS.communityHall} alt="" loading="lazy" />
              <h3>Community hall</h3><p>For pujo, birthdays and society meets.</p>
            </Reveal>
          </div>
        </div>
      </section>

      <div className="marquee" aria-hidden="true">
        <div className="marquee__track">
          {[0, 1].map((copy) => AMENITIES.map((a) => (
            <span className="marquee__item" key={`${copy}-${a.name}`}>{a.name}<Icon name="sparkle" /></span>
          )))}
        </div>
      </div>

      {GROUPS.map((g, i) => (
        <section className={`section section--tight${i % 2 ? ' section--paper' : ''}`} key={g.key}>
          <div className="container">
            <Reveal className="section-head section-head--split" style={{ marginBottom: 40 }}>
              <h2 className="h2">{g.title}</h2>
              <p className="lead--serif">{g.line}</p>
            </Reveal>
            <AmenityGrid items={AMENITIES.filter((a) => a.group === g.key)} />
          </div>
        </section>
      ))}

      <section className="section section--tight">
        <div className="container center-row" style={{ marginTop: 0 }}>
          <Link className="link-arrow" to="/mornings" viewTransition>See a morning at Shree Heights <Icon name="arrow" /></Link>
          <Link className="link-arrow" to="/growing-up" viewTransition>See it through a child’s eyes <Icon name="arrow" /></Link>
        </div>
      </section>
    </>
  );
}
