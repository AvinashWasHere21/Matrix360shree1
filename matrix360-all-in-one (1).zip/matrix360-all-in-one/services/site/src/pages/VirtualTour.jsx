import Button, { VisitButton } from '../components/Button.jsx';
import TourViewer from '../components/TourViewer.jsx';
import { Fade, MaskedLines } from '../components/Motion.jsx';
import { usePageMeta } from '../lib/usePageMeta.js';

export default function VirtualTour() {
  usePageMeta({
    title: 'Virtual Tour · Shree Heights, Chandannagar',
    description: 'Take a virtual walk through Shree Heights — drag to look around the yoga deck, lawns, water-side deck and play arena.',
  });
  return (
    <section className="page-hero tour-page">
      <div className="container">
        <div className="section-head section-head--split" style={{ marginBottom: 32 }}>
          <div className="stack">
            <Fade delay={0.05}><span className="eyebrow">Virtual tour</span></Fade>
            <MaskedLines className="h1 h1--md" lines={['Walk around,', <em key="t">from anywhere.</em>]} />
          </div>
          <Fade className="stack stack--sm" delay={0.45}>
            <p className="body-lg">Drag, swipe or use the arrow keys to look around the towers and amenities. Pick a scene below to move through the project.</p>
            <div className="hero__ctas">
              <VisitButton from="virtual-tour">Book a site visit</VisitButton>
              <Button to="/gallery" variant="ghost">Open the gallery</Button>
            </div>
          </Fade>
        </div>
        <Fade delay={0.35}><TourViewer /></Fade>
        <p className="small muted" style={{ marginTop: 20 }}>
          360° walkthroughs of the sample flat interiors will be added here as they are ready. Images are artistic impressions.
        </p>
      </div>
    </section>
  );
}
