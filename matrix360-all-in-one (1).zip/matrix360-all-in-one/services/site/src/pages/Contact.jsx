import Icon from '../components/Icon.jsx';
import LeadForm from '../components/LeadForm.jsx';
import MapViewer from '../components/MapViewer.jsx';
import { Fade, MaskedLines, Reveal } from '../components/Motion.jsx';
import { CONTACT, whatsappLink } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

export default function Contact() {
  usePageMeta({
    title: 'Contact · Shree Heights, Chandannagar',
    description: 'Call 033 6826 3828 or +91 74399 90925, chat on WhatsApp or write to info@shreeheights.com. Site: 374 & 375 Kuthir Math Road, North Bagbazar, Chandannagar.',
  });

  const cards = [
    { icon: 'phone', label: 'Sales office', value: CONTACT.office.label, href: CONTACT.office.href },
    { icon: 'phone', label: 'Mobile', value: CONTACT.mobile.label, href: CONTACT.mobile.href },
    { icon: 'whatsapp', label: 'WhatsApp', value: 'Chat with our team', href: whatsappLink(), external: true },
    { icon: 'mail', label: 'Email', value: CONTACT.email, href: `mailto:${CONTACT.email}` },
  ];

  return (
    <>
      <section className="hero">
        <div className="container hero__grid hero__grid--top">
          <div className="hero__copy">
            <Fade delay={0.05}><span className="eyebrow">Enquiry &amp; support</span></Fade>
            <MaskedLines className="h1 h1--md" lines={['Let’s talk about', <em key="h">your new home.</em>]} />
            <Fade as="p" className="lead" delay={0.45}>Call, chat or drop us a line — our team will help you find the right home at Shree Heights.</Fade>
            <Fade className="contact-cards" delay={0.55}>
              {cards.map((c) => (
                <a className="contact-card" key={c.label} href={c.href} {...(c.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>
                  <Icon name={c.icon} />
                  <small>{c.label}</small>
                  <strong>{c.value}</strong>
                </a>
              ))}
              <a className="contact-card contact-card--wide" href={CONTACT.directions} target="_blank" rel="noopener noreferrer">
                <Icon name="pin" />
                <small>Site address</small>
                <strong>{CONTACT.address[0]} {CONTACT.address[1]}</strong>
                <span>Get directions</span>
              </a>
            </Fade>
          </div>
          <Fade className="form-card" delay={0.35}>
            <div className="form-card__core">
              <LeadForm kind="enquiry" title="Send an enquiry" intro="Our team will get back to you shortly." />
            </div>
          </Fade>
        </div>
      </section>

      <section className="section section--paper section--tight">
        <div className="container">
          <Reveal><MapViewer /></Reveal>
          <Reveal as="p" className="small muted" style={{ marginTop: 20 }}>
            Owners &amp; developers: {CONTACT.developer}, {CONTACT.developerAddress}.
          </Reveal>
        </div>
      </section>
    </>
  );
}
