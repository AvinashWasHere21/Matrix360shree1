import { ArrowLink, VisitButton } from '../components/Button.jsx';
import Icon from '../components/Icon.jsx';
import { CountUp, Fade, MaskedLines, Reveal } from '../components/Motion.jsx';
import { CONTACT } from '../data/site.js';
import { usePageMeta } from '../lib/usePageMeta.js';

const DEVELOPERS = [
  {
    since: '1985',
    name: 'JP Group',
    sub: 'Parakh Group · Jatan Lal Parakh',
    text: 'Since 1985 the Parakh family has lived and breathed real estate — multi-purpose, multi-storeyed buildings delivered to the heartfelt satisfaction of the families who live in them. The name Jatan Lal Parakh has come to stand for trust.',
  },
  {
    since: '1989',
    name: 'Bhawani Group',
    sub: 'Lakhotia Group · Aditya Vikram Lakhotia, Managing Director',
    text: 'Established in 1989, Bhawani Group has developed residential and commercial projects of consistent quality across West Bengal and Odisha, and continues to grow under the leadership of Shri Aditya Vikram Lakhotia.',
  },
];

const VALUES = [
  { icon: 'sparkle', title: 'A pinch of heart', text: 'Buildings are made of iron, cement and bricks — we add a small pinch of heart to every project.' },
  { icon: 'shield', title: 'No compromise', text: 'We never compromise on quantum or quality, from the structure to the last fitting.' },
  { icon: 'people', title: 'In person, start to finish', text: 'We stay with every project from design to delivery — with our minds and our hearts.' },
];

export default function Developers() {
  usePageMeta({
    title: 'The Developers · Shree Heights, Chandannagar',
    description: 'Shree Heights is developed by Dream Royally LLP with JP Group (Parakh Group, since 1985) and Bhawani Group (Lakhotia Group, since 1989).',
  });

  return (
    <>
      <section className="page-hero">
        <div className="container split split--wide-left">
          <div className="stack">
            <Fade delay={0.05}><span className="eyebrow">Owners &amp; developers</span></Fade>
            <MaskedLines className="h1 h1--md" lines={['Built on decades', <em key="t">of trust.</em>]} />
            <Fade as="p" className="lead" delay={0.45}>
              Shree Heights is developed by {CONTACT.developer}, bringing together two Bengal developers with over
              seventy years of combined experience building homes people are proud of.
            </Fade>
            <Fade delay={0.55}><VisitButton from="developers">Meet the team on site</VisitButton></Fade>
          </div>
          <Fade className="stack" delay={0.5}>
            <span className="kicker">Building since</span>
            <span className="big-number"><CountUp value="1985" /></span>
          </Fade>
        </div>
      </section>

      <section className="section section--paper">
        <div className="container devs">
          {DEVELOPERS.map((d, i) => (
            <Reveal as="article" className="dev" key={d.name} delay={i * 0.1}>
              <span className="dev__year"><small>Since</small>{d.since}</span>
              <div className="stack stack--sm">
                <h2 className="h3">{d.name}</h2>
                <span className="kicker">{d.sub}</span>
              </div>
              <p>{d.text}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="section section--night">
        <div className="container">
          <Reveal className="section-head">
            <span className="eyebrow eyebrow--light">How we build</span>
            <h2 className="h2">Three promises, <em>kept since 1985.</em></h2>
          </Reveal>
          <ul className="values">
            {VALUES.map((v, i) => (
              <Reveal as="li" className="value" key={v.title} delay={i * 0.1}>
                <Icon name={v.icon} />
                <h3>{v.title}</h3>
                <p>{v.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section className="section section--tight">
        <div className="container split">
          <Reveal className="stack">
            <span className="eyebrow">Registered office</span>
            <h2 className="h3">{CONTACT.developer}</h2>
            <p>{CONTACT.developerAddress}</p>
          </Reveal>
          <Reveal className="stack" delay={0.1}>
            <p className="body-lg">Are you a broker or channel partner? Register with us, or refer a buyer who’d love to call Chandannagar home.</p>
            <ArrowLink to="/partners">Partner with Shree Heights</ArrowLink>
          </Reveal>
        </div>
      </section>
    </>
  );
}
