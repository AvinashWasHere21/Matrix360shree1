import homeFamily from '../assets/img/home-family.webp';
import towerFacade from '../assets/img/tower-facade.webp';
import professionals from '../assets/img/professionals.webp';
import lakeside from '../assets/img/lakeside.webp';
import yogaDeck from '../assets/img/yoga-deck.webp';
import playLawn from '../assets/img/play-lawn.webp';
import playGarden from '../assets/img/play-garden.webp';
import towers from '../assets/img/towers.webp';
// Official renders, floor plans and site photographs from the original shreeheights.com
import planMaster from '../assets/plans/master-plan.webp';
import planFirst from '../assets/plans/first-floor.webp';
import planTower1 from '../assets/plans/tower-1-typical.webp';
import planTower2 from '../assets/plans/tower-2-typical.webp';
import planTypical from '../assets/plans/typical-5th-12th.webp';
import aerialView from '../assets/original/aerial-view.webp';
import nightElevation from '../assets/original/night-elevation.webp';
import waterBody from '../assets/original/water-body.webp';
import podiumView from '../assets/original/podium-view.webp';
import yogaDeckRender from '../assets/original/yoga-deck.webp';
import gymRender from '../assets/original/gym.webp';
import gamesRoom from '../assets/original/games-room.webp';
import communityHall from '../assets/original/community-hall.webp';
import partyLounge from '../assets/original/party-lounge.webp';
import badmintonCourt from '../assets/original/badminton-court.webp';
import kidsPlayArea from '../assets/original/kids-play-area.webp';
import site01 from '../assets/construction/site-01.webp';
import site02 from '../assets/construction/site-02.webp';
import site03 from '../assets/construction/site-03.webp';
import site04 from '../assets/construction/site-04.webp';
import site05 from '../assets/construction/site-05.webp';
import site06 from '../assets/construction/site-06.webp';
import site07 from '../assets/construction/site-07.webp';
import site08 from '../assets/construction/site-08.webp';
import site09 from '../assets/construction/site-09.webp';
import site10 from '../assets/construction/site-10.webp';

export const SITE_URL = 'https://shreeheights.com';

// Optional: POST leads as JSON to a form backend (Formspree, Google Apps Script, CRM webhook).
// Leave empty and enquiries are handed to WhatsApp instead.
export const FORM_ENDPOINT = import.meta.env.VITE_FORM_ENDPOINT || '';

export const IMG = { homeFamily, towerFacade, professionals, lakeside, yogaDeck, playLawn, playGarden, towers };

// Original project imagery — use these wherever the building itself is shown.
export const RENDERS = {
  aerialView, nightElevation, waterBody, podiumView, yogaDeck: yogaDeckRender, gym: gymRender,
  gamesRoom, communityHall, partyLounge, badmintonCourt, kidsPlayArea,
};

// Actual site photographs (construction update).
export const CONSTRUCTION = {
  status: 'Structurally almost complete',
  summary: 'Shree Heights has reached an advanced stage of construction, with the principal residential structures now substantially in place.',
  photos: [
    { src: site01, title: "Overall view of the residential towers", w: 1400, h: 1050 },
    { src: site02, title: "Front elevation showing the scale of the development", w: 1400, h: 1050 },
    { src: site03, title: "Residential towers at an advanced construction stage", w: 1400, h: 1050 },
    { src: site04, title: "Current progress across the principal elevations", w: 1050, h: 1400 },
    { src: site05, title: "Residential tower structure viewed from the approach", w: 1050, h: 1400 },
    { src: site06, title: "Side elevation of the residential tower", w: 1050, h: 1400 },
    { src: site07, title: "Ongoing work across the central tower section", w: 1050, h: 1400 },
    { src: site08, title: "Full-height view of the residential development", w: 1050, h: 1400 },
    { src: site09, title: "Current façade development across the towers", w: 1050, h: 1400 },
    { src: site10, title: "Ground-level view of the structural form", w: 1050, h: 1400 },
  ],
};

const ADDRESS_QUERY = '374 Kuthir Math Road, North Bagbazar, Chandannagar, Hooghly 712136';

export const CONTACT = {
  office: { label: '033 6826 3828', href: 'tel:+913368263828' },
  mobile: { label: '+91 74399 90925', href: 'tel:+917439990925' },
  whatsapp: '917439990925',
  email: 'info@shreeheights.com',
  address: ['374 & 375, Kuthir Math Road, North Bagbazar,', 'Chandannagar, Hooghly – 712 136'],
  developer: 'Dream Royally LLP',
  developerAddress: '51 Maulana Abul Kalam Azad Road, Howrah 711 101',
  mapEmbed: `https://maps.google.com/maps?q=${encodeURIComponent(ADDRESS_QUERY)}&z=15&output=embed`,
  directions: `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(ADDRESS_QUERY)}`,
  rera: 'https://www.shreeheights.com/Shree-Heights-RERA.pdf',
  youtubeId: 'CJkvBz8pR6Y',
  social: [
    { icon: 'facebook', label: 'Facebook', href: 'https://www.facebook.com/shreeheightschandannagar' },
    { icon: 'instagram', label: 'Instagram', href: 'https://www.instagram.com/shreeheightschandannagar' },
    { icon: 'linkedin', label: 'LinkedIn', href: 'https://www.linkedin.com/company/shree-heights/' },
    { icon: 'youtube', label: 'YouTube', href: 'https://youtu.be/CJkvBz8pR6Y' },
  ],
};

export const whatsappLink = (text = 'Hello Shree Heights, I’d like to know more.') =>
  `https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(text)}`;

export const PRICE = { configs: '2 & 3 BHK', from: '₹70', unit: 'Lakhs' };

export const NAV = [
  { to: '/residences', label: 'Residences' },
  { to: '/amenities', label: 'Amenities' },
  { to: '/gallery', label: 'Gallery' },
  { to: '/virtual-tour', label: 'Virtual tour' },
  { to: '/location', label: 'Location' },
  { to: '/contact', label: 'Contact' },
];

export const NAV_MORE = [
  { to: '/developers', label: 'Developers' },
  { to: '/partners', label: 'Partner with us' },
];

// Brochure PDF — drop the file in public/ (e.g. public/shree-heights-brochure.pdf) and set the path.
// While empty, the "brochure" buttons ask for it on WhatsApp instead.
export const BROCHURE_URL = '';

// Floor plans from the published project drawings.
export const FLOOR_PLANS = [
  { key: 'master', label: 'Master plan', src: planMaster, w: 1200, h: 639, note: 'Site layout with the podium, water body and amenities.' },
  { key: 'first', label: 'First floor', src: planFirst, w: 2400, h: 1484, note: 'First-floor plan across both towers, with the commercial space.' },
  { key: 'tower-1', label: 'Tower 1', src: planTower1, w: 2400, h: 2078, note: 'Typical floor — four 3 BHK homes with three toilets each.', tower: 'Tower 1' },
  { key: 'tower-2', label: 'Tower 2', src: planTower2, w: 2400, h: 1662, note: 'Typical floor — six 3 BHK and two 2 BHK homes.', tower: 'Tower 2' },
  { key: 'typical', label: '5th–12th floor', src: planTypical, w: 2400, h: 1484, note: 'Typical upper-floor plan from the 5th to the 12th floor.' },
];

// Unit areas (sq ft) as printed on the typical floor plans. 2T / 3T = two / three toilets.
export const UNITS = [
  { tower: 'Tower 1', flat: 'A', type: '3 BHK', toilets: 3, carpet: 878, balcony: 38, builtUp: 1005, chargeable: 1341 },
  { tower: 'Tower 1', flat: 'B', type: '3 BHK', toilets: 3, carpet: 873, balcony: 38, builtUp: 997, chargeable: 1328 },
  { tower: 'Tower 1', flat: 'C', type: '3 BHK', toilets: 3, carpet: 873, balcony: 38, builtUp: 997, chargeable: 1328 },
  { tower: 'Tower 1', flat: 'D', type: '3 BHK', toilets: 3, carpet: 873, balcony: 38, builtUp: 1006, chargeable: 1341 },
  { tower: 'Tower 2', flat: 'A', type: '3 BHK', toilets: 2, carpet: 822, balcony: 39, builtUp: 947, chargeable: 1262 },
  { tower: 'Tower 2', flat: 'B', type: '3 BHK', toilets: 2, carpet: 845, balcony: 38, builtUp: 971, chargeable: 1295 },
  { tower: 'Tower 2', flat: 'C', type: '3 BHK', toilets: 2, carpet: 769, balcony: 36, builtUp: 877, chargeable: 1169 },
  { tower: 'Tower 2', flat: 'D', type: '3 BHK', toilets: 2, carpet: 769, balcony: 36, builtUp: 877, chargeable: 1169 },
  { tower: 'Tower 2', flat: 'E', type: '3 BHK', toilets: 2, carpet: 821, balcony: 38, builtUp: 941, chargeable: 1255 },
  { tower: 'Tower 2', flat: 'F', type: '3 BHK', toilets: 2, carpet: 822, balcony: 39, builtUp: 947, chargeable: 1262 },
  { tower: 'Tower 2', flat: 'G', type: '2 BHK', toilets: 2, carpet: 603, balcony: 33, builtUp: 714, chargeable: 952 },
  { tower: 'Tower 2', flat: 'H', type: '2 BHK', toilets: 2, carpet: 603, balcony: 33, builtUp: 714, chargeable: 952 },
];

export const GALLERY_TABS = [
  { key: 'all', label: 'All' },
  { key: 'exterior', label: 'Exterior' },
  { key: 'amenities', label: 'Amenities' },
  { key: 'construction', label: 'Construction' },
];

export const GALLERY = [
  { cat: 'exterior', src: aerialView, title: 'Aerial view of the towers', w: 1600, h: 833 },
  { cat: 'exterior', src: nightElevation, title: 'Evening elevation', w: 1600, h: 833 },
  { cat: 'amenities', src: podiumView, title: 'Podium view', w: 995, h: 560 },
  { cat: 'amenities', src: yogaDeckRender, title: 'Yoga deck', w: 995, h: 560 },
  { cat: 'exterior', src: waterBody, title: 'Water body & landscape', w: 1600, h: 833 },
  { cat: 'amenities', src: gymRender, title: 'Gymnasium', w: 996, h: 560 },
  { cat: 'amenities', src: gamesRoom, title: 'Games room', w: 996, h: 560 },
  { cat: 'amenities', src: communityHall, title: 'Community hall', w: 995, h: 560 },
  { cat: 'amenities', src: partyLounge, title: 'Party lounge', w: 995, h: 560 },
  { cat: 'amenities', src: badmintonCourt, title: 'Badminton court', w: 995, h: 560 },
  { cat: 'amenities', src: kidsPlayArea, title: 'Kids’ play arena', w: 995, h: 560 },
  { cat: 'construction', src: site01, title: "Overall view of the residential towers", w: 1400, h: 1050 },
  { cat: 'construction', src: site02, title: "Front elevation showing the scale of the development", w: 1400, h: 1050 },
  { cat: 'construction', src: site03, title: "Residential towers at an advanced construction stage", w: 1400, h: 1050 },
  { cat: 'construction', src: site04, title: "Current progress across the principal elevations", w: 1050, h: 1400 },
  { cat: 'construction', src: site05, title: "Residential tower structure viewed from the approach", w: 1050, h: 1400 },
  { cat: 'construction', src: site06, title: "Side elevation of the residential tower", w: 1050, h: 1400 },
  { cat: 'construction', src: site07, title: "Ongoing work across the central tower section", w: 1050, h: 1400 },
  { cat: 'construction', src: site08, title: "Full-height view of the residential development", w: 1050, h: 1400 },
  { cat: 'construction', src: site09, title: "Current façade development across the towers", w: 1050, h: 1400 },
  { cat: 'construction', src: site10, title: "Ground-level view of the structural form", w: 1050, h: 1400 },
];

// Virtual tour scenes. `loop: true` is for true 360° (2:1 equirectangular) panoramas —
// drop those in public/tour/ and add them here; they will spin seamlessly.
export const TOUR_SCENES = [
  { key: 'aerial', title: 'Aerial view', src: aerialView, loop: false },
  { key: 'podium', title: 'Podium', src: podiumView, loop: false },
  { key: 'water', title: 'Water body', src: waterBody, loop: false },
  { key: 'yoga', title: 'Yoga deck', src: yogaDeckRender, loop: false },
  { key: 'gym', title: 'Gymnasium', src: gymRender, loop: false },
  { key: 'games', title: 'Games room', src: gamesRoom, loop: false },
  { key: 'lounge', title: 'Party lounge', src: partyLounge, loop: false },
  { key: 'hall', title: 'Community hall', src: communityHall, loop: false },
  { key: 'night', title: 'Evening elevation', src: nightElevation, loop: false },
];

// The four campaign stories — each one is the landing page for a creative.
export const STORIES = [
  {
    key: 'professionals',
    to: '/why-shree-heights',
    img: professionals,
    eyebrow: 'For professionals',
    title: 'Why Chandannagar’s professionals choose Shree Heights',
    short: 'Why professionals choose us',
    sub: 'Six reasons, one address',
    cta: 'Discover why',
  },
  {
    key: 'serene',
    to: '/serene-living',
    img: lakeside,
    eyebrow: 'Serene living',
    titleBn: 'জলের মতো শান্ত জীবন।',
    sub: 'Where life finds its quieter rhythm.',
    cta: 'Slow down',
  },
  {
    key: 'mornings',
    to: '/mornings',
    img: yogaDeck,
    eyebrow: 'Wellness',
    titleBn: 'প্রতিটি সকাল নতুন সম্ভাবনার।',
    sub: 'Every morning begins with possibility.',
    cta: 'See your mornings',
  },
  {
    key: 'growing-up',
    to: '/growing-up',
    img: playLawn,
    thumb: playGarden,
    eyebrow: 'For families',
    titleBn: 'ছোট থেকে বড় হওয়া।',
    sub: 'Growing up, without growing away.',
    cta: 'Grow up here',
  },
];

export const LANDMARKS = [
  { name: 'Chandannagar Heritage Museum', cat: 'leisure', label: 'Culture', icon: 'landmark', dist: '11 m', m: 11, time: '1 min' },
  { name: 'Chandannagar Post Office', cat: 'civic', label: 'Civic', icon: 'post', dist: '400 m', m: 400, time: '2 min' },
  { name: 'Chandannagar Sub-Divisional Hospital', cat: 'health', label: 'Healthcare', icon: 'hospital', dist: '500 m', m: 500, time: '2 min' },
  { name: 'St. Thomas School', cat: 'education', label: 'School', icon: 'school', dist: '500 m', m: 500, time: '2 min' },
  { name: 'Chandannagar Strand', cat: 'leisure', label: 'Riverfront', icon: 'water', dist: '600 m', m: 600, time: '2 min' },
  { name: 'Chandannagar Police Station', cat: 'civic', label: 'Civic', icon: 'shield', dist: '700 m', m: 700, time: '3 min' },
  { name: 'Chandannagar Ferry Ghat', cat: 'transit', label: 'Ferry', icon: 'boat', dist: '750 m', m: 750, time: '3 min' },
  { name: 'Chandernagore College', cat: 'education', label: 'College', icon: 'school', dist: '800 m', m: 800, time: '3 min' },
  { name: 'St. Joseph’s Convent School', cat: 'education', label: 'School', icon: 'school', dist: '1.1 km', m: 1100, time: '4 min' },
  { name: 'Chandannagar Railway Station', cat: 'transit', label: 'Rail', icon: 'train', dist: '1.5 km', m: 1500, time: '5 min' },
  { name: 'Modern Public School', cat: 'education', label: 'School', icon: 'school', dist: '2.1 km', m: 2100, time: '6 min' },
  { name: 'Chuchura Railway Station', cat: 'transit', label: 'Rail', icon: 'train', dist: '4.3 km', m: 4300, time: '12 min' },
];

export const LANDMARK_FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'transit', label: 'Transit' },
  { key: 'education', label: 'Education' },
  { key: 'health', label: 'Healthcare' },
  { key: 'leisure', label: 'Leisure' },
  { key: 'civic', label: 'Civic' },
];

export const AMENITIES = [
  { icon: 'lotus', name: 'Yoga deck', text: 'An open-air deck for sunrise asanas and quiet evening stretches.', group: 'wellness' },
  { icon: 'dumbbell', name: 'Gymnasium', text: 'Train close to home — before work or after it.', group: 'wellness' },
  { icon: 'racket', name: 'Badminton court', text: 'Weekend games and friendly rivalries with the neighbours.', group: 'wellness' },
  { icon: 'games', name: 'Games room', text: 'Carrom, cards and long afternoons indoors.', group: 'leisure' },
  { icon: 'hall', name: 'Community hall', text: 'For pujo gatherings, birthdays and society meets.', group: 'leisure' },
  { icon: 'party', name: 'Party lounge', text: 'Host celebrations without rearranging your home.', group: 'leisure' },
  { icon: 'tree', name: 'Party lawn', text: 'Open-air celebrations under the evening sky.', group: 'leisure' },
  { icon: 'slide', name: 'Kids’ play arena', text: 'Safe, green play space inside the gate.', group: 'family' },
  { icon: 'leaf', name: 'Podium garden', text: 'Landscaped greens and water to unwind beside.', group: 'family' },
  { icon: 'parking', name: 'Multi-level car parking', text: 'Dedicated MLCP parking for residents.', group: 'everyday' },
  { icon: 'shield', name: '24×7 security', text: 'Round-the-clock security for a gated community.', group: 'everyday' },
  { icon: 'cctv', name: 'CCTV monitoring', text: 'Camera surveillance at the ground-floor lobby.', group: 'everyday' },
  { icon: 'flame', name: 'Fire-fighting system', text: 'Fire suppression and detection provisions.', group: 'everyday' },
  { icon: 'bolt', name: 'Power back-up', text: 'Generator power for lighting and domestic use (at extra cost).', group: 'everyday' },
  { icon: 'drop', name: 'Filtered water', text: 'Municipal water supply with filtration.', group: 'everyday' },
  { icon: 'store', name: 'Retail outlet on campus', text: 'A commercial & retail outlet within the development.', group: 'everyday' },
];

export const SPECS = [
  {
    icon: 'key',
    title: 'Doors',
    items: [
      '35 mm thick flush doors in all rooms',
      'Shutters hung on brass barrel hinges',
      'Night latch on the main entrance door',
      'Cylindrical locks and door stoppers on bedroom and kitchen doors',
      'Bathroom latches, with enamel paint on the inside surface',
    ],
  },
  {
    icon: 'kitchen',
    title: 'Kitchen',
    items: [
      'Granite-top cooking platform',
      'Stainless steel sink',
      'Ceramic wall tiles up to 2 ft above the counter',
      'Quality ceramic tile flooring',
    ],
  },
  {
    icon: 'building',
    title: 'Walls',
    items: [
      'External walls in cement-sand plaster with cement paint and/or texture finish, glazing as per the architectural scheme',
      'Internal walls finished in neat gypsum',
      'Designer ceramic tiles up to door height in bathrooms',
    ],
  },
  {
    icon: 'blueprint',
    title: 'Flooring',
    items: [
      'Vitrified tiles in the living, dining and bedrooms',
      'Ceramic tiles in bathrooms, with anti-skid tiles on the floor',
      'Vitrified tiles with matching skirting in lift lobbies',
      'Italian marble in the ground-floor lobby',
      'Screed concrete in other common areas',
    ],
  },
  {
    icon: 'sun',
    title: 'Windows & balconies',
    items: [
      'Anodised / powder-coated aluminium or UPVC sliding windows with glass inserts and matching fittings',
      'Decorative glass railings with uninterrupted green views',
    ],
  },
  {
    icon: 'bolt',
    title: 'Electrical',
    items: [
      'Fully concealed copper wiring in all rooms',
      'AC points in all bedrooms and the living room',
      'Light and plug points in the drawing, dining and bedrooms as per the architectural scheme',
      'Telephone and cable-TV points in the living room and all bedrooms',
      'Geyser points in all toilets',
      'Generator back-up for lighting and domestic use (at extra cost)',
    ],
  },
  {
    icon: 'drop',
    title: 'CP fittings & sanitary ware',
    items: [
      'Concealed piping for hot and cold water lines',
      'Geyser in the master bathroom',
      'Sleek single-lever fittings by Jaquar or equivalent',
      'Porcelain sanitary ware by Parryware, Hindware or equivalent',
    ],
  },
  {
    icon: 'shield',
    title: 'Safety & services',
    items: [
      'Fire-fighting system provision',
      'CCTV monitoring at the ground-floor lobby',
      'Municipal water supply with filtration',
    ],
  },
];

export const CONFIGS = [
  { key: '2bhk', label: '2 BHK' },
  { key: '3bhk', label: '3 BHK' },
  { key: 'undecided', label: 'Not sure yet' },
];

export const SLOTS = ['Morning', 'Afternoon', 'Evening'];

// Context line on the site-visit page, keyed by the ?from= value of the CTA that sent the visitor.
export const FROM_COPY = {
  home: 'Come home to Chandannagar — and experience the difference in person.',
  professionals: 'Discover why Chandannagar’s professionals have chosen Shree Heights.',
  serene: 'Walk the greens, find the quiet corners and see where the evenings slow down.',
  mornings: 'See the spaces where your mornings will begin — from the yoga deck to the courts.',
  'growing-up': 'Bring the family along — let the children see where they’ll grow up.',
  residences: 'Walk through the 2 & 3 BHK homes and pick the one that fits.',
  'floor-plans': 'We’ll walk you through the floor plans, carpet areas and current availability.',
  amenities: 'See the amenities, the podium and the community spaces up close.',
  location: 'See how close everything really is — the Strand, the station, the schools.',
  developers: 'Meet the team behind Shree Heights and see the quality first-hand.',
  contact: 'Pick a day that suits you and we’ll take care of the rest.',
  gallery: 'Seen the pictures? Now see the real thing.',
  'virtual-tour': 'Loved the tour? Walk the site in person.',
  availability: 'Availability changes daily — we’ll show you the homes that are open right now.',
  brochure: 'We’ll hand you the brochure and walk you through the project.',
  partners: 'Bring your client along — we’ll take care of the visit.',
};

export const REFERRAL_PROPERTY_TYPES = [
  'Shree Heights — 2 BHK',
  'Shree Heights — 3 BHK',
  'Shree Heights — retail / commercial',
  'Not sure yet',
];

export const CONSENT_METHODS = ['In person', 'Phone call', 'WhatsApp / SMS', 'Email', 'Other'];
