import Icon from './Icon.jsx';
import { Reveal } from './Motion.jsx';

export default function AmenityGrid({ items }) {
  return (
    <ul className="amenities">
      {items.map((a, i) => (
        <Reveal as="li" className="amenity" key={a.name} delay={(i % 4) * 0.07}>
          <Icon name={a.icon} />
          <h3>{a.name}</h3>
          <p>{a.text}</p>
        </Reveal>
      ))}
    </ul>
  );
}
