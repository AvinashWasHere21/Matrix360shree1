import { useEffect, useRef } from 'react';
import {
  animate, motion, useInView, useMotionValue, useReducedMotion, useScroll, useSpring, useTransform,
} from 'motion/react';
import { EASE } from '../lib/motion.js';

const VIEWPORT = { once: true, margin: '0px 0px -10% 0px' };

/** Heavy fade-up as the element scrolls into view. */
export function Reveal({ as = 'div', delay = 0, y = 36, children, ...rest }) {
  const Tag = motion[as];
  return (
    <Tag
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={VIEWPORT}
      transition={{ duration: 1.1, ease: EASE, delay }}
      {...rest}
    >
      {children}
    </Tag>
  );
}

/** Fade-up on mount — for hero content that is already in view. */
export function Fade({ as = 'div', delay = 0, children, ...rest }) {
  const Tag = motion[as];
  return (
    <Tag
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, ease: EASE, delay }}
      {...rest}
    >
      {children}
    </Tag>
  );
}

/** Headline whose lines rise out of an invisible mask, one after another. */
export function MaskedLines({ as: Tag = 'h1', lines, className, delay = 0.12, step = 0.11, ...rest }) {
  return (
    <Tag className={className} {...rest}>
      {lines.map((line, i) => (
        <span className="line" key={i}>
          <motion.span
            initial={{ y: '108%' }}
            animate={{ y: 0 }}
            transition={{ duration: 1.15, ease: EASE, delay: delay + i * step }}
          >
            {line}{' '}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}

/** Pulls its child gently towards the cursor (mouse only). */
export function Magnetic({ children, strength = 0.22 }) {
  const ref = useRef(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const spring = { stiffness: 240, damping: 18, mass: 0.6 };
  const sx = useSpring(x, spring);
  const sy = useSpring(y, spring);

  const onPointerMove = (e) => {
    if (e.pointerType !== 'mouse' || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    x.set((e.clientX - r.left - r.width / 2) * strength);
    y.set((e.clientY - r.top - r.height / 2) * strength);
  };
  const reset = () => { x.set(0); y.set(0); };

  return (
    <motion.span ref={ref} className="magnetic" style={{ x: sx, y: sy }} onPointerMove={onPointerMove} onPointerLeave={reset}>
      {children}
    </motion.span>
  );
}

/** Image that drifts slower than the page as it scrolls past. */
export function Parallax({ src, alt = '', className = '', strength = 6, style, imgStyle, ...imgProps }) {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [`-${strength}%`, `${strength}%`]);
  return (
    <div ref={ref} className={`parallax ${className}`.trim()} style={style}>
      <motion.img src={src} alt={alt} style={reduce ? imgStyle : { y, scale: 1.15, ...imgStyle }} {...imgProps} />
    </div>
  );
}

/** Number that counts up the first time it is seen. */
export function CountUp({ value }) {
  const ref = useRef(null);
  const inView = useInView(ref, VIEWPORT);
  const reduce = useReducedMotion();
  const decimals = (String(value).split('.')[1] || '').length;
  const target = Number(value);

  useEffect(() => {
    if (!inView || reduce || !ref.current) return undefined;
    const controls = animate(0, target, {
      duration: 1.7,
      ease: EASE,
      onUpdate: (v) => { if (ref.current) ref.current.textContent = v.toFixed(decimals); },
    });
    return () => controls.stop();
  }, [inView, reduce, target, decimals]);

  return <span ref={ref}>{reduce ? value : (0).toFixed(decimals)}</span>;
}

/** Gold flourish whose lines draw outwards from the centre. */
export function Ornament({ className = 'ornament' }) {
  const draw = {
    initial: { pathLength: 0 },
    whileInView: { pathLength: 1 },
    viewport: VIEWPORT,
    transition: { duration: 1.6, ease: EASE, delay: 0.2 },
  };
  return (
    <svg className={className} viewBox="0 0 260 18" aria-hidden="true">
      <motion.path d="M106 9H0" {...draw} />
      <motion.path d="M154 9h106" {...draw} />
      <path d="M130 2.5 136.5 9 130 15.5 123.5 9z" />
      <path d="M130 6 133 9 130 12 127 9z" />
      <circle cx="115" cy="9" r="2.2" />
      <circle cx="145" cy="9" r="2.2" />
    </svg>
  );
}

/** Adds `is-in` once the element enters the viewport — for CSS-driven sequences. */
export function useInViewClass() {
  const ref = useRef(null);
  const inView = useInView(ref, VIEWPORT);
  return [ref, inView ? 'is-in' : ''];
}
