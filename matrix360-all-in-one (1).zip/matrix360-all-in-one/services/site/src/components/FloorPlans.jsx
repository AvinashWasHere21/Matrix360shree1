import { useCallback, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import Icon from './Icon.jsx';
import { VisitButton } from './Button.jsx';
import { Lightbox } from './Gallery.jsx';
import { FLOOR_PLANS, UNITS } from '../data/site.js';
import { EASE } from '../lib/motion.js';

/** Plan viewer: master plan, first floor, typical tower floors — with each tower's unit areas. */
export default function FloorPlans() {
  const [index, setIndex] = useState(2);
  const [zoomed, setZoomed] = useState(false);
  const plan = FLOOR_PLANS[index];
  const units = plan.tower ? UNITS.filter((u) => u.tower === plan.tower) : [];
  const items = FLOOR_PLANS.map((p) => ({ src: p.src, title: `${p.label} — floor plan` }));
  const onClose = useCallback(() => setZoomed(false), []);
  const onStep = useCallback((step) => setIndex((i) => (i + step + FLOOR_PLANS.length) % FLOOR_PLANS.length), []);

  return (
    <div className="frame">
      <div className="frame__core plans">
        <div className="plans__head">
          <h3 className="h3">Floor plans</h3>
          <div className="tabs" role="tablist" aria-label="Floor plan">
            {FLOOR_PLANS.map((p, i) => (
              <button key={p.key} type="button" role="tab" aria-selected={i === index} className="tab" onClick={() => setIndex(i)}>
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="plans__stage">
          <AnimatePresence mode="wait">
            <motion.button
              type="button" key={plan.key} className="plans__figure" onClick={() => setZoomed(true)}
              aria-label={`Enlarge the ${plan.label} plan`}
              initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }}
              transition={{ duration: 0.45, ease: EASE }}
            >
              <img src={plan.src} alt={`${plan.label} floor plan of Shree Heights`} width={plan.w} height={plan.h} loading="lazy" />
              <span className="plans__zoom"><Icon name="plus" />Tap to enlarge</span>
            </motion.button>
          </AnimatePresence>
          <button type="button" className="plans__nav plans__nav--prev" onClick={() => onStep(-1)} aria-label="Previous plan"><Icon name="arrow-r" /></button>
          <button type="button" className="plans__nav plans__nav--next" onClick={() => onStep(1)} aria-label="Next plan"><Icon name="arrow-r" /></button>
        </div>

        <p className="plans__note">{plan.note}</p>

        {units.length > 0 && (
          <div className="units" role="region" aria-label={`${plan.tower} unit areas`} tabIndex={0}>
            <table>
              <thead>
                <tr><th>Flat</th><th>Type</th><th>Carpet</th><th>Balcony</th><th>Built-up (with CB)</th><th>Chargeable</th></tr>
              </thead>
              <tbody>
                {units.map((u) => (
                  <tr key={u.flat}>
                    <td>{u.flat}</td>
                    <td>{u.type} <small>· {u.toilets} toilets</small></td>
                    <td><strong>{u.carpet}</strong></td>
                    <td>{u.balcony}</td>
                    <td>{u.builtUp}</td>
                    <td>{u.chargeable}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="small muted">Areas in sq ft, as printed on the published floor plans; subject to final measurement.</p>
          </div>
        )}

        <div className="plans__foot">
          <VisitButton from="floor-plans" size="sm">Discuss a plan with our team</VisitButton>
        </div>
      </div>
      <AnimatePresence>
        {zoomed && <Lightbox items={items} index={index} onClose={onClose} onStep={onStep} />}
      </AnimatePresence>
    </div>
  );
}
