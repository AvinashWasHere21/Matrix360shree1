import { useState } from 'react';
import Icon from './Icon.jsx';
import { useInViewClass } from './Motion.jsx';
import { LANDMARK_FILTERS, LANDMARKS } from '../data/site.js';

const FARTHEST = Math.max(...LANDMARKS.map((l) => l.m));

/** Every landmark with a bar scaled to its distance (square-root scale so short hops stay visible). */
export default function LandmarkRail({ filters = true }) {
  const [filter, setFilter] = useState('all');
  const [ref, inClass] = useInViewClass();

  return (
    <div className={`rail ${inClass}`.trim()} ref={ref}>
      {filters && (
        <div className="rail__filters" role="group" aria-label="Filter places by category">
          {LANDMARK_FILTERS.map((f) => (
            <button key={f.key} type="button" className="filter" aria-pressed={filter === f.key} onClick={() => setFilter(f.key)}>
              {f.label}
            </button>
          ))}
        </div>
      )}
      <div className="rail__list">
        <ol className="rail__core">
          {LANDMARKS.map((l, n) => (
            <li
              key={l.name}
              className={`rail__row${filter !== 'all' && l.cat !== filter ? ' is-dim' : ''}`}
              style={{ '--d': Math.max(0.04, Math.sqrt(l.m / FARTHEST)).toFixed(3), '--n': n }}
            >
              <span className="rail__icon"><Icon name={l.icon} /></span>
              <span className="rail__name">{l.name}<small>{l.label}</small></span>
              <span className="rail__bar" aria-hidden="true"><span /></span>
              <span className="rail__dist">{l.dist}<small>{l.time}</small></span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
