import { Link, useLocation } from 'react-router';
import Brand from './Brand.jsx';
import Button, { VisitButton } from './Button.jsx';
import Icon from './Icon.jsx';
import { Ornament, Reveal } from './Motion.jsx';
import { CONTACT, NAV, NAV_MORE, STORIES, whatsappLink } from '../data/site.js';
import { pageKey, visitHref } from '../lib/routes.js';

export function CtaBand() {
  return (
    <section className="cta-band" aria-labelledby="cta-band-title">
      <div className="container cta-band__inner">
        <Ornament />
        <Reveal as="h2" className="h2" id="cta-band-title">
          Live the next chapter <em>in Chandannagar.</em>
        </Reveal>
        <Reveal as="p" delay={0.08}>
          Walk the site, see the homes and meet the team. Site visits are free, with no obligation.
        </Reveal>
        <Reveal className="cta-band__actions" delay={0.16}>
          <VisitButton variant="light" />
          <Button href={CONTACT.office.href} variant="outline-light" icon="phone">Call {CONTACT.office.label}</Button>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  const { pathname } = useLocation();
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer__grid">
          <div className="footer__brand">
            <Brand />
            <p>Gated 2 &amp; 3 BHK residences in the heart of heritage Chandannagar.</p>
            <p className="small">{CONTACT.address[0]}<br />{CONTACT.address[1]}</p>
          </div>

          <nav aria-label="Explore">
            <h3>Explore</h3>
            <ul>
              {[...NAV, ...NAV_MORE].map((item) => (
                <li key={item.to}><Link to={item.to} viewTransition>{item.label}</Link></li>
              ))}
              <li><Link to={visitHref(pageKey(pathname))} viewTransition>Book a site visit</Link></li>
            </ul>
          </nav>

          <nav aria-label="Life here">
            <h3>Life here</h3>
            <ul>
              {STORIES.map((story) => (
                <li key={story.key}>
                  {story.titleBn
                    ? <Link to={story.to} className="bn" lang="bn" viewTransition>{story.titleBn.replace('।', '')}</Link>
                    : <Link to={story.to} viewTransition>{story.short}</Link>}
                </li>
              ))}
            </ul>
          </nav>

          <div className="footer__contact">
            <h3>Talk to us</h3>
            <ul>
              <li><a href={CONTACT.office.href}>{CONTACT.office.label}</a></li>
              <li><a href={CONTACT.mobile.href}>{CONTACT.mobile.label}</a></li>
              <li><a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></li>
            </ul>
            <div className="footer__social">
              {CONTACT.social.map((s) => (
                <a key={s.icon} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={`Shree Heights on ${s.label}`}>
                  <Icon name={s.icon} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="footer__base">
          <p>
            © {new Date().getFullYear()} Shree Heights. Owners &amp; developers: {CONTACT.developer}, {CONTACT.developerAddress}.{' '}
            <a href={CONTACT.rera} target="_blank" rel="noopener noreferrer">RERA certificate</a>
          </p>
          <p>
            Images are artistic impressions for representation only. Specifications, amenities and prices are indicative
            and subject to change — please confirm the details with our sales team before booking.
          </p>
        </div>
      </div>
    </footer>
  );
}

export function ActionBar({ showVisit = true }) {
  const { pathname } = useLocation();
  return (
    <nav className={`action-bar${showVisit ? '' : ' action-bar--two'}`} aria-label="Quick actions">
      <a href={CONTACT.mobile.href}><Icon name="phone" />Call</a>
      <a href={whatsappLink()} target="_blank" rel="noopener noreferrer"><Icon name="whatsapp" />WhatsApp</a>
      {showVisit && (
        <Link className="action-bar__primary" to={visitHref(pageKey(pathname))} viewTransition>
          <Icon name="calendar" />Book a visit
        </Link>
      )}
    </nav>
  );
}
