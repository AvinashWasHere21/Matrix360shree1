import { Link } from 'react-router';

export function BrandMark({ className = 'brand__mark' }) {
  return (
    <svg className={className} viewBox="10 8 105 154" aria-hidden="true">
      <path d="M47 36 33 48v101h-8v-41l-13 12v40h35z" />
      <path d="M55 20 62.5 11 70 20v92H55z" />
      <path d="M55 120h15v40H55z" />
      <path d="m78 36 14 12v101h8v-41l13 12v40H78z" />
    </svg>
  );
}

export default function Brand({ light = false }) {
  return (
    <Link className={`brand${light ? ' brand--light' : ''}`} to="/" viewTransition aria-label="Shree Heights — home">
      <BrandMark />
      <span className="brand__word">
        <span className="brand__shree">Shree</span>
        <span className="brand__heights">Heights</span>
      </span>
    </Link>
  );
}
