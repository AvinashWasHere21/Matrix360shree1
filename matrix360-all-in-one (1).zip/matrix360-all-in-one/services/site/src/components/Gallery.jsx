import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import Icon from './Icon.jsx';
import { GALLERY, GALLERY_TABS } from '../data/site.js';
import { EASE } from '../lib/motion.js';

export function Lightbox({ items, index, onClose, onStep }) {
  const item = items[index];
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onStep(1);
      if (e.key === 'ArrowLeft') onStep(-1);
    };
    document.addEventListener('keydown', onKey);
    document.documentElement.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.documentElement.style.overflow = '';
    };
  }, [onClose, onStep]);

  return (
    <motion.div
      className="lightbox" role="dialog" aria-modal="true" aria-label={item.title}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.35 }}
      onClick={onClose}
    >
      <AnimatePresence mode="wait">
        <motion.figure
          key={index} className="lightbox__figure" onClick={(e) => e.stopPropagation()}
          initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.45, ease: EASE }}
        >
          <img src={item.src} alt={item.title} />
          <figcaption>{item.title}<span>{index + 1} / {items.length}</span></figcaption>
        </motion.figure>
      </AnimatePresence>
      <button type="button" className="lightbox__close" onClick={onClose} aria-label="Close gallery"><Icon name="plus" /></button>
      <button type="button" className="lightbox__nav lightbox__nav--prev" onClick={(e) => { e.stopPropagation(); onStep(-1); }} aria-label="Previous image"><Icon name="arrow-r" /></button>
      <button type="button" className="lightbox__nav lightbox__nav--next" onClick={(e) => { e.stopPropagation(); onStep(1); }} aria-label="Next image"><Icon name="arrow-r" /></button>
    </motion.div>
  );
}

export default function Gallery({ limit }) {
  const [tab, setTab] = useState('all');
  const [open, setOpen] = useState(null);
  const items = GALLERY.filter((g) => tab === 'all' || g.cat === tab).slice(0, limit);
  const onClose = useCallback(() => setOpen(null), []);
  const onStep = useCallback((step) => setOpen((i) => (i + step + items.length) % items.length), [items.length]);

  return (
    <div className="gallery">
      <div className="tabs" role="tablist" aria-label="Gallery category">
        {GALLERY_TABS.map((t) => (
          <button key={t.key} type="button" role="tab" aria-selected={tab === t.key} className="tab" onClick={() => setTab(t.key)}>
            {t.label}
          </button>
        ))}
      </div>
      <motion.ul className="gallery__grid" layout>
        <AnimatePresence initial={false}>
          {items.map((g, i) => (
            <motion.li
              key={g.title} layout className={g.w / g.h > 1.8 ? 'is-wide' : ''}
              initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.6, ease: EASE, delay: i * 0.04 }}
            >
              <button type="button" onClick={() => setOpen(i)} aria-label={`Open image: ${g.title}`}>
                <img src={g.src} alt="" loading="lazy" />
                <span className="gallery__caption">{g.title}<Icon name="plus" /></span>
              </button>
            </motion.li>
          ))}
        </AnimatePresence>
      </motion.ul>
      <AnimatePresence>
        {open !== null && items[open] && <Lightbox items={items} index={open} onClose={onClose} onStep={onStep} />}
      </AnimatePresence>
    </div>
  );
}
