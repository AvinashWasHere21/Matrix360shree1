import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import Icon from './Icon.jsx';
import { TOUR_SCENES } from '../data/site.js';

const MIN_ZOOM = 1.15;
const MAX_ZOOM = 2.2;

/**
 * Drag-to-look panorama viewer with inertia, keyboard and zoom controls.
 * Scenes marked `loop` (2:1 equirectangular 360° images) wrap around and slowly auto-rotate.
 */
export default function TourViewer() {
  const [sceneIndex, setSceneIndex] = useState(0);
  const [hint, setHint] = useState(true);
  const scene = TOUR_SCENES[sceneIndex];
  const stage = useRef(null);
  const s = useRef({ x: 0, y: 0, vx: 0, vy: 0, zoom: MIN_ZOOM, ratio: 0, iw: 0, ih: 0, drag: null, raf: 0, idle: true });

  const apply = useCallback(() => {
    const el = stage.current;
    const st = s.current;
    if (!el || !st.ratio) return;
    const w = el.clientWidth;
    const h = el.clientHeight;
    if (scene.loop) {
      st.x = ((st.x % st.iw) + st.iw) % st.iw - st.iw;
    } else {
      st.x = Math.min(0, Math.max(w - st.iw, st.x));
    }
    st.y = Math.min(0, Math.max(h - st.ih, st.y));
    el.style.backgroundPosition = `${st.x}px ${st.y}px`;
  }, [scene.loop]);

  const layout = useCallback((keepCentre = false) => {
    const el = stage.current;
    const st = s.current;
    if (!el || !st.ratio) return;
    const w = el.clientWidth;
    const h = el.clientHeight;
    const cx = keepCentre && st.iw ? (w / 2 - st.x) / st.iw : 0.5;
    const cy = keepCentre && st.ih ? (h / 2 - st.y) / st.ih : 0.5;
    let ih = h * st.zoom;
    let iw = ih * st.ratio;
    if (iw < w * st.zoom) { iw = w * st.zoom; ih = iw / st.ratio; }
    st.iw = iw; st.ih = ih;
    st.x = w / 2 - cx * iw;
    st.y = h / 2 - cy * ih;
    el.style.backgroundSize = `${iw}px ${ih}px`;
    el.style.backgroundRepeat = scene.loop ? 'repeat-x' : 'no-repeat';
    apply();
  }, [apply, scene.loop]);

  // Load the scene image to learn its proportions.
  useEffect(() => {
    const st = s.current;
    st.ratio = 0; st.zoom = MIN_ZOOM; st.vx = 0; st.vy = 0;
    const img = new Image();
    img.onload = () => { st.ratio = img.naturalWidth / img.naturalHeight; layout(); };
    img.src = scene.src;
    const ro = new ResizeObserver(() => layout(true));
    if (stage.current) ro.observe(stage.current);
    return () => ro.disconnect();
  }, [scene.src, layout]);

  // Inertia + auto-rotate loop.
  useEffect(() => {
    const st = s.current;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const tick = () => {
      if (!st.drag) {
        if (Math.abs(st.vx) > 0.05 || Math.abs(st.vy) > 0.05) {
          st.x += st.vx; st.y += st.vy; st.vx *= 0.93; st.vy *= 0.93; apply();
        } else if (scene.loop && st.idle && !reduce) {
          st.x -= 0.25; apply();
        }
      }
      st.raf = requestAnimationFrame(tick);
    };
    st.raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(st.raf);
  }, [apply, scene.loop]);

  const onPointerDown = (e) => {
    const st = s.current;
    st.drag = { x: e.clientX, y: e.clientY };
    st.vx = 0; st.vy = 0; st.idle = false;
    setHint(false);
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e) => {
    const st = s.current;
    if (!st.drag) return;
    const dx = e.clientX - st.drag.x;
    const dy = e.clientY - st.drag.y;
    st.drag = { x: e.clientX, y: e.clientY };
    st.x += dx; st.y += dy; st.vx = dx; st.vy = dy;
    apply();
  };
  const onPointerUp = () => { s.current.drag = null; };

  const nudge = (dx, dy = 0) => { const st = s.current; st.vx = dx; st.vy = dy; st.idle = false; setHint(false); };
  const zoom = (factor) => {
    const st = s.current;
    st.zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, st.zoom * factor));
    layout(true);
  };
  const onKeyDown = (e) => {
    const keys = { ArrowLeft: [14, 0], ArrowRight: [-14, 0], ArrowUp: [0, 10], ArrowDown: [0, -10] };
    if (keys[e.key]) { e.preventDefault(); nudge(...keys[e.key]); }
    if (e.key === '+' || e.key === '=') zoom(1.15);
    if (e.key === '-') zoom(1 / 1.15);
  };
  const fullscreen = () => {
    const el = stage.current?.parentElement;
    if (!document.fullscreenElement) el?.requestFullscreen?.();
    else document.exitFullscreen?.();
  };

  return (
    <div className="tour">
      <div className="tour__frame">
        <div
          ref={stage}
          className="tour__stage"
          style={{ backgroundImage: `url(${scene.src})` }}
          role="img"
          aria-label={`${scene.title} — drag or use the arrow keys to look around`}
          tabIndex={0}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          onKeyDown={onKeyDown}
        />
        <span className="tour__badge">{scene.loop ? '360°' : 'Pan'}<small>{scene.title}</small></span>
        <div className="tour__tools">
          <button type="button" onClick={() => zoom(1.15)} aria-label="Zoom in"><Icon name="plus" /></button>
          <button type="button" onClick={() => zoom(1 / 1.15)} aria-label="Zoom out"><span className="tour__minus" aria-hidden="true" /></button>
          <button type="button" onClick={fullscreen} aria-label="Toggle full screen"><Icon name="arrow" /></button>
        </div>
        <div className="tour__pad" aria-hidden="true">
          <button type="button" tabIndex={-1} onClick={() => nudge(0, 12)} className="up"><Icon name="chevron" /></button>
          <button type="button" tabIndex={-1} onClick={() => nudge(18)} className="left"><Icon name="chevron" /></button>
          <button type="button" tabIndex={-1} onClick={() => nudge(-18)} className="right"><Icon name="chevron" /></button>
          <button type="button" tabIndex={-1} onClick={() => nudge(0, -12)} className="down"><Icon name="chevron" /></button>
        </div>
        <AnimatePresence>
          {hint && (
            <motion.span className="tour__hint" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              Drag to look around
            </motion.span>
          )}
        </AnimatePresence>
      </div>
      <div className="tour__scenes" role="tablist" aria-label="Tour scenes">
        {TOUR_SCENES.map((sc, i) => (
          <button
            key={sc.key} type="button" role="tab" aria-selected={i === sceneIndex}
            className="tour__thumb" onClick={() => { setSceneIndex(i); setHint(true); }}
          >
            <img src={sc.src} alt="" loading="lazy" />
            <span>{sc.title}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
