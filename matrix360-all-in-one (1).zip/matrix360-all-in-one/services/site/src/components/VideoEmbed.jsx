import { useState } from 'react';
import Icon from './Icon.jsx';

/** YouTube embed that only loads the player after the visitor asks for it. */
export default function VideoEmbed({ id, poster, label }) {
  const [playing, setPlaying] = useState(false);
  return (
    <div className="frame">
      <div className="frame__core video">
        {playing ? (
          <iframe
            src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0`}
            title={label}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        ) : (
          <button className="video__poster" type="button" aria-label={`Play video: ${label}`} onClick={() => setPlaying(true)}>
            <img src={poster} alt="" loading="lazy" />
            <span className="video__play"><Icon name="play" /></span>
            <span className="video__label">{label}</span>
          </button>
        )}
      </div>
    </div>
  );
}
