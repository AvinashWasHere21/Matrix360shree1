import { useEffect, useId, useRef, useState } from 'react';
import Button from './Button.jsx';
import { Choices, Field, formatDate, isEmail, isPhone, isUrl, todayISO } from './FormFields.jsx';
import { CONSENT_METHODS, CONTACT, FORM_ENDPOINT, REFERRAL_PROPERTY_TYPES, whatsappLink } from '../data/site.js';
import { readAttribution } from '../lib/attribution.js';

const INTENTS = {
  register: 'Register as a broker / referral partner',
  lead: 'Submit a specific lead',
};
const CONSENT = { yes: 'Yes, they agreed', no: 'No', notAsked: 'Not asked yet' };
const UNKNOWN = 'Unknown';

const EMPTY = {
  partnerName: '', firm: '', partnerPhone: '', partnerEmail: '', linkedin: '',
  intent: INTENTS.register,
  leadName: '', leadCompany: '', leadPhone: '', leadEmail: '',
  unknown: { leadCompany: false, leadPhone: false, leadEmail: false },
  propertyType: '', reason: '', evidence: '', referralId: '',
  consent: '', consentMethod: '', consentDate: '', consentNote: '',
  about: '',
};

function validate(v) {
  const e = {};
  if (!v.partnerName.trim()) e.partnerName = 'Please enter your name.';
  if (!isPhone(v.partnerPhone)) e.partnerPhone = 'Please enter a valid 10-digit mobile number.';
  if (!isEmail(v.partnerEmail.trim())) e.partnerEmail = 'Please enter a valid email address.';
  if (v.linkedin.trim() && !(isUrl(v.linkedin.trim()) && /linkedin\.com/i.test(v.linkedin))) e.linkedin = 'Please paste a full linkedin.com profile or company URL.';

  if (v.intent === INTENTS.lead) {
    if (!v.leadName.trim() && !v.leadCompany.trim()) e.leadName = 'Add the prospect’s name or company.';
    if (!v.unknown.leadPhone && v.leadPhone.trim() && !isPhone(v.leadPhone)) e.leadPhone = 'Check the number, or mark it as unknown.';
    if (!v.unknown.leadEmail && v.leadEmail.trim() && !isEmail(v.leadEmail.trim())) e.leadEmail = 'Check the email, or mark it as unknown.';
    if (!v.propertyType) e.propertyType = 'Choose what the prospect is looking for.';
    if (!v.reason.trim()) e.reason = 'Tell us briefly why this lead may be relevant.';
    if (v.evidence.trim() && !isUrl(v.evidence.trim())) e.evidence = 'Please paste a full link starting with https://';
    if (v.consent !== CONSENT.yes) {
      e.consent = 'We can only accept a lead once the prospect has agreed to share their details for this enquiry.';
    } else {
      if (!v.consentMethod) e.consentMethod = 'How did they agree?';
      if (!v.consentDate) e.consentDate = 'When did they agree?';
      else if (v.consentDate > todayISO()) e.consentDate = 'The date can’t be in the future.';
    }
  }
  return e;
}

const ORDER = ['partnerName', 'partnerPhone', 'partnerEmail', 'linkedin', 'leadName', 'leadPhone', 'leadEmail', 'propertyType', 'reason', 'evidence', 'consent', 'consentMethod', 'consentDate'];

/** Builds the record we send. Partner approval is deliberately absent — it is set internally, never by this form. */
function buildRecord(v) {
  const lead = v.intent === INTENTS.lead;
  const known = (key) => (v.unknown[key] || !v[key].trim() ? UNKNOWN : v[key].trim());
  return {
    kind: 'referral',
    intent: lead ? 'lead' : 'register',
    partner: {
      name: v.partnerName.trim(),
      firm: v.firm.trim() || UNKNOWN,
      phone: v.partnerPhone.trim(),
      email: v.partnerEmail.trim(),
      linkedin: v.linkedin.trim() || null,
      about: v.about.trim() || null,
    },
    lead: lead ? {
      name: v.leadName.trim() || UNKNOWN,
      company: known('leadCompany'),
      phone: known('leadPhone'),
      email: known('leadEmail'),
      propertyType: v.propertyType,
      reason: v.reason.trim(),
      evidence: v.evidence.trim() || null,
      referralId: v.referralId.trim() || null,
      consent: {
        given: true,
        scope: 'This enquiry only — not consent for wider marketing',
        method: v.consentMethod,
        obtainedOn: v.consentDate,
        note: v.consentNote.trim() || null,
        assertedBy: 'partner',
      },
    } : null,
    submittedAt: new Date().toISOString(),
  };
}

function toMessage(r) {
  const lines = [r.lead ? 'Hello Shree Heights, I’d like to refer a lead.' : 'Hello Shree Heights, I’d like to register as a referral partner.'];
  const add = (label, value) => { if (value) lines.push(`${label}: ${value}`); };
  lines.push('', '— Partner —');
  add('Name', r.partner.name);
  add('Firm', r.partner.firm);
  add('Phone', r.partner.phone);
  add('Email', r.partner.email);
  add('LinkedIn', r.partner.linkedin);
  add('About', r.partner.about);
  if (r.lead) {
    const l = r.lead;
    lines.push('', '— Lead —');
    add('Name', l.name);
    add('Company', l.company);
    add('Phone', l.phone);
    add('Email', l.email);
    add('Looking for', l.propertyType);
    add('Why relevant', l.reason);
    add('Evidence / source', l.evidence);
    add('Referral ID', l.referralId);
    lines.push('', '— Consent —');
    add('Prospect agreed to share details', `Yes, for this enquiry only (${l.consent.method}, ${formatDate(l.consent.obtainedOn)})`);
    add('Consent note', l.consent.note);
  }
  return lines.join('\n');
}

export default function ReferralForm() {
  const uid = useId();
  const id = (name) => `${uid}-${name}`;
  const [v, setV] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');
  const [waUrl, setWaUrl] = useState('');
  const successRef = useRef(null);
  const isLead = v.intent === INTENTS.lead;

  useEffect(() => { if (status === 'delivered' || status === 'whatsapp') successRef.current?.focus(); }, [status]);

  const set = (key) => (e) => {
    const value = typeof e === 'string' ? e : e.target.value;
    setV((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
  };
  const toggleUnknown = (key) => (e) => {
    const checked = e.target.checked;
    setV((prev) => ({ ...prev, [key]: checked ? '' : prev[key], unknown: { ...prev.unknown, [key]: checked } }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const found = validate(v);
    setErrors(found);
    const first = ORDER.find((k) => found[k]);
    if (first) { document.getElementById(id(first))?.focus(); return; }

    const record = buildRecord(v);
    const url = whatsappLink(toMessage(record));
    setWaUrl(url);

    if (!FORM_ENDPOINT) {
      window.open(url, '_blank', 'noopener');
      setStatus('whatsapp');
      return;
    }
    setStatus('sending');
    try {
      const res = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ ...record, attribution: readAttribution() }),
      });
      setStatus(res.ok ? 'delivered' : 'whatsapp');
    } catch {
      setStatus('whatsapp');
    }
  };

  if (status === 'delivered' || status === 'whatsapp') {
    return (
      <div className="form-success" ref={successRef} tabIndex={-1} role="status">
        <span className="success-mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5" /></svg></span>
        <h2 className="h3">Thank you, {v.partnerName.trim().split(/\s+/)[0]}.</h2>
        <p>
          {status === 'delivered'
            ? 'We’ve received your submission. Our partnerships team will review it and get in touch.'
            : 'One last step — send the pre-filled message on WhatsApp so our team can review it. If WhatsApp didn’t open, use the button below.'}
        </p>
        <div className="hero__ctas">
          <Button href={waUrl} target="_blank" rel="noopener noreferrer" icon="whatsapp">Send on WhatsApp</Button>
          <Button href={CONTACT.office.href} variant="ghost" icon="phone">Call {CONTACT.office.label}</Button>
        </div>
      </div>
    );
  }

  const textInput = (key, props = {}) => (
    <input
      id={id(key)} value={v[key]} onChange={set(key)} aria-invalid={!!errors[key]}
      aria-describedby={errors[key] ? `${id(key)}-error` : undefined} {...props}
    />
  );

  const unknownField = (key, label, props) => (
    <Field id={id(key)} label={label} optional error={errors[key]}>
      {textInput(key, { disabled: v.unknown[key], placeholder: v.unknown[key] ? 'Marked as unknown' : props.placeholder, ...props })}
      <label className="check">
        <input type="checkbox" checked={v.unknown[key]} onChange={toggleUnknown(key)} />
        <span>Unknown</span>
      </label>
    </Field>
  );

  return (
    <form className="form" noValidate onSubmit={onSubmit}>
      <fieldset className="form__group">
        <legend>1 · About you</legend>
        <div className="form__row">
          <Field id={id('partnerName')} label="Your name" error={errors.partnerName}>{textInput('partnerName', { autoComplete: 'name' })}</Field>
          <Field id={id('firm')} label="Firm / company" optional>{textInput('firm', { autoComplete: 'organization', placeholder: 'Independent? Leave blank' })}</Field>
        </div>
        <div className="form__row">
          <Field id={id('partnerPhone')} label="Mobile number" error={errors.partnerPhone}>{textInput('partnerPhone', { type: 'tel', inputMode: 'tel', autoComplete: 'tel' })}</Field>
          <Field id={id('partnerEmail')} label="Email" error={errors.partnerEmail}>{textInput('partnerEmail', { type: 'email', autoComplete: 'email' })}</Field>
        </div>
        <Field id={id('linkedin')} label="LinkedIn URL" optional error={errors.linkedin}>
          {textInput('linkedin', { type: 'url', inputMode: 'url', placeholder: 'https://www.linkedin.com/in/…' })}
        </Field>
      </fieldset>

      <fieldset className="form__group">
        <legend>2 · What would you like to do?</legend>
        <Choices legend="I want to" name={id('intent')} options={Object.values(INTENTS)} value={v.intent} onChange={set('intent')} />
        {!isLead && (
          <Field id={id('about')} label="Tell us about your work" optional>
            <textarea id={id('about')} rows="3" value={v.about} onChange={set('about')} placeholder="Areas you cover, the kind of buyers you work with…" />
          </Field>
        )}
      </fieldset>

      {isLead && (
        <>
          <fieldset className="form__group">
            <legend>3 · The lead</legend>
            <p className="form__hint">Share only what you know — mark anything else as unknown.</p>
            <div className="form__row">
              <Field id={id('leadName')} label="Prospect’s name" error={errors.leadName}>{textInput('leadName')}</Field>
              {unknownField('leadCompany', 'Company', { placeholder: 'Where they work' })}
            </div>
            <div className="form__row">
              {unknownField('leadPhone', 'Phone', { type: 'tel', inputMode: 'tel', placeholder: '98XXX XXXXX' })}
              {unknownField('leadEmail', 'Email', { type: 'email', placeholder: 'name@example.com' })}
            </div>
            <Field id={id('propertyType')} label="Property type / project" error={errors.propertyType}>
              <select id={id('propertyType')} value={v.propertyType} onChange={set('propertyType')} aria-invalid={!!errors.propertyType}>
                <option value="">Choose one</option>
                {REFERRAL_PROPERTY_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field id={id('reason')} label="Why might this lead be relevant?" error={errors.reason}>
              <textarea id={id('reason')} rows="3" maxLength={300} value={v.reason} onChange={set('reason')} aria-invalid={!!errors.reason} placeholder="e.g. Relocating to Chandannagar, looking for a 3 BHK near schools" />
            </Field>
            <div className="form__row">
              <Field id={id('evidence')} label="Evidence / source link" optional error={errors.evidence}>{textInput('evidence', { type: 'url', inputMode: 'url', placeholder: 'https://' })}</Field>
              <Field id={id('referralId')} label="Referral ID" optional>{textInput('referralId', { placeholder: 'If you have one' })}</Field>
            </div>
          </fieldset>

          <fieldset className="form__group">
            <legend>4 · Consent</legend>
            <Choices
              id={id('consent')}
              legend="Has the prospect agreed to have their details shared for this enquiry?"
              name={id('consent-choice')} options={Object.values(CONSENT)} value={v.consent} onChange={set('consent')}
              error={errors.consent}
            />
            {v.consent === CONSENT.yes && (
              <>
                <div className="form__row">
                  <Field id={id('consentMethod')} label="How did they agree?" error={errors.consentMethod}>
                    <select id={id('consentMethod')} value={v.consentMethod} onChange={set('consentMethod')} aria-invalid={!!errors.consentMethod}>
                      <option value="">Choose one</option>
                      {CONSENT_METHODS.map((m) => <option key={m}>{m}</option>)}
                    </select>
                  </Field>
                  <Field id={id('consentDate')} label="When?" error={errors.consentDate}>
                    {textInput('consentDate', { type: 'date', max: todayISO() })}
                  </Field>
                </div>
                <Field id={id('consentNote')} label="Anything else about the consent?" optional>
                  {textInput('consentNote', { placeholder: 'e.g. Agreed on a call, prefers evening calls' })}
                </Field>
              </>
            )}
            <p className="form__hint">
              Consent covers this enquiry only. We will use the prospect’s details to respond to this enquiry and
              not for other marketing unless they opt in themselves.
            </p>
          </fieldset>
        </>
      )}

      <Button type="submit" block disabled={status === 'sending'} icon={FORM_ENDPOINT ? 'arrow' : 'whatsapp'}>
        {status === 'sending' ? 'Sending…' : isLead ? 'Submit lead for review' : 'Register as a partner'}
      </Button>
      <p className="form__legal">
        Every submission is reviewed by our team before any partnership is confirmed.
        {!FORM_ENDPOINT && ' Your submission opens in WhatsApp, ready to send.'}
      </p>
    </form>
  );
}
