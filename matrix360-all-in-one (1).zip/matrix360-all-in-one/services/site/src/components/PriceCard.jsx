import { PRICE } from '../data/site.js';

export default function PriceCard({ inline = false, className = '' }) {
  if (inline) {
    return (
      <div className={`price-card price-card--inline ${className}`.trim()}>
        <div className="price-card__core">
          <span className="price-card__label">{PRICE.configs}<span>Homes</span></span>
          <span className="price-card__divider" aria-hidden="true" />
          <span className="price-card__value">{PRICE.from} <span>{PRICE.unit}</span></span>
          <span className="price-card__note">onwards</span>
        </div>
      </div>
    );
  }
  return (
    <div className={`price-card ${className}`.trim()}>
      <div className="price-card__core">
        <span className="price-card__label">{PRICE.configs} Homes</span>
        <span className="price-card__value">{PRICE.from} <span>{PRICE.unit}</span></span>
        <span className="price-card__note">onwards</span>
      </div>
    </div>
  );
}
