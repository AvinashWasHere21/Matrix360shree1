import Button from './Button.jsx';
import { CONTACT } from '../data/site.js';

/** Embedded Google Map with a card that opens the exact location in Google Maps. */
export default function MapViewer() {
  return (
    <div className="frame">
      <div className="frame__core map-viewer">
        <iframe src={CONTACT.mapEmbed} title="Map showing Shree Heights, Chandannagar" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
        <div className="map-card">
          <strong>Shree Heights</strong>
          <span>{CONTACT.address[0]} {CONTACT.address[1]}</span>
          <div className="map-card__actions">
            <Button href={CONTACT.directions} target="_blank" rel="noopener noreferrer" size="sm" icon="pin">Open in Google Maps</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
