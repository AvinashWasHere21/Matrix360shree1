// Shared building blocks for the lead and referral forms.

export const isPhone = (v) => /^(?:\+?91)?[6-9]\d{9}$/.test(v.replace(/[\s().-]/g, '').replace(/^0/, ''));
export const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

export const todayISO = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};

export const formatDate = (iso) => new Date(`${iso}T00:00:00`).toLocaleDateString('en-IN', {
  weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
});

export const isUrl = (v) => { try { const u = new URL(v); return u.protocol === 'https:' || u.protocol === 'http:'; } catch { return false; } };

export function Field({ id, label, optional, error, children }) {
  return (
    <div className={`field${error ? ' is-invalid' : ''}`}>
      <label htmlFor={id}>{label}{optional && <span> (optional)</span>}</label>
      {children}
      {error && <span className="field__error" id={`${id}-error`}>{error}</span>}
    </div>
  );
}

export function Choices({ legend, name, options, value, onChange, error, id }) {
  return (
    <fieldset className={`field${error ? ' is-invalid' : ''}`} id={id} tabIndex={error ? -1 : undefined}>
      <legend className="field__label">{legend}</legend>
      <div className="choices">
        {options.map((option) => (
          <label className="choice" key={option}>
            <input type="radio" name={name} value={option} checked={value === option} onChange={() => onChange(option)} />
            <span>{option}</span>
          </label>
        ))}
      </div>
      {error && <span className="field__error">{error}</span>}
    </fieldset>
  );
}

