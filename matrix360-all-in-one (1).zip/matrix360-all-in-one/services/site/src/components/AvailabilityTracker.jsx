import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import Button, { VisitButton } from './Button.jsx';
import { whatsappLink } from '../data/site.js';
import { EASE } from '../lib/motion.js';

const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

/**
 * Reads public/availability.json at runtime, so the sales team can update numbers without a rebuild.
 * Until real numbers are filled in, it shows a "check today's availability" state — never made-up figures.
 */
export default function AvailabilityTracker() {
  const [data, setData] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    fetch(`${import.meta.env.BASE_URL}availability.json`, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((json) => { if (alive) setData(json); })
      .catch(() => { if (alive) setFailed(true); });
    return () => { alive = false; };
  }, []);

  const units = data?.units ?? [];
  const configured = units.length > 0 && units.every((u) => isNum(u.total) && isNum(u.available));
  const total = units.reduce((n, u) => n + (u.total || 0), 0);
  const available = units.reduce((n, u) => n + (u.available || 0), 0);
  const sold = total - available;
  const share = total ? sold / total : 0;

  return (
    <div className="frame">
      <div className="frame__core avail">
        <div className="avail__head">
          <h3 className="h3">Flat availability</h3>
          <span className={`avail__live${configured ? '' : ' is-off'}`}>{configured ? 'Live' : 'Updated daily'}</span>
        </div>

        {configured ? (
          <>
            <div className="avail__summary">
              <svg className="donut" viewBox="0 0 120 120" role="img" aria-label={`${sold} of ${total} flats sold, ${available} available`}>
                <circle cx="60" cy="60" r="48" className="donut__track" />
                <motion.circle
                  cx="60" cy="60" r="48" className="donut__value"
                  initial={{ pathLength: 0 }} whileInView={{ pathLength: share }} viewport={{ once: true }}
                  transition={{ duration: 1.6, ease: EASE }}
                />
                <text x="60" y="56" className="donut__label">Total flats</text>
                <text x="60" y="76" className="donut__total">{total}</text>
              </svg>
              <dl className="avail__legend">
                <div><dt><i className="dot dot--sold" />Sold</dt><dd>{sold}</dd></div>
                <div><dt><i className="dot dot--open" />Available</dt><dd>{available}</dd></div>
              </dl>
            </div>
            <div className="avail__units">
              <span className="kicker">By unit type</span>
              {units.map((u) => (
                <div className="avail__unit" key={u.type}>
                  <span>{u.type}</span>
                  <span className="avail__bar">
                    <motion.span
                      initial={{ scaleX: 0 }} whileInView={{ scaleX: u.total ? (u.total - u.available) / u.total : 0 }}
                      viewport={{ once: true }} transition={{ duration: 1.4, ease: EASE, delay: 0.2 }}
                    />
                  </span>
                  <strong>{u.available} available</strong>
                </div>
              ))}
            </div>
            {data.updatedAt && (
              <p className="small muted">
                Updated {new Date(data.updatedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </p>
            )}
          </>
        ) : (
          <div className="avail__empty">
            <p>
              Homes are moving quickly and availability changes every day. Ask our team for today’s open
              2 &amp; 3 BHK units, floors and facings.
            </p>
            {failed && <p className="small muted">Live figures couldn’t be loaded right now.</p>}
            <div className="hero__ctas">
              <Button href={whatsappLink('Hello Shree Heights, which 2 & 3 BHK flats are available today?')} target="_blank" rel="noopener noreferrer" icon="whatsapp">
                Check on WhatsApp
              </Button>
              <VisitButton from="availability" variant="ghost">Book a site visit</VisitButton>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
