import { useCallback, useState } from 'react';
import { AnimatePresence } from 'motion/react';
import Button, { VisitButton } from './Button.jsx';
import Icon from './Icon.jsx';
import VideoEmbed from './VideoEmbed.jsx';
import { Lightbox } from './Gallery.jsx';
import { Reveal } from './Motion.jsx';
import { CONSTRUCTION, CONTACT } from '../data/site.js';

/** Construction status, the YouTube update and the actual site photographs (from the original site). */
export default function ConstructionUpdates({ from, limit }) {
  const [open, setOpen] = useState(null);
  const photos = CONSTRUCTION.photos;
  const shown = limit ? photos.slice(0, limit) : photos;
  const onClose = useCallback(() => setOpen(null), []);
  const onStep = useCallback((step) => setOpen((i) => (i + step + photos.length) % photos.length), [photos.length]);

  return (
    <div className="construction">
      <div className="section-head section-head--split">
        <Reveal className="stack">
          <span className="eyebrow"><span className="chip__pulse" aria-hidden="true" />Construction update</span>
          <h2 className="h2">Structurally <em>almost complete.</em></h2>
        </Reveal>
        <Reveal className="stack stack--sm" delay={0.1}>
          <p>{CONSTRUCTION.summary} The latest site photographs show progress across the development.</p>
          <ul className="status">
            <li>
              <span className="status__mark"><Icon name="check" /></span>
              <span><strong>Residential towers</strong>Structure substantially in place</span>
            </li>
            <li>
              <span className="status__mark status__mark--wip"><Icon name="building" /></span>
              <span><strong>Commercial &amp; retail outlet</strong>Construction in full swing</span>
            </li>
          </ul>
        </Reveal>
      </div>

      <div className="construction__grid">
        <Reveal className="construction__video">
          <VideoEmbed id={CONTACT.youtubeId} poster={photos[0].src} label="Watch the construction update" />
        </Reveal>
        {shown.slice(1).map((p, i) => (
          <Reveal key={p.title} delay={(i % 4) * 0.06} className={p.h > p.w ? 'is-tall' : ''}>
            <button type="button" className="construction__photo" onClick={() => setOpen(i + 1)} aria-label={`Open photo: ${p.title}`}>
              <img src={p.src} alt="" loading="lazy" />
              <span>{p.title}</span>
            </button>
          </Reveal>
        ))}
      </div>

      <Reveal className="center-row">
        <Button type="button" variant="ghost" icon="plus" onClick={() => setOpen(0)}>View all {photos.length} site photos</Button>
        <VisitButton from={from}>See the progress in person</VisitButton>
      </Reveal>
      <p className="small muted" style={{ textAlign: 'center', marginTop: 16 }}>Actual site photographs.</p>

      <AnimatePresence>
        {open !== null && <Lightbox items={photos} index={open} onClose={onClose} onStep={onStep} />}
      </AnimatePresence>
    </div>
  );
}
