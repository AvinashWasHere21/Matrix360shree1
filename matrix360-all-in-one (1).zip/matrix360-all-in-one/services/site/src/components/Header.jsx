import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router';
import Brand from './Brand.jsx';
import Button, { VisitButton } from './Button.jsx';
import Icon from './Icon.jsx';
import { CONTACT, NAV, NAV_MORE, STORIES } from '../data/site.js';

function LifeMenu() {
  const [open, setOpen] = useState(false);
  const itemRef = useRef(null);
  const closeTimer = useRef();
  const { pathname } = useLocation();
  const active = STORIES.some((s) => s.to === pathname);

  const show = (value) => {
    clearTimeout(closeTimer.current);
    setOpen(value);
  };

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => { if (!itemRef.current?.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('pointerdown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <li
      className="nav__item--menu"
      ref={itemRef}
      onPointerEnter={(e) => e.pointerType === 'mouse' && show(true)}
      onPointerLeave={(e) => { if (e.pointerType === 'mouse') closeTimer.current = setTimeout(() => setOpen(false), 180); }}
      onBlur={(e) => { if (!itemRef.current?.contains(e.relatedTarget)) setOpen(false); }}
    >
      <button
        className="nav__link nav__trigger"
        type="button"
        aria-expanded={open}
        aria-controls="life-menu"
        aria-current={active ? 'page' : undefined}
        onClick={() => show(!open)}
      >
        Life here <Icon name="chevron" />
      </button>
      <div className={`nav__panel${open ? ' is-open' : ''}`} id="life-menu">
        <div className="nav__panel-core">
          {STORIES.map((story) => (
            <Link className="story-link" to={story.to} key={story.key} viewTransition>
              <img src={story.thumb || story.img} alt="" width="68" height="68" loading="lazy" />
              <span>
                {story.titleBn
                  ? <strong className="bn" lang="bn">{story.titleBn.replace('।', '')}</strong>
                  : <strong>{story.short}</strong>}
                <small>{story.sub}</small>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </li>
  );
}

function MobileMenu({ open }) {
  const items = [{ to: '/', label: 'Home' }, ...NAV, ...NAV_MORE];
  return (
    <div className={`mobile-menu${open ? ' is-open' : ''}`} id="mobile-menu" inert={!open}>
      <ul className="mobile-menu__list">
        {items.map((item, i) => (
          <li style={{ '--i': i }} key={item.to}>
            <NavLink to={item.to} end viewTransition>{item.label} <Icon name="arrow" /></NavLink>
          </li>
        ))}
      </ul>
      <div className="mobile-menu__stories" style={{ '--i': items.length }}>
        {STORIES.map((story) => (
          <Link to={story.to} key={story.key} viewTransition>
            {story.titleBn
              ? <strong className="bn" lang="bn">{story.titleBn.replace('।', '')}</strong>
              : <strong>{story.short}</strong>}
            <small>{story.eyebrow}</small>
          </Link>
        ))}
      </div>
      <div className="mobile-menu__foot" style={{ '--i': items.length + 1 }}>
        <VisitButton block />
        <Button href={CONTACT.mobile.href} variant="ghost" icon="phone" block>Call {CONTACT.mobile.label}</Button>
      </div>
    </div>
  );
}

export default function Header({ scrolled }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { pathname } = useLocation();
  const toggleRef = useRef(null);

  useEffect(() => setMenuOpen(false), [pathname]);

  useEffect(() => {
    document.documentElement.style.overflow = menuOpen ? 'hidden' : '';
    if (!menuOpen) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') { setMenuOpen(false); toggleRef.current?.focus(); }
    };
    const wide = matchMedia('(min-width: 1181px)');
    const onWide = (e) => { if (e.matches) setMenuOpen(false); };
    document.addEventListener('keydown', onKey);
    wide.addEventListener('change', onWide);
    return () => {
      document.removeEventListener('keydown', onKey);
      wide.removeEventListener('change', onWide);
    };
  }, [menuOpen]);

  return (
    <>
      <header className={`site-header${scrolled ? ' is-scrolled' : ''}`}>
        <div className="nav-shell">
          <Brand />
          <nav className="nav" aria-label="Primary">
            <ul className="nav__list">
              <li><NavLink className="nav__link" to="/residences" viewTransition>Residences</NavLink></li>
              <LifeMenu />
              {NAV.slice(1).map((item) => (
                <li key={item.to}><NavLink className="nav__link" to={item.to} viewTransition>{item.label}</NavLink></li>
              ))}
            </ul>
          </nav>
          <div className="nav__actions">
            <a className="icon-btn" href={CONTACT.mobile.href} aria-label={`Call ${CONTACT.mobile.label}`}>
              <Icon name="phone" />
            </a>
            <VisitButton size="sm" />
            <button
              ref={toggleRef}
              className="nav-toggle"
              type="button"
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              onClick={() => setMenuOpen((v) => !v)}
            >
              <span /><span />
            </button>
          </div>
        </div>
      </header>
      <MobileMenu open={menuOpen} />
    </>
  );
}
