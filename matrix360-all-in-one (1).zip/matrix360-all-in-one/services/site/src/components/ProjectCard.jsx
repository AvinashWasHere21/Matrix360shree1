import Button from './Button.jsx';
import Icon from './Icon.jsx';
import { BROCHURE_URL, CONTACT, RENDERS, whatsappLink } from '../data/site.js';

const BADGES = [
  { icon: 'building', label: '2 & 3 BHK apartments' },
  { icon: 'leaf', label: 'Podium garden' },
  { icon: 'shield', label: 'RERA registered', href: CONTACT.rera },
];

export default function ProjectCard() {
  return (
    <div className="frame">
      <div className="frame__core project">
        <div className="project__top">
          <div className="stack stack--sm">
            <h3 className="h3">About Shree Heights</h3>
            <p>
              Gated 2 &amp; 3 BHK residences across two towers in North Bagbazar, Chandannagar — modern design,
              thoughtful planning and a podium of amenities, a short walk from the Strand.
            </p>
          </div>
          <img src={RENDERS.aerialView} alt="" loading="lazy" />
        </div>
        <ul className="project__badges">
          {BADGES.map((b) => (
            <li key={b.label}>
              <Icon name={b.icon} />
              {b.href ? <a href={b.href} target="_blank" rel="noopener noreferrer">{b.label}</a> : <span>{b.label}</span>}
            </li>
          ))}
        </ul>
        {BROCHURE_URL ? (
          <Button href={BROCHURE_URL} download icon="arrow">Download brochure</Button>
        ) : (
          <Button href={whatsappLink('Hello Shree Heights, please share the project brochure.')} target="_blank" rel="noopener noreferrer" icon="whatsapp">
            Get the brochure
          </Button>
        )}
      </div>
    </div>
  );
}
