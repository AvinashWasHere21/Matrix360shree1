import { useEffect, useRef, useState } from 'react';
import { MotionConfig } from 'motion/react';
import { Outlet, ScrollRestoration, useLocation } from 'react-router';
import Header from './Header.jsx';
import { ActionBar, CtaBand, Footer } from './Footer.jsx';
import { captureAttribution } from '../lib/attribution.js';

export default function Layout() {
  const { pathname, search } = useLocation();
  const sentinel = useRef(null);
  const [scrolled, setScrolled] = useState(false);
  const onVisitPage = pathname === '/site-visit';

  useEffect(() => { captureAttribution(pathname, search); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Solid header once the top of the page leaves the viewport — no scroll listeners.
  useEffect(() => {
    const io = new IntersectionObserver(([entry]) => setScrolled(!entry.isIntersecting));
    io.observe(sentinel.current);
    return () => io.disconnect();
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <span ref={sentinel} className="scroll-sentinel" aria-hidden="true" />
      <a className="skip-link" href="#main">Skip to content</a>
      <Header scrolled={scrolled} />
      <main id="main" key={pathname}>
        <Outlet />
      </main>
      {!onVisitPage && <CtaBand />}
      <Footer />
      <ActionBar showVisit={!onVisitPage} />
      <ScrollRestoration />
    </MotionConfig>
  );
}
