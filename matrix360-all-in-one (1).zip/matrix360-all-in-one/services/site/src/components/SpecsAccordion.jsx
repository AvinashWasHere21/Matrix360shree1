import Icon from './Icon.jsx';
import { Reveal } from './Motion.jsx';
import { SPECS } from '../data/site.js';

export default function SpecsAccordion() {
  return (
    <div className="specs">
      {SPECS.map((spec, i) => (
        <Reveal as="details" className="spec" key={spec.title} open={i === 0} delay={i * 0.05} y={24}>
          <summary>
            <span className="spec__icon"><Icon name={spec.icon} /></span>
            <span className="spec__title">{spec.title}</span>
            <span className="spec__toggle" aria-hidden="true" />
          </summary>
          <div className="spec__body">
            <ul>{spec.items.map((item) => <li key={item}>{item}</li>)}</ul>
          </div>
        </Reveal>
      ))}
    </div>
  );
}
