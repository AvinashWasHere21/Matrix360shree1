import { useEffect, useId, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import Button from './Button.jsx';
import { Choices, Field, formatDate, isEmail, isPhone, todayISO } from './FormFields.jsx';
import { CONFIGS, CONTACT, FORM_ENDPOINT, SLOTS, whatsappLink } from '../data/site.js';
import { readAttribution } from '../lib/attribution.js';

function validate(values) {
  const errors = {};
  if (!values.name.trim()) errors.name = 'Please tell us your name.';
  if (!values.phone.trim()) errors.phone = 'We need a number to confirm your visit.';
  else if (!isPhone(values.phone)) errors.phone = 'Please enter a valid 10-digit mobile number.';
  if (values.email.trim() && !isEmail(values.email.trim())) errors.email = 'That email doesn’t look quite right.';
  return errors;
}

function buildMessage(kind, v, source) {
  const lines = [kind === 'visit'
    ? 'Hello Shree Heights, I would like to book a site visit.'
    : 'Hello Shree Heights, I have an enquiry.'];
  const add = (label, value) => { if (value) lines.push(`${label}: ${value}`); };
  add('Name', v.name);
  add('Phone', v.phone);
  add('Email', v.email);
  if (v.date) add('Preferred date', `${formatDate(v.date)}${v.slot ? ` (${v.slot})` : ''}`);
  else add('Preferred time', v.slot);
  add('Interested in', v.config);
  add('Message', v.message);
  add('Source', source);
  return lines.join('\n');
}

/**
 * Site-visit / enquiry form. With FORM_ENDPOINT set it posts JSON there; otherwise it opens
 * WhatsApp with the details filled in, so no lead is lost without a backend.
 */
export default function LeadForm({ kind = 'visit', title, intro }) {
  const uid = useId();
  const [params] = useSearchParams();
  const from = params.get('from') || '';
  const presetConfig = CONFIGS.find((c) => c.key === params.get('config'))?.label ?? '';

  const [values, setValues] = useState({
    name: '', phone: '', email: '', date: '', slot: '', config: presetConfig, message: '',
  });
  const [consent, setConsent] = useState(false); // optional, unticked: WhatsApp follow-up opt-in
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | delivered | whatsapp
  const [waUrl, setWaUrl] = useState('');
  const fieldRefs = { name: useRef(null), phone: useRef(null), email: useRef(null) };
  const successRef = useRef(null);

  useEffect(() => {
    if (status === 'delivered' || status === 'whatsapp') successRef.current?.focus();
  }, [status]);

  const set = (key) => (e) => {
    const value = typeof e === 'string' ? e : e.target.value;
    setValues((v) => ({ ...v, [key]: value }));
    if (errors[key]) setErrors((errs) => ({ ...errs, [key]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    const firstInvalid = ['name', 'phone', 'email'].find((k) => found[k]);
    if (firstInvalid) { fieldRefs[firstInvalid].current?.focus(); return; }

    const attr = readAttribution();
    const source = [from, attr.landing, attr.utm_source, attr.utm_campaign].filter(Boolean).join(' · ');
    const clean = Object.fromEntries(Object.entries(values).map(([k, v]) => [k, v.trim()]));
    const message = buildMessage(kind, clean, source);
    const url = whatsappLink(message);
    setWaUrl(url);

    if (!FORM_ENDPOINT) {
      // Synchronous inside the submit gesture, so pop-up blockers let it through.
      window.open(url, '_blank', 'noopener');
      setStatus('whatsapp');
      return;
    }

    setStatus('sending');
    try {
      const res = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ kind, ...clean, consent, from, attribution: attr, summary: message }),
      });
      setStatus(res.ok ? 'delivered' : 'whatsapp');
    } catch {
      setStatus('whatsapp');
    }
  };

  const firstName = values.name.trim().split(/\s+/)[0];

  if (status === 'delivered' || status === 'whatsapp') {
    return (
      <div className="form-success" ref={successRef} tabIndex={-1} role="status">
        <span className="success-mark">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5" /></svg>
        </span>
        <h2 className="h3">Thank you, {firstName}.</h2>
        {status === 'delivered' ? (
          <p>We’ve received your request. Our team will call you shortly to confirm the details.</p>
        ) : (
          <p>
            One last step — send the pre-filled message on WhatsApp so our team can confirm your
            {kind === 'visit' ? ' visit' : ' enquiry'}. If WhatsApp didn’t open, use the button below.
          </p>
        )}
        <div className="hero__ctas">
          <Button href={waUrl} target="_blank" rel="noopener noreferrer" icon="whatsapp">
            {status === 'delivered' ? 'Chat on WhatsApp' : 'Send on WhatsApp'}
          </Button>
          <Button href={CONTACT.office.href} variant="ghost" icon="phone">Call {CONTACT.office.label}</Button>
        </div>
      </div>
    );
  }

  const id = (name) => `${uid}-${name}`;

  return (
    <form className="form" noValidate onSubmit={onSubmit}>
      {(title || intro) && (
        <div className="form__head">
          {title && <h2>{title}</h2>}
          {intro && <p className="muted small">{intro}</p>}
        </div>
      )}

      <div className="form__row">
        <Field id={id('name')} label="Full name" error={errors.name}>
          <input
            ref={fieldRefs.name} id={id('name')} name="name" autoComplete="name" placeholder="Your name"
            value={values.name} onChange={set('name')} aria-invalid={!!errors.name}
            aria-describedby={errors.name ? `${id('name')}-error` : undefined}
          />
        </Field>
        <Field id={id('phone')} label="Mobile number" error={errors.phone}>
          <input
            ref={fieldRefs.phone} id={id('phone')} name="phone" type="tel" inputMode="tel" autoComplete="tel"
            placeholder="98XXX XXXXX" value={values.phone} onChange={set('phone')} aria-invalid={!!errors.phone}
            aria-describedby={errors.phone ? `${id('phone')}-error` : undefined}
          />
        </Field>
      </div>

      <Field id={id('email')} label="Email" optional error={errors.email}>
        <input
          ref={fieldRefs.email} id={id('email')} name="email" type="email" autoComplete="email"
          placeholder="you@example.com" value={values.email} onChange={set('email')} aria-invalid={!!errors.email}
          aria-describedby={errors.email ? `${id('email')}-error` : undefined}
        />
      </Field>

      {kind === 'visit' && (
        <div className="form__row">
          <Field id={id('date')} label="Preferred date" optional>
            <input id={id('date')} name="date" type="date" min={todayISO()} value={values.date} onChange={set('date')} />
          </Field>
          <Choices legend="Time of day" name={id('slot')} options={SLOTS} value={values.slot} onChange={set('slot')} />
        </div>
      )}

      <Choices legend="I’m interested in" name={id('config')} options={CONFIGS.map((c) => c.label)} value={values.config} onChange={set('config')} />

      <Field id={id('message')} label={kind === 'visit' ? 'Anything we should know?' : 'Your message'} optional>
        <textarea
          id={id('message')} name="message" rows="3" value={values.message} onChange={set('message')}
          placeholder={kind === 'visit' ? 'Number of visitors, questions for our team…' : 'Ask us anything about Shree Heights'}
        />
      </Field>

      <label className="form__consent">
        <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
        <span>Yes, you may also update me about my {kind === 'visit' ? 'visit' : 'enquiry'} on WhatsApp. (Optional. Reply STOP any time to opt out.)</span>
      </label>

      <Button type="submit" block disabled={status === 'sending'} icon={FORM_ENDPOINT ? 'arrow' : 'whatsapp'}>
        {status === 'sending' ? 'Sending…' : kind === 'visit' ? 'Request my site visit' : 'Send enquiry'}
      </Button>
      <p className="form__legal">
        By submitting, you agree to be contacted by Shree Heights about your {kind === 'visit' ? 'visit' : 'enquiry'}.
        {!FORM_ENDPOINT && ' Your request opens in WhatsApp, ready to send.'}
      </p>
    </form>
  );
}
