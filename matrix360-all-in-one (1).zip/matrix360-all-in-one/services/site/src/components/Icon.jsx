const SPRITE = `${import.meta.env.BASE_URL}icons.svg`;

export default function Icon({ name, className = '' }) {
  return (
    <svg className={`i ${className}`.trim()} aria-hidden="true" focusable="false">
      <use href={`${SPRITE}#i-${name}`} />
    </svg>
  );
}
