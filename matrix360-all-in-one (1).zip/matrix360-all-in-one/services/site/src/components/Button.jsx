import { Link, useLocation } from 'react-router';
import Icon from './Icon.jsx';
import { pageKey, visitHref } from '../lib/routes.js';

const classes = (...list) => list.filter(Boolean).join(' ');

/** Pill button with the arrow nested in its own circle. Renders a router Link, an <a> or a <button>. */
export default function Button({ to, href, variant = 'primary', size, block, icon = 'arrow', sub, children, className, ...rest }) {
  const cls = classes('btn', `btn--${variant}`, size && `btn--${size}`, block && 'btn--block', className);
  const inner = (
    <>
      {sub ? (
        <span className="btn__label">{children}<small>{sub}</small></span>
      ) : (
        <span>{children}</span>
      )}
      <span className="btn__icon"><Icon name={icon} /></span>
    </>
  );
  if (to) return <Link to={to} className={cls} viewTransition {...rest}>{inner}</Link>;
  if (href) return <a href={href} className={cls} {...rest}>{inner}</a>;
  return <button className={cls} {...rest}>{inner}</button>;
}

/** "Book a site visit" CTA that tells the booking page which page the visitor came from. */
export function VisitButton({ from, extra, children = 'Book a site visit', ...rest }) {
  const { pathname } = useLocation();
  return <Button to={visitHref(from ?? pageKey(pathname), extra)} {...rest}>{children}</Button>;
}

export function ArrowLink({ to, href, children, className, ...rest }) {
  const inner = <>{children}<Icon name="arrow" /></>;
  const cls = classes('link-arrow', className);
  if (to) return <Link to={to} className={cls} viewTransition {...rest}>{inner}</Link>;
  return <a href={href} className={cls} {...rest}>{inner}</a>;
}
