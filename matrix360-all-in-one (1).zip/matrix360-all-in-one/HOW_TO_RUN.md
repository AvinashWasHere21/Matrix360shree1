# Run Matrix360 (landing page + all services, one file)

Needs Python 3.10+ and Node 20.19+ (with npm). Internet is needed on the first run to install packages.

    python run.py          # first run installs everything, then starts all services
    python run.py test     # starts everything, runs the end-to-end test, stops

Press Ctrl+C to stop. On Windows use `py run.py`. Keep the terminal open while you use the site.

Open **http://127.0.0.1:5173** (the Shree Heights landing page). Everything else hangs off it:

| What | Where | How it connects to the landing page |
|---|---|---|
| Landing page | http://127.0.0.1:5173 | |
| Chat bubble (bottom right) | on every page | Avinash's chat widget, loaded by the site; chats become leads |
| Site-visit / enquiry / partner forms | /site-visit, /contact, /partners | post to the shared DB; ad tags (utm) are kept |
| WhatsApp follow-up | http://127.0.0.1:4000 | the visit form has an optional WhatsApp opt-in box; only ticked leads can be messaged |
| Dashboard (admin key `demo-admin-key`) | http://127.0.0.1:8000/platform | every lead from the site, chat and Radar, with history |
| Demand Radar | http://127.0.0.1:8002/index.html | `python services/radar/push_to_shared_db.py --send` adds its leads |

Test it: open /site-visit, submit the form, then look at the dashboard.

Changes made so everything follows the landing page as the source of truth:
- The chat's price answer now says "from ₹70 Lakhs onwards, exact unit price from the sales team" (it used to say prices were undecided).
- The visit form has a new optional, unticked WhatsApp consent box.

Notes: WhatsApp sending and AI replies are mocked. Outside 9am-8pm IST the WhatsApp gate blocks sends on purpose
(set SENDING_WINDOW_START_HOUR=0 SENDING_WINDOW_END_HOUR=24 to override). Change the demo keys before sharing.
Logs: ./logs. Data: ./data (delete to reset).
