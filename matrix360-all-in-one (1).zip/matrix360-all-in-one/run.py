#!/usr/bin/env python3
"""Matrix360: one file to run the whole platform, with the Shree Heights landing page at the front.

    python run.py          install (first time only), start everything, keep running
    python run.py test     start everything, run the end-to-end test, stop
    python run.py setup    only install dependencies

Press Ctrl+C to stop all services. Needs Python 3.10+ and Node 20+.
Works on Windows, macOS and Linux. Logs go to ./logs.
"""
import os, subprocess, sys, time, urllib.request, venv, signal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
S, LOGS, DATA, VENV = ROOT / "services", ROOT / "logs", ROOT / "data", ROOT / ".venv"
WIN = os.name == "nt"
PY = VENV / ("Scripts/python.exe" if WIN else "bin/python")
NPM = "npm.cmd" if WIN else "npm"
NODE = "node"
DB = "http://127.0.0.1:8000"
ADMIN = os.environ.get("ADMIN_API_KEY", "demo-admin-key")
INTEG = os.environ.get("INTEGRATION_API_KEY", "demo-integration-key")


def run(cmd, cwd=None):
    subprocess.run([str(c) for c in cmd], cwd=cwd, check=True)


def setup():
    if not PY.exists():
        print("creating virtual environment ...")
        venv.create(VENV, with_pip=True)
    print("installing Python packages (shared DB + chat) ...")
    run([PY, "-m", "pip", "install", "-q", "--no-cache-dir", "-r", S / "shared-db/requirements.txt",
         "-r", S / "chat/requirements.txt"])
    if not (S / "engage/node_modules/express").exists():
        print("installing Node packages (WhatsApp engage) ...")
        run([NPM, "ci", "--silent"], cwd=S / "engage")
    if not (S / "site/node_modules/vite").exists():
        print("installing Node packages (landing site) ...")
        run([NPM, "ci", "--silent"], cwd=S / "site")


def services():
    """(name, port, cwd, command, extra env, health url)"""
    # Outside 9am-8pm IST the WhatsApp policy gate blocks sends (correct behaviour);
    # the test mode widens the window so the test works at any hour.
    start, end = (os.environ.get("SENDING_WINDOW_START_HOUR", "9"),
                  os.environ.get("SENDING_WINDOW_END_HOUR", "20"))
    return [
        ("shared-db", 8000, S / "shared-db",
         [PY, "-m", "uvicorn", "app.main:app", "--port", "8000"],
         dict(DATABASE_URL=f"sqlite:///{(DATA / 'matrix360.db').as_posix()}", ADMIN_API_KEY=ADMIN,
              INTEGRATION_API_KEY=INTEG, AI_PROVIDER=os.environ.get("AI_PROVIDER", "demo")),
         f"{DB}/health"),
        ("chat", 8001, S / "chat",
         [PY, "-m", "uvicorn", "server:app", "--port", "8001"],
         dict(ALLOW_LOCALHOST="1", ADMIN_KEY=ADMIN, DB_PATH=str(DATA / "chat.db"),
              DB_API_URL=f"{DB}/integrations/chat", DB_API_KEY=INTEG, DB_FLAVOR="generic"),
         "http://127.0.0.1:8001/health"),
        ("engage", 4000, S / "engage", [NODE, "server.js"],
         dict(PORT="4000", USE_DEV_DB_ADAPTER="false", SHARED_DB_URL=f"{DB}/integrations/whatsapp",
              SHARED_DB_API_KEY=INTEG, USE_MOCK_GROK="true", WHATSAPP_MOCK_SEND="true",
              SENDING_WINDOW_START_HOUR=start, SENDING_WINDOW_END_HOUR=end),
         "http://127.0.0.1:4000/api/health"),
        # Landing site (Shalini) with Avinash's chat widget built in; its forms post to the shared DB.
        ("site", 5173, S / "site",
         [NODE, "node_modules/vite/bin/vite.js", "--host", "127.0.0.1", "--port", "5173", "--strictPort"],
         dict(VITE_FORM_ENDPOINT=f"{DB}/integrations/landing/enquiry",
              VITE_CHAT_WIDGET_URL="http://127.0.0.1:8001/widget.js"),
         "http://127.0.0.1:5173/"),
        # Demand Radar page is plain HTML + JSON, so a static server is enough.
        ("radar", 8002, S / "radar",
         [PY, "-m", "http.server", "8002", "--bind", "127.0.0.1"], {}, "http://127.0.0.1:8002/index.html"),
    ]


def up(url):
    try:
        urllib.request.urlopen(url, timeout=2).read()
        return True
    except Exception:
        return False


def start(test_mode=False):
    LOGS.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
    if test_mode:
        os.environ["SENDING_WINDOW_START_HOUR"], os.environ["SENDING_WINDOW_END_HOUR"] = "0", "24"
    procs = []
    for name, port, cwd, cmd, env, url in services():
        if up(url):
            sys.exit(f"Port {port} ({name}) is already in use. Stop whatever is running there first.")
        log = open(LOGS / f"{name}.log", "w")
        p = subprocess.Popen([str(c) for c in cmd], cwd=cwd, env={**os.environ, **env},
                             stdout=log, stderr=subprocess.STDOUT)
        procs.append((name, p, url))
    ok = True
    for name, p, url in procs:
        for _ in range(60):
            if up(url) or p.poll() is not None:
                break
            time.sleep(0.5)
        good = up(url)
        ok &= good
        print(("up   " if good else "DOWN ") + url + ("" if good else f"   (see logs/{name}.log)"))
    return procs, ok


def stop(procs):
    for _, p, _ in procs:
        if p.poll() is None:
            p.terminate()
    for _, p, _ in procs:
        try:
            p.wait(timeout=8)
        except subprocess.TimeoutExpired:
            p.kill()
    print("stopped")


BANNER = f"""
Everything is running.
  >>> LANDING PAGE (start here)        http://127.0.0.1:5173
  Dashboard (admin key: {ADMIN})   http://127.0.0.1:8000/platform
  Shared DB API docs               http://127.0.0.1:8000/docs
  Website chat demo                http://127.0.0.1:8001/demo
  WhatsApp engage + policy gate    http://127.0.0.1:4000
  Demand Radar page                http://127.0.0.1:8002/index.html
To load the Radar leads into the DB:  python services/radar/push_to_shared_db.py --send
Press Ctrl+C to stop.
"""


def main():
    if sys.version_info < (3, 10):
        sys.exit("Python 3.10+ required")
    cmd = sys.argv[1] if len(sys.argv) > 1 else "start"
    setup()
    if cmd == "setup":
        return print("Setup done.")
    procs, ok = start(test_mode=(cmd == "test"))
    try:
        if not ok:
            sys.exit(1)
        if cmd == "test":
            sys.exit(subprocess.run([str(PY), str(ROOT / "e2e_test.py")]).returncode)
        print(BANNER)
        while all(p.poll() is None for _, p, _ in procs):
            time.sleep(1)
        print("A service exited; check logs/")
    except KeyboardInterrupt:
        pass
    finally:
        stop(procs)


if __name__ == "__main__":
    main()
